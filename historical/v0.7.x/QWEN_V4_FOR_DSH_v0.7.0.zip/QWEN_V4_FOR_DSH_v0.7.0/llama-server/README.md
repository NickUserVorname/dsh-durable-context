# llama-server profile

1. Run `llama-server.exe --list-devices` and copy the exact V100 / RTX 3070 Ti device identifiers.
2. Start `start-qwen38-windows.ps1` with those identifiers and your Q4_K_M GGUF.
3. Default: layer split 4:1, ctx 128K, KV q8_0/q5_1, one slot, MEDIUM reasoning, **6144 tokens per reasoning block**, DSH total completion cap 16384/request, raw reasoning history not preserved back into the model template. The launcher binds only `127.0.0.1` and requires API key `local`; set `LLAMA_LOCAL_API_KEY=local` for DSH.
4. Current llama.cpp may re-arm the reasoning sampler on another reasoning block in the same response. Do not describe 6144 as a request-wide hard reasoning maximum; v0.7.0 keeps host reasoning-output-starvation recovery.
5. See `ADDENDUM_MODEL_GPU_REASONING_TUNING.md` before tuning.


The 4:1 + q8_0/q5_1 + FlashAttention=on profile is the qualified 128K baseline for the documented V100 16GB + RTX 3070 Ti 8GB setup. It requires a llama.cpp build with `GGML_CUDA_FA_ALL_QUANTS=ON` for the mixed KV path.
