from pathlib import Path
import hashlib, json, tarfile, yaml, re

root = Path(__file__).resolve().parents[1]

required = [
    'dist/local-dsh-v4-control-0.7.0.tgz',
    'dsh-bundle-v4-control/package.json',
    'dsh-bundle-v4-control/cordis.patch.yml',
    'dsh-bundle-v4-control/index.js',
    'dsh-bundle-v4-control/lib/core.js',
    'dsh-bundle-v4-control/lib/intent-router.js',
    'dsh-bundle-v4-control/lib/test-gate.js',
    'dsh-bundle-v4-control/lib/role-control.js',
    'dsh-bundle-v4-control/lib/runtime-policy.js',
    'dsh-bundle-v4-control/lib/execution-usage.js',
    'dsh-bundle-v4-control/lib/fresh-role.js',
    'dsh-bundle-v4-control/lib/role-results.js',
    'dsh-bundle-v4-control/lib/role-schemas.js',
    'dsh-bundle-v4-control/lib/host-runtime.js',
    'dsh-bundle-v4-control/lib/evidence.js',
    'dsh-bundle-v4-control/lib/operations.js',
    'dsh-bundle-v4-control/lib/commands.js',
    'dsh-bundle-v4-control/lib/context-memory.js',
    'dsh-bundle-v4-control/lib/context-pressure.js',
    'dsh-bundle-v4-control/lib/context-commands.js',
    'dsh-bundle-v4-control/lib/universal-commit.js',
    'dsh-preset-qwen-v4/agent.cordis.yml',
    'dsh-settings/llama-local.settings.example.yaml',
    'dsh-settings/runtime-policy.example.json',
    'llama-server/start-qwen38-windows.ps1',
    'project-template/.dsh/project/state.json',
    'project-template/.dsh/project/WORKING_STATE.json',
    'project-template/.dsh/project/SOURCE_POLICY.md',
    'project-template/.dsh/project/ACTIVE_REQUIREMENTS.json',
    'project-template/.dsh/project/INFERENCE_POLICY.md',
    'project-template/.dsh/project/IGNORED_POLICY.md',
    'project-template/.dsh/project/RUNTIME_POLICY.json',
    'ADDENDUM_MODEL_GPU_REASONING_TUNING.md',
    'FINAL_SPEC_V0_7.md',
    'HARDENING_V0_7.md',
    'INSTALL_V0_7_WINDOWS.ps1',
    'INSTALL_V0_7_WINDOWS.cmd',
    'docs/EXTERNAL_RUNTIME_POLICY.md',
    'docs/IMPLEMENTATION_STATUS.md',
    'docs/history/FINAL_SPEC_V0_6.md',
    'docs/history/HARDENING_V0_6.md',
    'tests/hardening-v060.test.mjs',
    'tests/hardening-v070.test.mjs',
    'tests/runtime-policy.test.mjs',
    'tests/package-portability.test.mjs',
    'tests/RUNTIME_ADVERSARIAL_SUITE.md',
    '_LOCAL_C_DSH-QWEN/01-start-qwen38-128k.ps1',
    '_LOCAL_C_DSH-QWEN/02-install-v070-qualification.ps1',
    '_LOCAL_C_DSH-QWEN/03-verify-live.ps1',
    '_LOCAL_C_DSH-QWEN/LOCAL_OVERLAY_MANIFEST.json',
    'PACKAGE_MANIFEST.json',
]
for rel in required:
    assert (root / rel).exists(), f'missing {rel}'

assert not (root / 'project-template/.dsh/project/MODEL_ROUTING.md').exists(), 'legacy MODEL_ROUTING.md must not be active'

# Node parses JSON as UTF-8 without BOM. Every shipped JSON must be BOM-free and valid.
for p in root.rglob('*.json'):
    data = p.read_bytes()
    assert not data.startswith(b'\xef\xbb\xbf'), f'UTF-8 BOM in JSON: {p.relative_to(root)}'
    json.loads(data.decode('utf-8'))

class Loader(yaml.SafeLoader):
    pass
Loader.add_constructor('tag:yaml.org,2002:js', lambda loader, node: loader.construct_scalar(node))
for p in list(root.rglob('*.yml')) + list(root.rglob('*.yaml')):
    yaml.load(p.read_text(encoding='utf-8'), Loader=Loader)

# Packed npm artifact must contain the expected bundle and be source-identical.
tgz = root / 'dist/local-dsh-v4-control-0.7.0.tgz'
with tarfile.open(tgz, 'r:gz') as t:
    names = set(t.getnames())
    expected_bundle_files = [
        'package/package.json', 'package/index.js', 'package/cordis.patch.yml', 'package/README.md',
        'package/lib/core.js', 'package/lib/state.js', 'package/lib/git.js', 'package/lib/ledger.js',
        'package/lib/working-state.js', 'package/lib/token-accounting.js', 'package/lib/baseline.js',
        'package/lib/intent-router.js', 'package/lib/test-gate.js', 'package/lib/role-control.js',
        'package/lib/runtime-policy.js', 'package/lib/execution-usage.js', 'package/lib/fresh-role.js',
        'package/lib/role-results.js', 'package/lib/role-schemas.js', 'package/lib/host-runtime.js',
        'package/lib/evidence.js', 'package/lib/operations.js', 'package/lib/commands.js',
        'package/lib/context-memory.js', 'package/lib/context-pressure.js', 'package/lib/context-commands.js',
        'package/lib/universal-commit.js',
    ]
    for n in expected_bundle_files:
        assert n in names, f'tgz missing {n}'
    pkg = json.loads(t.extractfile('package/package.json').read())
    assert pkg['version'] == '0.7.0'
    for n in expected_bundle_files:
        rel = n.removeprefix('package/')
        src = root / 'dsh-bundle-v4-control' / rel
        packed = t.extractfile(n).read()
        assert src.read_bytes() == packed, f'tgz/source mismatch: {rel}'

manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest['version'] == '0.7.0'
assert manifest['file_count'] == len(manifest['files'])
manifest_paths = {item['path'] for item in manifest['files']}
actual_paths = {
    p.relative_to(root).as_posix()
    for p in root.rglob('*')
    if p.is_file() and p.name != 'PACKAGE_MANIFEST.json'
}
assert manifest_paths == actual_paths, f'manifest path set mismatch: missing={sorted(actual_paths-manifest_paths)} extra={sorted(manifest_paths-actual_paths)}'
for item in manifest['files']:
    p = root / item['path']
    data = p.read_bytes()
    assert len(data) == item['bytes'], f'manifest size mismatch {item["path"]}'
    assert hashlib.sha256(data).hexdigest() == item['sha256'], f'manifest hash mismatch {item["path"]}'

# Current docs/installers must point to v0.7 active artifacts. Historical docs may describe v0.6.
current_docs = [
    'README_FIRST.md', 'INSTALL_AND_RUN_WINDOWS.md', 'FINAL_SPEC_V0_7.md', 'HARDENING_V0_7.md',
    'docs/IMPLEMENTATION_STATUS.md', 'docs/EXTERNAL_RUNTIME_POLICY.md', '_LOCAL_C_DSH-QWEN/README_LOCAL.md',
]
for rel in current_docs:
    txt = (root / rel).read_text(encoding='utf-8')
    for stale in ['local-dsh-v4-control-0.6.0.tgz', 'INSTALL_V0_6_WINDOWS.ps1', '02-install-v060-qualification.ps1']:
        assert stale not in txt, f'stale active release ref in {rel}: {stale}'

launcher = (root / 'llama-server/start-qwen38-windows.ps1').read_text(encoding='utf-8')
for needle in [
    '[int]$ReasoningBudget = 6144', '[string]$TensorSplit = "4,1"',
    '--cache-type-k q8_0', '--cache-type-v q5_1', '--flash-attn on', '--fit off', '--api-key local',
]:
    assert needle in launcher, f'qualified llama launcher missing: {needle}'

installer = (root / 'INSTALL_V0_7_WINDOWS.ps1').read_text(encoding='utf-8')
assert '$env:DSH_HOME' in installer and '$ResolvedDshHome' in installer, 'installer must honor DSH_HOME'
assert 'ExistingProjectPolicy = "Stop"' in installer, 'installer must fail closed on existing .dsh by default'
assert 'MergeMissing' in installer and 'Copy-MissingTree' in installer, 'installer must use explicit non-overwrite merge mode'
assert 'PolicyFile' in installer and '[string[]]$Set' in installer, 'installer must accept external runtime policy and CLI overrides'
assert 'Copy-Item (Join-Path $ProjectTemplate "*") $ProjectDst -Recurse -Force' not in installer, 'installer must not force-overwrite project .dsh'
assert 'System.Text.UTF8Encoding($false)' in installer, 'installer must provide UTF-8 no-BOM writer'
assert 'Write-Utf8NoBom $PolicyDst $PolicyJson' in installer, 'runtime policy must be written without BOM'
assert "qwen-v4-runtime-policy-0.7.0" in installer

# Local-only composition must neutralize stock external routes while pinning fallback to local Qwen.
cordis = (root / 'dsh-bundle-v4-control/cordis.patch.yml').read_text(encoding='utf-8')
assert re.search(r'id:\s*agent-default-model[\s\S]*?provider:\s*llama-local[\s\S]*?model:\s*qwen3\.8-27b', cordis)
for ident in ['session-title-llm', 'web-search-deepseek', 'llm-deepseek', 'session-telemetry-otel']:
    assert re.search(rf'id:\s*{re.escape(ident)}[\s\S]{{0,120}}?disabled:\s*true', cordis), f'local-only override missing: {ident}'

# v0.7 memory/context invariants.
index = (root / 'dsh-bundle-v4-control/index.js').read_text(encoding='utf-8')
universal = (root / 'dsh-bundle-v4-control/lib/universal-commit.js').read_text(encoding='utf-8')
pressure = (root / 'dsh-bundle-v4-control/lib/context-pressure.js').read_text(encoding='utf-8')
preset = (root / 'dsh-preset-qwen-v4/agent.cordis.yml').read_text(encoding='utf-8')
assert 'state_checkpoint' in universal and 'FINALIZATION_TOOL_DENIED' in universal
assert 'COMPACTION_REQUIRED' in pressure and 'surfaceOp' in pressure and "sourceEventSeqs" in pressure
assert 'isProtocolTool(exec.name)' in index
assert '@deepseek-ai/dsh-compaction-basic' not in preset and '@deepseek-ai/dsh-command-compact' not in preset
policy = json.loads((root / 'project-template/.dsh/project/RUNTIME_POLICY.json').read_text(encoding='utf-8'))
assert policy['schema_version'] == 'qwen-v4-runtime-policy-0.7.0'
assert policy['universal_commit']['finalization_max_tokens'] == 4096
assert policy['context_pressure']['context_window'] == 131072
working = json.loads((root / 'project-template/.dsh/project/WORKING_STATE.json').read_text(encoding='utf-8'))
assert working['schema_version'] == 5 and 'covered_surface_through_seq' in working['checkpoint_meta'] and 'state_hash' in working['checkpoint_meta']

# Active model-visible donor fossils are release failures. Historical migration docs are excluded.
active = []
for base in [root / 'project-template/.dsh/skills', root / 'project-template/.dsh/project']:
    active += [p for p in base.rglob('*') if p.is_file() and p.suffix.lower() in {'.md', '.json', '.yml', '.yaml'}]
forbidden = [r'model_class\s*:\s*cheap', r'route to Pro', r'Mark each task `cheap`', r'scripts/agent_task\.py', r'task_graph\.json', r'claims\.json']
for p in active:
    txt = p.read_text(encoding='utf-8', errors='ignore')
    for pat in forbidden:
        assert not re.search(pat, txt, re.I), f'active donor fossil in {p.relative_to(root)}: {pat}'

# Build-machine path leakage is a release failure.
text_suffixes = {'.js', '.mjs', '.json', '.md', '.yml', '.yaml', '.ps1', '.py', '.csv', '.txt', '.cmd'}
banned = [re.compile('/mnt' + '/data/', re.I), re.compile(r'v02\d+build', re.I), re.compile('/home' + '/oai/', re.I), re.compile(r'[A-Za-z]:\\Users\\(?!<)', re.I)]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in text_suffixes:
        continue
    txt = p.read_text(encoding='utf-8', errors='ignore')
    for rx in banned:
        assert not rx.search(txt), f'build-machine path leakage in {p.relative_to(root)}: {rx.pattern}'

index_lines = len((root / 'dsh-bundle-v4-control/index.js').read_text(encoding='utf-8').splitlines())
assert index_lines < 900, f'index.js re-monolithized: {index_lines} lines'

print('validate_package.py: PASS')
