# External runtime policy — v0.7.0

Runtime limits live in `.dsh/project/RUNTIME_POLICY.json` and may be overlaid by the Windows installer with `-PolicyFile` and `-Set`.

Example:

```powershell
.\INSTALL_V0_7_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home `
  -Set 'context_pressure.soft_headroom_tokens=30000;universal_commit.finalization_max_tokens=3072'
```

The policy keeps the v0.6 task/fresh-role budgets and adds:

- `universal_commit.*` — checkpoint recovery, ephemeral response basis cap, finalization request cap/reasoning effort;
- `context_pressure.*` — context window, completion/compression/safety reserves, soft/hard thresholds, warning hysteresis and retained recent-window policy.

Pressure thresholds must satisfy `hard_headroom_tokens < soft_headroom_tokens`, and total fixed reserves must remain smaller than the context window.
