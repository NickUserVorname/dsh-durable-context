$ErrorActionPreference = "Stop"
$Root     = "C:\DSH-QWEN"
$DshHome  = "$Root\dsh-home"
$DshCmd   = "$Root\runtime\dsh\node_modules\.bin\dsh.cmd"
$Node     = "$Root\runtime\node"
$DshBin   = "$Root\runtime\dsh\node_modules\.bin"
$QProject = "$Root\qualification-v070"
$Headers  = @{ Authorization = "Bearer local" }

$env:DSH_HOME = $DshHome
$env:LLAMA_LOCAL_API_KEY = "local"
$env:DSH_TELEMETRY_MODE = "DISABLED"
$env:DEEPSEEK_API_KEY = ""
$env:Path = "$Node;$DshBin;$env:Path"

Write-Host "===== FILE LAYER ====="
foreach ($p in @("$Root\start-qwen38-128k.ps1","$Root\start-dsh-qwen.cmd","$DshHome\settings.yaml","$DshHome\.agent-presets\qwen-v4\agent.cordis.yml","$QProject\.dsh\project\RUNTIME_POLICY.json")) {
  if (!(Test-Path -LiteralPath $p)) { throw "Missing required file: $p" }
  Write-Host "OK $p"
}

Write-Host "===== JSON BOM + PARSE ====="
Get-ChildItem "$QProject\.dsh" -Recurse -File -Filter "*.json" | ForEach-Object {
  $b=[System.IO.File]::ReadAllBytes($_.FullName)
  if ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { throw "UTF-8 BOM found in JSON: $($_.FullName)" }
  Get-Content $_.FullName -Raw | ConvertFrom-Json | Out-Null
}

Write-Host "===== DSH DUMP ====="
$Dump = "$Root\dump-config-v070-verify.txt"
& $DshCmd --profile web --dump-config 2>&1 | Tee-Object -FilePath $Dump | Out-Null
if ($LASTEXITCODE -ne 0) { throw "dsh dump-config failed" }
$Raw=Get-Content $Dump -Raw
foreach ($Pattern in @('local-v4-control','provider:\s*llama-local','model:\s*qwen3.8-27b')) { if ($Raw -notmatch $Pattern) { throw "Missing config: $Pattern" } }
foreach ($Id in @('session-title-llm','web-search-deepseek','llm-deepseek','session-telemetry-otel')) { if ($Raw -notmatch "(?s)- id: $([regex]::Escape($Id)).{0,500}?disabled: true") { throw "Not disabled: $Id" } }

Write-Host "===== LLAMA HEALTH ====="
Invoke-RestMethod "http://127.0.0.1:8080/health" -Headers $Headers -TimeoutSec 5 | Format-List *
$Models=Invoke-RestMethod "http://127.0.0.1:8080/v1/models" -Headers $Headers -TimeoutSec 5
if (-not ($Models.data.id -contains 'qwen3.8-27b')) { throw "qwen3.8-27b alias not exposed" }

Write-Host "===== SHORT TOOL-CALL INFERENCE ====="
$Body=@{
  model='qwen3.8-27b'; messages=@(@{role='user';content='Call echo_probe exactly once with value TOOL_OK. Do not answer in plain text.'});
  tools=@(@{type='function';function=@{name='echo_probe';description='probe';parameters=@{type='object';properties=@{value=@{type='string'}};required=@('value');additionalProperties=$false}}});
  temperature=0; max_tokens=512; stream=$false
} | ConvertTo-Json -Depth 30
$R=Invoke-RestMethod -Uri "http://127.0.0.1:8080/v1/chat/completions" -Method POST -Headers $Headers -ContentType 'application/json' -Body $Body -TimeoutSec 300
$Call=$R.choices[0].message.tool_calls[0]
if ($Call.function.name -ne 'echo_probe' -or $Call.function.arguments -notmatch 'TOOL_OK') { throw "Tool-call qualification failed" }
$R.choices[0].message | ConvertTo-Json -Depth 20

Write-Host "===== GPU ====="
nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader
Write-Host "LIVE LLAMA + DSH LOCAL-ONLY CONFIG PASS - v0.7.0"
