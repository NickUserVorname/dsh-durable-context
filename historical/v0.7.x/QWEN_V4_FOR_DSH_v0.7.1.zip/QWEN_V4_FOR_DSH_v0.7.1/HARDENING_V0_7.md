# Hardening v0.7.1 — universal state commit and context-pressure compaction

v0.7.1 is a context/memory hardening release on top of v0.6.0. It preserves all v0.6 fixes: structured-output admission, exact-cap budget semantics, no-BOM Windows policy writes, fail-closed critical task guards, local-only DeepSeek route neutralization, expanded fresh-role budgets, and the qualified llama profile.

## H7-1 — One semantic memory model

`WORKING_STATE` schema is bumped to 5. No parallel conversation-summary authority is introduced. Extended checkpoint metadata adds stable coverage and state identity.

## H7-2 — Universal commit-before-answer

A top-level ordinary model turn is intercepted by the host. The host injects the committed state plus a primary commit protocol. A turn that attempts natural completion without a checkpoint is steered once by default into checkpoint-only mode. Failure after the bounded recovery allowance is cancelled explicitly.

`state_checkpoint` permits model-owned semantic fields only. Host-owned fields are re-derived from authoritative project/task state.

## H7-3 — Rendering-only finalization

After accepted checkpoint, a separate continuation is injected with the updated state and ephemeral response basis. All tool calls are denied in finalization. Request output is capped and reasoning defaults to `off`.

## H7-4 — Protocol-tool accounting

`state_checkpoint` and `task_checkpoint` are excluded from the normal per-turn tool anti-runaway counter because they are mandatory protocol operations. This does not erase their real events or provider token usage.

## H7-5 — Coverage metadata

Every universal checkpoint and `/work` task checkpoint writes:

```text
checkpoint_id
checkpoint_kind
covered_surface_through_seq
session_revision
source_revision
state_hash
```

`task_failed_hypothesis` also refreshes host-owned state/coverage so compaction never relies on a stale semantic hash.

## H7-6 — Context-pressure gate

The host measures the canonical session/model surface through `tokenMeter` and subtracts completion, compression-recovery, and safety reserves. SOFT warning uses deterministic context injection with hysteresis. HARD pressure rejects the ordinary model step before context overflow.

## H7-7 — Structured compaction only

The qwen-v4 preset no longer enables stock `compaction-basic`, stock `/compact`, or its tool-result-pruner group. `/compress` replaces only a validated covered prefix with a structured state snapshot. Raw session events stay in the archive and are referenced through `sourceEventSeqs`.

## H7-8 — Conservative turn boundaries

Compaction never splits a completed turn. User messages that precede `turn/start` are assigned conservatively to the following completed turn. Unknown/unowned surface nodes stop the compactable prefix rather than being guessed safe.

## H7-9 — Stale-safe commit

`/compress` records session revision, checkpoint id, and state hash, then rechecks them immediately before surface replacement. Any mismatch aborts without modifying the active surface.

## H7-10 — Deterministic inspection

`/context`, `/status`, and `/compress --dry-run` expose context/compaction state without a model inference.

## H7-11 — Natural intent parity and pressure-offer recovery

`/context` and `/compress` are registered slash commands **and** participate in the same conservative host intent router as the older workflow commands. Read-only context questions such as `сколько контекста осталось?` route directly to `/context` without a model request. Only unambiguous imperative compression phrases route to `/compress`; questions, negations, hypotheticals, and quoted examples remain ordinary chat. Dry-run phrases route to `/compress --dry-run`.

A SOFT-pressure notice arms an ephemeral host-side compression offer. While that offer is active, short acknowledgements such as `да`, `окей`, or `сжимай` may route to `/compress`. The same words do nothing without an active offer. Successful real compression clears the offer. Because the intent-router hook runs before the universal model-pressure gate, an explicit natural compression request remains a recovery path even when the next normal model request would be `COMPACTION_REQUIRED`.

## Known live-qualification boundary

The plugin uses public DSH hook/surface concepts (`agent/pre-step`, `agent/turn-stopping`, tool guards, session surface replacement, token-meter). Static tests validate the intended contracts using mocks, but v0.7.1 must still be qualified on the installed DSH 0.1.1-rc.1 before being treated as production-proven. In particular, primary-response streaming suppression is not claimed as a custom DSH-core feature.
