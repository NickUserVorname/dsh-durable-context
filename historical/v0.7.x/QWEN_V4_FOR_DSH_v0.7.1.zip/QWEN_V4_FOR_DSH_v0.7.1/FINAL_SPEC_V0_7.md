# QWEN-V4-FOR-DSH — Final Specification v0.7.1

## 1. Architecture

DeepSeek Harness is the host runtime. Qwen3.8-27B is a bounded local executor. Project authority, lifecycle, budgets, guards, evidence, durable memory, and context-pressure policy are host-owned.

The canonical semantic memory is still the single `WORKING_STATE.json` structure:

- `known`
- `decisions`
- `evidence`
- `failed_hypotheses` — host-authoritative
- `do_not_repeat`
- `open_acceptance` — host-authoritative
- `next_action`

No `TURN_CAPSULE`, second summary table, or free-form compaction summary becomes an authority source.

Raw historical reasoning is not durable memory. The local llama profile keeps `--no-reasoning-preserve`; useful results are externalized into structured state.

## 2. Universal commit-before-answer

Every **top-level model-backed user-facing turn** in a controlled project uses this lifecycle:

```text
USER
  -> PRIMARY PHASE
       reasoning on
       normal mode-appropriate tools
       one or more model/tool steps
  -> mandatory state_checkpoint
  -> host schema/authority validation
  -> atomic WORKING_STATE merge + coverage metadata
  -> host reinjection
  -> FINALIZATION PASS
       reasoning off/low
       no tools
       no state mutation
       bounded output
  -> USER-FACING ANSWER
```

Host-only commands such as `/status`, `/context`, and `/compress` do not fabricate a model checkpoint because they do not create a model-backed answer.

A primary phase must explicitly produce either a semantic delta or `state_checkpoint(no_change=true)`. Missing checkpoint is a protocol failure, not an implicit no-change result.

`task_checkpoint` remains the evidence-aware `/work` specialization. A main `/work` worker continues using task checkpoint barriers and does not use the general conversation checkpoint.

Internal fresh roles (`SOURCE_CURATOR`, `TASK_PLANNER`, `TEST_ANALYST`, `REVIEWER`, `ACCEPTANCE_AUDITOR`) continue to return their typed schemas. Their tentative internal output is not automatically merged into `WORKING_STATE`.

### 2.1 Primary answer publication rule

The primary prompt requires the model to finish with a checkpoint tool call rather than a user-facing answer. A checkpoint call containing provisional text is rejected as a protocol violation. Finalization is requested only after commit.

DSH UI streaming behavior remains a live-qualification item: the plugin can reject an invalid primary assistant message and refuse terminal success, but v0.7.1 does not claim a custom core stream-buffer implementation until verified on the installed DSH build.

### 2.2 Ephemeral response basis

The checkpoint may include a bounded `response_basis` with:

- `conclusion`
- `details`
- `warnings`

It exists only between primary commit and finalization. It is not persisted as a second memory store and is discarded after finalization.

### 2.3 Coverage metadata

Successful checkpoints advance mechanical coverage only after validation and atomic state persistence. `checkpoint_meta` includes:

- `checkpoint_id`
- `checkpoint_kind`
- `updated_at`
- `covered_surface_through_seq`
- `session_revision`
- `source_revision`
- `state_hash`
- task evidence coverage where applicable

Coverage is a high-water mark over the active model surface, not a claim that raw session events were deleted.

## 3. Context-pressure gate

The host uses DSH token-meter/canonical session-surface measurement when available. The generic UI token badge is not the policy sensor.

```text
safe_headroom =
    context_window
  - estimated_next_input
  - completion_reserve
  - compression_recovery_reserve
  - safety_margin
```

Default v0.7 policy for the qualified 131072-token local runtime:

```text
context_window                        131072
completion_reserve_tokens             16384
compression_recovery_reserve_tokens    8192
safety_margin_tokens                    4096
soft_headroom_tokens                   24576
hard_headroom_tokens                    4096
hysteresis_tokens                       4096
min_recent_turns                           3
max_recent_tokens                      24000
```

All values are runtime-policy fields and must be empirically qualified; the architecture is not hard-coded to a specific 90K/105K prompt threshold.

Pressure states:

- `NORMAL`
- `SOFT_PRESSURE`
- `COMPACTION_REQUIRED`
- `UNKNOWN` if canonical measurement is unavailable

At SOFT pressure the host injects one deterministic DSH context notice per pressure episode. This does not consume a separate inference solely to phrase the warning. Hysteresis re-arms the warning only after recovery.

At COMPACTION_REQUIRED a normal top-level model request is rejected before llama context overflow. Recovery/inspection commands remain usable.

## 4. `/context`

`/context` is deterministic and model-free. It reports:

- context window
- estimated active/next input surface
- completion reserve
- compression recovery reserve
- safety margin
- safe headroom
- pressure state

`/status` includes the same pressure block plus whether a covered compaction prefix is currently available.

## 5. Structured `/compress`

Stock free-form `compaction-basic` and stock `/compact` are deliberately absent from the qwen-v4 preset. They must not become a second semantic source of truth.

`/compress` is a host-owned active-surface operation:

1. read the latest committed `WORKING_STATE` and coverage high-water mark;
2. measure the current tokenized surface;
3. identify only a contiguous covered prefix composed of completed turns;
4. retain at least the configured recent completed turns verbatim;
5. never prune uncovered/current/incomplete material;
6. build one structured compaction snapshot containing the committed state and archive/source event references;
7. verify session revision and checkpoint id/state hash immediately before replacement;
8. atomically append a DSH surface replacement;
9. leave the raw append-only session log intact;
10. report before/after estimates.

`/compress --dry-run` performs planning and reports the candidate without changing the surface.

If recent whole-turn integrity causes the retained window to exceed `max_recent_tokens`, v0.7 keeps the whole turns and reports the advisory cap overrun rather than splitting a turn/tool pair unsafely.

Compaction is refused while a project operation or `/work` task is active. The active task must checkpoint/pause/finish first.

## 5.1 Natural-language command-plane routing

Slash syntax is an explicit escape hatch, not the only supported interface. The existing conservative phrase router also recognizes the new context operations.

Read-only examples routed directly to `/context` include `сколько контекста осталось?`, `покажи состояние контекста`, and `show context`. Because this operation is model-free and non-mutating, narrowly defined question forms are allowed.

Mutation is stricter. Imperatives such as `сожми контекст`, `освободи контекст`, or `compress history` route to `/compress`; phrases such as `покажи что будет сжато` or `preview context compression` route to `/compress --dry-run`. Questions (`можно сжать контекст?`), negations (`не сжимай контекст`), hypotheticals, quoted examples, and explanatory discussion never auto-run compaction.

When the host has emitted a SOFT-pressure compression offer, an ephemeral `compression_offer` state is armed. Only during that episode may a short acknowledgement such as `да`, `окей`, or `сжимай` mean `/compress`. Without that host offer the same acknowledgement is ordinary chat. A successful non-dry-run compression clears the offer. Explicit/natural compression routing executes in the command plane before the universal HARD-pressure model gate, so it remains usable as a recovery path when normal inference is blocked.

## 6. Budget accounting

v0.6 exact-cap fixes remain in force. `state_checkpoint` and `task_checkpoint` are protocol tools and do not consume the ordinary **per-turn tool-call** anti-runaway counter. Their real DSH events/tokens still exist and remain visible to absolute/session/task accounting where the underlying DSH exposes them.

Finalization receives its own request cap (`4096` tokens default) and reasoning effort (`off` default). v0.7 does not claim complete provider-level separation of every protocol token from the global DSH counters until live qualification proves the installed 0.1.1-rc.1 accounting surface.

## 7. Authority boundaries

Universal conversation checkpointing cannot:

- create or supersede `ACTIVE_REQUIREMENTS`;
- alter source authority or source revision;
- forge acceptance truth;
- overwrite host-owned failed-hypothesis or open-acceptance state;
- bypass `/triage`, `/review`, or `/accept` policy.

An active task owned by another session blocks universal conversation state mutation fail-closed.

## 8. Local-only composition

The v0.6 local-only hardening remains:

- default agent model pinned to `llama-local/qwen3.8-27b`;
- `session-title-llm` disabled;
- `web-search-deepseek` disabled;
- `llm-deepseek` disabled;
- session telemetry plugin disabled;
- qwen-v4 preset exposes no web tool by default.

## 9. Runtime baseline

Qualified target-machine llama baseline remains:

- llama.cpp build 10566 / commit `bb4caa754`
- custom CUDA FlashAttention all-quants build
- Qwen3.8-27B Q4_K_M
- context 131072
- split `4,1`
- KV `q8_0/q5_1`
- FlashAttention on
- fit off
- reasoning medium / 6144 block budget
- historical reasoning preservation off

## 10. Qualification status

Package-level tests are required before shipping. The following are **live acceptance items**, not claims made by static tests:

- installed DSH 0.1.1-rc.1 hook compatibility for universal turn continuation;
- real `state_checkpoint -> WORKING_STATE -> finalization reinjection` wire trace;
- no historical reasoning in the final rendered Qwen prompt;
- actual SOFT/HARD pressure behavior using installed token-meter;
- actual surface replacement and post-compression token reduction;
- user-visible handling of invalid primary provisional text/streaming.
