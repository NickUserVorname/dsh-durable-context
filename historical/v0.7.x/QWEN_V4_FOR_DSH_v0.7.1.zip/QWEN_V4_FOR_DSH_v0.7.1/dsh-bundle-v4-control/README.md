# local-dsh-v4-control 0.7.1

Host-owned control bundle for QWEN-V4-FOR-DSH.

The bundle keeps DSH in control of source authority, task lifecycle, budgets, evidence, checkpoints and acceptance. v0.7 adds universal commit-before-answer and structured active-context compaction without introducing a second semantic memory table.

Important model-facing tools:

- `state_checkpoint` — ordinary top-level turn durable commit before finalization;
- `task_checkpoint` — active `/work` evidence-aware checkpoint;
- task terminal/scope/hypothesis tools from the existing worker protocol.

Important human commands:

- `/status`
- `/context`
- `/compress [--dry-run]`
- `/triage`, `/task`, `/work`, `/review`, `/accept`, `/phase`

`WORKING_STATE.json` remains the canonical distilled semantic state. Raw historical reasoning is not durable memory.

The qwen-v4 preset deliberately does not activate stock free-form DSH compaction. v0.7 `/compress` shadows only checkpoint-covered completed-turn history while the append-only raw session remains available for audit/recovery.
