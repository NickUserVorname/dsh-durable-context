param(
  [int]$Port = 8080,
  [int]$Context = 131072,
  [string]$TensorSplit = "4,1",
  [ValidateSet("low","medium","xhigh")][string]$ReasoningEffort = "medium",
  [int]$ReasoningBudget = 6144
)

$ErrorActionPreference = "Stop"

$Root   = "C:\DSH-QWEN"
$Cuda   = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.9"
$Server = "$Root\llama-custom_GGML_CUDA_FA_ALL_QUANTS=ON\llama-server.exe"
$Model  = "$Root\models\Qwen3.8-27B-UD-Q4_K_M.gguf"
$Work   = Split-Path -Parent $Server

foreach ($p in @($Server,$Model,"$Cuda\bin\cudart64_12.dll","$Cuda\bin\cublas64_12.dll","$Cuda\bin\cublasLt64_12.dll")) {
  if (!(Test-Path -LiteralPath $p)) { throw "Required path not found: $p" }
}

$env:CUDA_PATH = $Cuda
if (($env:Path -split ';') -notcontains "$Cuda\bin") { $env:Path = "$Cuda\bin;$env:Path" }
Remove-Item Env:CUDA_SCALE_LAUNCH_QUEUES -ErrorAction SilentlyContinue
$env:LLAMA_LOCAL_API_KEY = "local"

Write-Host "===== CUSTOM LLAMA ====="
& $Server --version
if ($LASTEXITCODE -ne 0) { throw "llama-server --version failed" }

$DeviceText = (& $Server --list-devices 2>&1 | Out-String)
Write-Host $DeviceText
if ($LASTEXITCODE -ne 0) { throw "llama-server --list-devices failed" }
if ($DeviceText -notmatch 'CUDA0:\s+Tesla V100-SXM2-16GB') { throw "Expected llama CUDA0 = Tesla V100-SXM2-16GB" }
if ($DeviceText -notmatch 'CUDA1:\s+NVIDIA GeForce RTX 3070 Ti') { throw "Expected llama CUDA1 = NVIDIA GeForce RTX 3070 Ti" }

$Listener = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue
if ($Listener) { throw "Port $Port is already listening (PID $($Listener[0].OwningProcess)). Stop the old server first." }

$ServerArgs = @(
  "-m", $Model,
  "--alias", "qwen3.8-27b",
  "--device", "CUDA0,CUDA1",
  "--n-gpu-layers", "all",
  "--split-mode", "layer",
  "--tensor-split", $TensorSplit,
  "--ctx-size", "$Context",
  "--parallel", "1",
  "--cache-type-k", "q8_0",
  "--cache-type-v", "q5_1",
  "--flash-attn", "on",
  "--fit", "off",
  "--jinja",
  "--reasoning", "on",
  "--reasoning-effort", $ReasoningEffort,
  "--reasoning-budget", "$ReasoningBudget",
  "--reasoning-budget-message", "Reasoning budget reached. Use established evidence, persist useful state, then act or return a concise blocked handoff.",
  "--no-reasoning-preserve",
  "--reasoning-format", "deepseek",
  "--metrics",
  "--api-key", "local",
  "--host", "127.0.0.1",
  "--port", "$Port"
)

Write-Host "===== TARGET PROFILE ====="
Write-Host "context=$Context split=$TensorSplit K=q8_0 V=q5_1 FA=on fit=off reasoning=$ReasoningEffort budget=$ReasoningBudget auth=local port=$Port"
Write-Host "This launcher stays in the foreground. Ctrl+C stops llama-server."

Push-Location $Work
try {
  & $Server @ServerArgs
  $code = $LASTEXITCODE
  if ($code -ne 0) { throw "llama-server exited with code $code" }
}
finally { Pop-Location }
