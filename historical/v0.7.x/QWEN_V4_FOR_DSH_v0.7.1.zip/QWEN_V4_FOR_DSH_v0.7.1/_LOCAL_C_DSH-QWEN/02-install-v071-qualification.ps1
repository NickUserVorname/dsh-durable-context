param(
  [string]$QualificationProject = "C:\DSH-QWEN\qualification-v071",
  [switch]$MergeExistingQualificationProject
)

$ErrorActionPreference = "Stop"
$Root        = "C:\DSH-QWEN"
$DshHome     = "$Root\dsh-home"
$DshRuntime  = "$Root\runtime\dsh"
$NodeRuntime = "$Root\runtime\node"
$DshCmd      = "$DshRuntime\node_modules\.bin\dsh.cmd"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$UpstreamInstaller = Join-Path $PackageRoot "INSTALL_V0_7_WINDOWS.ps1"
$SettingsSnippet    = Join-Path $PackageRoot "dsh-settings\llama-local.settings.example.yaml"
$LocalLauncher      = Join-Path $PSScriptRoot "01-start-qwen38-128k.ps1"

foreach ($p in @($DshHome,$DshRuntime,$NodeRuntime,$DshCmd,$UpstreamInstaller,$SettingsSnippet,$LocalLauncher)) {
  if (!(Test-Path -LiteralPath $p)) { throw "Required path not found: $p" }
}
if (!(Test-Path -LiteralPath "$NodeRuntime\pnpm.cmd")) {
  throw "Portable pnpm is required at $NodeRuntime\pnpm.cmd. Install it with: & '$NodeRuntime\npm.cmd' install --global --prefix '$NodeRuntime' pnpm@11.7.0 --no-audit --no-fund"
}

$env:DSH_HOME = $DshHome
$env:LLAMA_LOCAL_API_KEY = "local"
$env:DSH_TELEMETRY_MODE = "DISABLED"
$env:DEEPSEEK_API_KEY = ""
$env:Path = "$NodeRuntime;$DshRuntime\node_modules\.bin;$env:Path"

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Backup = "$Root\backups\v071-install-$stamp"
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
if (Test-Path "$DshHome\settings.yaml") { Copy-Item "$DshHome\settings.yaml" "$Backup\settings.yaml.before" -Force }
if (Test-Path "$DshHome\profiles\web") { Copy-Item "$DshHome\profiles\web" "$Backup\web-profile.before" -Recurse -Force }
Write-Host "Backup created: $Backup"

if (!(Test-Path -LiteralPath $QualificationProject)) { New-Item -ItemType Directory -Force -Path $QualificationProject | Out-Null }
if (!(Test-Path -LiteralPath (Join-Path $QualificationProject ".git"))) {
  & git -C $QualificationProject init
  if ($LASTEXITCODE -ne 0) { throw "git init failed" }
  & git -C $QualificationProject config user.email "dsh-qualification@localhost"
  & git -C $QualificationProject config user.name "DSH Qualification"
  [System.IO.File]::WriteAllText((Join-Path $QualificationProject "README.md"), "# DSH v0.7.1 qualification project`r`n", (New-Object System.Text.UTF8Encoding($false)))
  & git -C $QualificationProject add README.md
  & git -C $QualificationProject commit -m "qualification baseline"
  if ($LASTEXITCODE -ne 0) { throw "qualification baseline commit failed" }
}

$ExistingPolicy = if ($MergeExistingQualificationProject) { "MergeMissing" } else { "Stop" }
Write-Host "===== INSTALL HOST BUNDLE + PRESET + PROJECT PACK ====="
& $UpstreamInstaller -ProjectRoot $QualificationProject -DshCommand $DshCmd -DshHome $DshHome -ExistingProjectPolicy $ExistingPolicy
if ($LASTEXITCODE -ne 0) { throw "Upstream installer failed: $LASTEXITCODE" }

$SettingsPath = Join-Path $DshHome "settings.yaml"
if (!(Test-Path -LiteralPath $SettingsPath)) { New-Item -ItemType File -Path $SettingsPath -Force | Out-Null }
$Current = Get-Content -LiteralPath $SettingsPath -Raw
if ($Current -match '(?m)^llm-pi-ai\s*:') {
  if ($Current -notmatch '(?m)^\s{4}llama-local\s*:') { throw "settings.yaml already has llm-pi-ai but no llama-local. Refusing unsafe text merge. Backup: $Backup" }
  $Normalized = $Current.Replace('baseURL: http://127.0.0.1:8082/v1','baseURL: http://127.0.0.1:8080/v1')
  if ($Normalized -ne $Current) {
    [System.IO.File]::WriteAllText($SettingsPath, $Normalized, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "llama-local baseURL restored from wire proxy 8082 to canonical 8080."
  } else { Write-Host "llama-local already present in settings.yaml; leaving it unchanged." }
} else {
  $Snippet = Get-Content -LiteralPath $SettingsSnippet -Raw
  $Combined = $Current
  if ($Combined.Length -gt 0 -and -not $Combined.EndsWith("`n")) { $Combined += "`r`n" }
  $Combined += "`r`n" + $Snippet
  [System.IO.File]::WriteAllText($SettingsPath, $Combined, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host "llama-local provider appended to: $SettingsPath"
}

Copy-Item -LiteralPath $LocalLauncher -Destination "$Root\start-qwen38-128k.ps1" -Force
@'
@echo off
setlocal
set "DSH_HOME=C:\DSH-QWEN\dsh-home"
set "LLAMA_LOCAL_API_KEY=local"
set "DSH_TELEMETRY_MODE=DISABLED"
set "DEEPSEEK_API_KEY="
call "C:\DSH-QWEN\start-dsh.cmd" %*
endlocal
'@ | Set-Content "$Root\start-dsh-qwen.cmd" -Encoding ASCII

Write-Host "===== DUMP CONFIG ====="
$Dump = "$Root\dump-config-v071.txt"
& $DshCmd --profile web --dump-config 2>&1 | Tee-Object -FilePath $Dump
if ($LASTEXITCODE -ne 0) { throw "dsh --dump-config failed: $LASTEXITCODE" }
$DumpRaw = Get-Content $Dump -Raw
foreach ($Pattern in @('local-v4-control','provider:\s*llama-local','model:\s*qwen3.8-27b')) {
  if ($DumpRaw -notmatch $Pattern) { throw "Required v0.7 config not visible in dump-config: $Pattern" }
}
foreach ($Id in @('session-title-llm','web-search-deepseek','llm-deepseek','session-telemetry-otel')) {
  if ($DumpRaw -notmatch "(?s)- id: $([regex]::Escape($Id)).{0,500}?disabled: true") { throw "Local-only row is not disabled in dump-config: $Id" }
}

Write-Host ""
Write-Host "INSTALLATION LAYER PASS - v0.7.1"
Write-Host "Qualification project: $QualificationProject"
Write-Host "Backup:               $Backup"
Write-Host "Dump:                 $Dump"
Write-Host "NEXT: start $Root\start-qwen38-128k.ps1, run 03-verify-live.ps1, then launch DSH on $QualificationProject"
