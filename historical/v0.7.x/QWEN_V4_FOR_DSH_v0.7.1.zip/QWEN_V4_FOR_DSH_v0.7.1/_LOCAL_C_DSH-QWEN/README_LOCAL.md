# C:\DSH-QWEN v0.7.1 overlay

This overlay targets the already-qualified machine layout:

- custom llama.cpp: `C:\DSH-QWEN\llama-custom_GGML_CUDA_FA_ALL_QUANTS=ON`
- CUDA 12.9
- llama CUDA0 = V100 16GB, CUDA1 = RTX 3070 Ti 8GB
- Qwen3.8-27B Q4_K_M
- context 131072, split 4:1, K=q8_0, V=q5_1, FlashAttention=on, fit=off
- reasoning medium / 6144 per reasoning block
- local API key `local`

Install into a fresh qualification repo with `02-install-v071-qualification.ps1`, then start the model and run `03-verify-live.ps1`.

v0.7 keeps local-only route hardening and adds universal commit-before-answer plus the host-owned context-pressure `/context` + `/compress` path. The static package does not claim those new DSH hook/surface paths are live-qualified until you run the v0.7 session tests.
