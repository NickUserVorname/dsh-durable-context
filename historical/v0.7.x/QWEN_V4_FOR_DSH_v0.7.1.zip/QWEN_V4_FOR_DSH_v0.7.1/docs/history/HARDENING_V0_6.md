# QWEN-V4-FOR-DSH v0.6.0 hardening

v0.6.0 is a corrective release over the frozen v0.2 architecture. It does not move goal ownership, budgets, source authority, task state, or acceptance into the model.

## H1 — fresh-role structured output is part of the read-only role surface

A fresh role started with `outputSchema` receives DSH's scoped `structured_output` tool. v0.2.5 exposed that tool to the model but the host role guard allowed only `read/grep/glob`, so a correct terminal call was rejected with `ROLE_TOOL_DENIED`.

v0.6.0 allows `read`, `grep`, `glob`, and `structured_output` for all fresh roles. `write`, `edit`, `pwsh`, `bash`, `task_checkpoint`, and other worker mutation/control tools remain unavailable to those roles.

## H2 — exact-cap budget semantics

Budget predicates are no longer reused across incompatible phases.

- **Exhausted/start predicate:** `>=`. If completed usage is already exactly at a hard ceiling, new work cannot start.
- **Pre-step predicate:** the current `step/start` is already present in DSH events, therefore `model_requests > max` rejects the first request beyond the cap while request `N/N` is admitted. Other completed dimensions remain exhausted at equality.
- **Post-run predicate:** `>`. A role/task that successfully finishes exactly at the configured ceiling is valid; only actual overshoot fails.

This applies to both role-local budgets and the task-global ledger.

## H3 — validation reserve request boundary

With the default 30-request task budget and 8-request validation reserve, worker request 22 is the last admissible worker request. Because `step/start` already counted that current request, pre-step admits usage `22` and rejects `23`. Starting a new worker epoch when completed usage is already `22` remains blocked so the reserve is protected.

## H4 — Windows JSON encoding

Windows PowerShell 5.1 `Set-Content -Encoding UTF8` writes a UTF-8 BOM. Node `JSON.parse(fs.readFileSync(file, 'utf8'))` does not strip U+FEFF. The v0.6.0 installer writes `RUNTIME_POLICY.json` through `System.Text.UTF8Encoding($false)` / `File.WriteAllText` and package validation rejects BOM-prefixed JSON.

## H5 — critical guards fail closed

For a controlled project (`.dsh/project/state.json` present), internal failures in safety enforcement are no longer logged-and-ignored. v0.6.0 rejects/cancels model continuation and, when an active worker can be resolved, records a `BLOCKED_QUALIFICATION` host-guard failure. Covered paths include:

- main `agent/pre-step` budget / validation-reserve / checkpoint-injection enforcement;
- checkpoint cadence persistence;
- turn-stop checkpoint / starvation / goal-cap enforcement;
- checkpoint-required tool guard evaluation;
- tool-result evidence and post-shell scope verification.

Sessions outside a QWEN-V4 controlled project are not converted into fail-closed project sessions merely because the bundle is installed globally.

## H6 — local-only composition

The bundle is applied after the stock base/web bundles and overrides the stock rows by id:

- `agent-default-model` -> `llama-local / qwen3.8-27b`;
- `session-title-llm` -> disabled;
- `web-search-deepseek` -> disabled;
- `llm-deepseek` -> disabled;
- `session-telemetry-otel` -> disabled.

The `qwen-v4` preset still omits the web tool. The target-machine launcher additionally clears `DEEPSEEK_API_KEY`, pins `DSH_TELEMETRY_MODE=DISABLED`, and uses local llama API authentication.

## H7 — v0.6.0 fresh-role budgets

| Role | model requests | reasoning tokens | visible output | tools | active minutes |
| --- | ---: | ---: | ---: | ---: | ---: |
| SOURCE_CURATOR | 6 | 16000 | 6000 | 16 | 10 |
| TASK_PLANNER | 6 | 20000 | 6000 | 16 | 10 |
| TEST_ANALYST | 4 | 12000 | 5000 | 12 | 10 |
| REVIEWER | 4 | 12000 | 5000 | 12 | 10 |
| ACCEPTANCE_AUDITOR | 3 | 8000 | 3000 | 6 | 5 |

These counters are not the same as the token total shown on a DSH subagent card. Large project reads increase input/context tokens without necessarily consuming the reasoning-token budget.

## H8 — retained architecture

All previous host-owned controls remain: source revision, atomic task packet, disposable Git worktree, write-set guard, process lock, deterministic qualification, mandatory TEST_ANALYST, independent review/acceptance, typed evidence, checkpoint barrier, bounded goal rounds, task-wide budget, validation reserve, and externalized `WORKING_STATE` memory. Raw hidden reasoning is still intentionally non-durable.

## Qualification target

v0.6.0 adds regression tests for structured-output admission, exact-cap role/global/reserve semantics, local-only Cordis overrides, PowerShell no-BOM output, and fail-closed controlled-project guard failures. Live DSH qualification remains required before an important repository is trusted.
