import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { ensureProject, initialState, saveState, saveTask, loadTask } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-cp-'));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.writeFileSync(path.join(root,'a.txt'),'a\n');git(root,'add','-A');git(root,'commit','-m','base')
const paths=ensureProject(root);const state=initialState();state.source_revision=1;state.active_task_id='T1';state.task_state='IN_PROGRESS';state.worker_session_id='S';saveState(paths,state)
const task={schema_version:3,id:'T1',source_revision:1,objective:'x',write_set:['a.txt'],acceptance:['x'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{failed_hypotheses:[],worktree:root,baseline_commit:'x',usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:'S',epoch_start_seq:0,steps_since_checkpoint:1,meaningful_since_checkpoint:1,checkpoint_required:false,pending_evidence:[{id:'EV-00001',tool:'read',outcome:'OK'}],evidence_seq:1,token_accounting:{entries:{},latest_mode:'uninitialized'}}};saveTask(paths,task)
const hooks=new Map(),guards=[],tools=new Map(),commands=new Map();const agent={id:'A',session:{id:'S',header:{cwd:root},events:[],seq:0},cancel(){}}
const ctx={logger:{warn(){}},agents:{get(id){return id==='S'?agent:undefined}},on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)}},goals:{get(){return {id:'g',revision:1,phase:'active',activation:'armed',roundsStarted:1,maxGoalRounds:6}},block(){},complete(){},clear(){},create(){throw new Error('n/a')}},subagents:{async start(){throw new Error('n/a')}}}
apply(ctx,{checkpointEverySteps:3,tokenizerEndpoint:''})
const pre=(hooks.get('agent/pre-step')??[]).at(-2)
const goalMsg={id:'goalmsg',role:'user',content:[{type:'text',text:'round'}],source:{kind:'goal',goalId:'g',revision:1,round:2}}
const decision=await pre({agent,messages:[goalMsg],turn:2,step:1},async()=>({kind:'enter',messages:[goalMsg]}))
assert.equal(decision.kind,'enter');assert.equal(decision.messages[0].source.kind,'plugin');assert.match(decision.messages[0].content[0].text,/CHECKPOINT BARRIER ACTIVE/)
let saved=loadTask(paths,'T1');assert.equal(saved.execution.checkpoint_required,true)
const readExec={name:'read',arguments:{file_path:path.join(root,'a.txt')},agent}
assert.match(guards[0](readExec),/CHECKPOINT_REQUIRED_BEFORE_CONTINUATION/)
const cp=tools.get('task_checkpoint')
const result=await cp.execute({mode:'merge',covered_evidence_ids:['EV-00001'],known:['k'],decisions:[],evidence:['e'],do_not_repeat:[],next_action:['n']},{agent})
assert.equal(result.checkpoint_barrier_cleared,true)
saved=loadTask(paths,'T1');assert.equal(saved.execution.checkpoint_required,false);assert.equal(saved.execution.meaningful_since_checkpoint,0)
assert.equal(guards[0](readExec),undefined)
console.log('checkpoint-barrier.mock.test.mjs: PASS')
