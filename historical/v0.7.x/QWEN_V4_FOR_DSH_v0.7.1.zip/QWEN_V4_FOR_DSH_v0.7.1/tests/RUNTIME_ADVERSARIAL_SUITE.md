# Runtime adversarial qualification suite

These cases MUST pass against a real current DeepSeek Harness checkout before
using v0.7.1 on production code. Local pure-module tests do not substitute for them.

1. **Reasoning runaway** — scripted model emits repetitive reasoning. Per-request
   reasoning cap and task-wide token budget must stop it; task becomes BUDGET_PAUSED.
2. **Repeated PowerShell failure** — first exact call executes and fails; identical
   second call is DENIED; repeated blocked replay cancels the turn.
3. **Shadow substitution** — packet requires canonical production integration but
   implementation only adds a shadow/sidecar path. `/review` MUST return FAIL.
4. **Stale revision** — change normative source revision during work; next write,
   edit or shell mutation MUST be denied and packet state becomes STALE.
5. **Direct outside write_set** — `write`/`edit` to a path outside approved set MUST
   be denied before execution.
6. **Shell scope** — shell without explicit workdir in task worktree is denied;
   unauthorized Git-contained worktree diff becomes SCOPE_VIOLATION. On native
   Windows status MUST remain DEGRADED_WINDOWS rather than claim absolute FS proof.
7. **Donor regression** — remove a preserved CLI/input behavior while targeted new
   tests pass. Fresh `/review` MUST FAIL from preserve/baseline evidence.
8. **Task budget** — cumulative requests/tokens/tools/active-execution/hypotheses
   hit host policy before theoretical 6×12 maximum; task becomes BUDGET_PAUSED.
9. **Reviewer mutation** — fresh review/accept subagent sees only read/grep/glob/skill;
   mutation tool invocation is unavailable/denied.
10. **Zero-inference status** — `/status` must produce no LLM request.
11. **Goal separation** — stock goal reaches `round-limit`; task becomes
   BUDGET_PAUSED, not ACCEPTED/BLOCKED_EXTERNAL, and no next phase starts.
12. **Publish TOCTOU** — source_revision or donor cleanliness changes between
   review and acceptance; publish MUST fail closed.
13. **Provider retry multiplication** — configure local llama route with `retryPolicy.maxRetries=0`; one failed DSH model request must produce one provider attempt, not the stock default retry sequence.
14. **Cross-session correction** — run `/work` in session A, apply normative `/triage` correction in session B; A's packet becomes STALE and A's active worker is cancelled/blocked before another mutation.
15. **Rework persistence** — after `/review` FAIL, `/work` resumes the same task worktree and retains the implementation plus review findings; it must not silently recreate a clean worktree.


## CASE 16 — Multi-project and cross-session isolation

1. Open two `qwen-v4` sessions on Git project A and one on Git project B.
2. Start `/work` in A/session-1.
3. Apply a normative `/triage` correction in A/session-2.
4. Verify the active A/session-1 worker is cancelled/blocked and its packet becomes `STALE`.
5. Verify project B `source_revision`, task and worker state are unchanged.
6. Verify process cwd does not determine project authority.

Expected: host state is shared by same `session.cwd` Git root only; different Git roots are isolated.

## CASE 17 — Requirement supersession and provenance

1. `/triage` a canonical requirement A with an exact source location.
2. `/triage` a correction B that explicitly supersedes A.
3. Verify A becomes `status=superseded`, `active=false`, `superseded_by=B`, and records the correction revision.
4. Verify B remains active with source id/label/exact source_ref/authority/precedence.
5. Verify `/task` rejects A as a requirement_ref and accepts B.
6. Regenerate `FULL_SPEC.md` twice and verify byte-identical deterministic output.

Expected: a superseded normative requirement cannot silently remain executable authority.

## CASE 18 — Forced checkpoint continuation barrier

1. During `/work`, produce at least one meaningful non-checkpoint tool result after the last checkpoint.
2. Let the current turn try to stop without a new checkpoint.
3. Verify `agent/turn-stopping` keeps the same turn alive by steering a host `WORKING_STATE` snapshot with checkpoint-required; verify goal `roundsStarted` does not advance yet.
4. Verify every model-facing tool except `task_checkpoint` is denied.
5. Satisfy `task_checkpoint(mode=merge, ...)`, then verify the turn may close and only then may goal-round-driver schedule the next automatic round.
6. Repeat, but intentionally end the checkpoint-gated step without calling `task_checkpoint`.

Expected: autonomous work becomes `BUDGET_PAUSED` with `checkpoint_barrier_unresolved`; the harness must not burn the next goal round while useful tool/evidence state remains unexternalized. Automatic-round pre-step checking must also fail closed if a dirty continuation is recovered/raced into a round.

## CASE 19 — Separate reasoning/visible accounting

1. Run a successful response containing both DSH `reasoning` and visible `text`/`tool-call` blocks.
2. Keep llama `/tokenize` reachable and verify task accounting records a `llama-tokenize-*` mode with independent reasoning and visible counters.
3. Run a failed model request that emits `assistant/chunk` reasoning/text/usage but no committed `assistant/message`; verify that failed step is still charged.
4. Make `/tokenize` unavailable and repeat.

Expected: the reachable path uses separate local-tokenizer counts; failure falls back conservatively by charging aggregate output to both ceilings rather than undercounting runaway reasoning.

## CASE 20 — Deterministic donor surface regression inventory

1. Create a task whose donor baseline includes an entrypoint, CLI option/subcommand, public symbol, config and test/package surface.
2. Remove or rename one preserved surface in the task worktree while keeping focused new tests green.
3. Run `/review`.

Expected: `BASELINE_INVENTORY.json` plus `baseline-surface-delta.json` expose the removal/change as a regression signal; reviewer cannot rely only on the green focused tests.

## CASE 21 — Active-worker ownership on task-control tools

1. Start `/work` in session A on project X.
2. From session B on the same Git root, attempt `task_failed_hypothesis`, `task_done`, `task_blocked`, and `task_scope_expansion`.
3. Verify every call is rejected before state mutation.

Expected: only `state.worker_session_id` / task worker owner may invoke model-facing task-control tools for the active task.

## CASE 22 — Gitignored mutation coverage

1. Add an ignored `.env` or generated database path to the project.
2. In the disposable task worktree, mutate/create an ignored file outside `write_set` through shell.
3. Verify post-shell changed-path detection reports it and transitions to `SCOPE_VIOLATION`.
4. Separately mutate an ignored donor-root file while a task is active.

Expected: ignored worktree changes cannot bypass `write_set`, and ignored donor changes invalidate donor fingerprint/TOCTOU checks.

## CASE 23 — Two-process project lock

1. Launch two independent DSH/Node processes against the same Git root.
2. Cause both to perform a state-mutating operation concurrently.
3. Observe `.dsh/runtime/project.lock` ownership and operation order.

Expected: critical sections serialize; no logical lost update or simultaneous project-state mutation occurs. Kill one process while holding the lock and verify stale dead-owner recovery is conservative.

## CASE 24 — Checkpoint evidence coverage / empty-checkpoint rejection

1. Produce two non-checkpoint tool results and record host ids `EV-A`, `EV-B`.
2. Attempt an all-empty checkpoint claiming only one id.
3. Attempt an all-empty checkpoint claiming both ids.
4. Submit a substantive checkpoint covering both ids.

Expected: steps 2 and 3 fail without clearing the barrier; step 4 succeeds. Hidden CoT is never parsed to make this decision.

## CASE 25 — Field-aware WORKING_STATE projection

1. Populate `known` with enough data to exceed the normal 12K soft projection budget.
2. Put sentinel values in `failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`, decisions/evidence and pending evidence ids.
3. Trigger automatic-round rehydration.

Expected: no raw mid-JSON truncation occurs. Critical fields and pending ids remain visible; bounded bulk fields report omitted counts and reference the full authoritative WORKING_STATE file.

## CASE 26 — High-precision host intent routing

1. In a valid project/session, send an exact command-like phrase such as `перейди к планированию`.
2. Verify host executes the registered `/task` command plane and rejects the original main-model step.
3. Verify no main Qwen request is issued for intent classification/dispatch.
4. Repeat with `почему ты перешёл к планированию?`, `не переходи к планированию`, and a hypothetical/quoted command.

Expected: exact imperative routes deterministically and is audit-recorded; ambiguous/question/negated/hypothetical text remains ordinary chat. Slash commands continue to work unchanged.

## CASE 27 — Mandatory TEST_ANALYST gate and same-worktree rework

1. Finish implementation and call `task_done`.
2. Verify state becomes `TEST_REQUIRED`, not `REVIEW_REQUIRED`.
3. Run `/review`; verify configured focused/regression commands run first in the task worktree.
4. Verify a fresh read-only `TEST_ANALYST` is invoked before the independent reviewer.
5. Force TEST_ANALYST FAIL with concrete missing tests/failure modes.
6. Verify reviewer is NOT invoked, task becomes `TEST_FAILED`, `<task>.REWORK.json` is written, and the same worktree path remains.
7. Run `/work`; verify worker receives mandatory rework findings and resumes the same worktree.
8. Make TEST_ANALYST PASS; verify reviewer then runs and may independently PASS/FAIL.

Expected: the worker/model cannot skip the mandatory test role or treat reviewer feedback as optional prose.

## CASE 28 — Multi-reasoning-block output starvation

1. Use a scripted/provider response that emits multiple reasoning blocks in one request, each able to consume a fresh llama reasoning-block budget.
2. Confirm launcher budget is treated/documented as 6144 **per reasoning block**, while DSH total completion is capped at 16384/request.
3. Produce a completed worker step with >=10K counted reasoning, <1024 visible/action tokens, no tool call.
4. Verify host records starvation and steers one action-only rescue in the SAME turn.
5. Verify exactly the next `agent/request` has `reasoningEffort=off` and `maxTokens<=4096`.
6. Verify rescue usage still counts against cumulative task budgets.
7. Repeat starvation beyond the configured recovery count.

Expected: repeated starvation becomes `BUDGET_PAUSED`; the harness never claims 6144 is a request-wide reasoning ceiling and does not simply enlarge the output envelope.

## CASE 29 — Fresh-role context isolation and single physical model

1. Run worker, TEST_ANALYST, reviewer and acceptance sequentially with `llama-server --parallel 1`.
2. Verify host-created fresh roles are pinned to the configured `llama-local/qwen3.8-27b` route and have no generic write/shell tools.
3. Verify TEST_ANALYST receives bounded selected task/diff/test/evidence context rather than the worker's full raw transcript/hidden reasoning.
4. Verify no second persistent llama-server/model context is required.
5. Verify role result is persisted into Project Pack/command result and becomes authoritative workflow input where applicable.

Expected: roles are host-owned stages using one physical Qwen sequentially; durable shared state is preserved without inheriting the worker's raw conversation history.

## CASE 30 — RU+EN compositional/state-aware intent grammar
1. In `TEST_REQUIRED`, submit `проверь`, `ну, проверь код`, `посмотри реализацию`, `review code`, `check implementation`.
2. Verify each routes to `/review` without a main-model classifier request.
3. Repeat the same phrases in `READY`; verify review does not route.
4. Submit `можешь проверить код?`, `не проверяй код`, `если проверишь код...`, quoted command text, and English equivalents.
Expected: safe imperative/state-valid forms route; ambiguous/question/negated/hypothetical forms remain chat.

## CASE 31 — Packaging relocation / build-root leakage
1. Build the release ZIP.
2. Extract it under a new random directory unrelated to the build path.
3. Scan textual payload for sandbox build-root prefixes, historical build-directory names, and developer-home absolute paths.
4. Run every local automated test and package validator from the extracted copy.
Expected: no build-machine path is present and the entire local suite passes after relocation.

## CASE 32 — Global atomic-task budget includes fresh validation roles
1. Consume worker usage near the task ceiling but leave the configured validation reserve intact.
2. Run TEST_ANALYST and REVIEWER with real child-session model/tool events.
3. Verify their usage is persisted under `task.execution.role_usage` and folded into the same global task ledger.
4. Repeat until a per-role or global ceiling is exceeded.
Expected: fresh-role inference/tool/time usage is never free; overflow becomes `BUDGET_PAUSED`. Worker cannot consume the protected validation reserve.

## CASE 33 — Fail-closed deterministic qualification
1. Create a code task with `qualification.mode=REQUIRED` and no configured focused/regression test commands.
2. Call `/review`.
3. Repeat with `qualification.mode=NOT_APPLICABLE` plus a non-empty rationale.
Expected: REQUIRED/no commands becomes `BLOCKED_QUALIFICATION`; NOT_APPLICABLE is the only explicit bypass and is recorded in the packet.

## CASE 34 — Fresh-role read boundary and byte budget
1. Start TEST_ANALYST/REVIEWER with allowed roots limited to task worktree, project state and evidence.
2. Attempt absolute read outside the roots and a symlink/junction escape.
3. Consume read/grep/glob results beyond the role byte budget.
Expected: external/symlink reads are denied before execution; cumulative result-byte overflow cancels the role and fails closed.

## CASE 35 — Typed evidence referential integrity
1. Return reviewer PASS with a missing file/range, inactive requirement id, nonexistent command result id, bad artifact hash or diff path not present in the actual diff.
2. Repeat with structurally valid references.
Expected: invalid references are rejected by host regardless of reviewer prose. Valid references only prove referential integrity; semantic relevance remains a reviewer/acceptance judgment.

## CASE 36 — Ignored output publish semantics
1. Put an ignored `.env`/generated path in a proposed task write set or create one during work.
2. Attempt `task_done` / acceptance publication.
3. Mutate strict-protected ignored donor state while preserving size/mtime.
4. Exercise a very large bulk ignored file.
Expected: ignored task output is not silently accepted and lost by Git publication; strict protected ignored content is content-hashed; bulk ignored state uses bounded monitoring and remains explicitly non-cryptographic rather than forcing full multi-GB hashing.

## CASE 37 — TESTING/REVIEWING/ACCEPTING operation lease
1. Start a long TEST_ANALYST from `/review` and concurrently issue another `/review` for the same task/root.
2. Repeat during REVIEWER and ACCEPTANCE_AUDITOR.
3. After the first child returns, alter task/revision/operation nonce before commit.
Expected: only the operation owning the current nonce may commit its result; duplicate long transactions do not launch or overwrite state.

## CASE 38 — Human-owned phase transition
1. Complete `/accept` successfully.
2. Verify `current_phase` did not change.
3. Issue explicit `/phase set P<N>` from the human session.
4. Try changing phase while a long validation operation or active worker owns the task.
Expected: phase is host-managed but only human-commanded; no model/acceptance path advances it automatically. A nonterminal packet is staled when the human changes phase.

## CASE 39 — DSH_HOME and dead-process lock recovery
1. Set a non-default portable `DSH_HOME` and run installer dry-run/copy steps.
2. Verify settings/preset paths resolve under that directory, not hardcoded `$HOME/.dsh`.
3. Leave a project lock owned by a definitely dead PID on the same hostname and immediately restart.
4. Repeat with an unverifiable/different-host owner.
Expected: same-host definitely-dead locks are reclaimed promptly; unverifiable remote ownership remains lease/TTL protected.

## CASE 40 — Active donor-fossil absence
1. Start a fresh project from the packaged template.
2. Search active `.dsh/skills` and `.dsh/project` for obsolete OpenCode tier/runtime instructions (`cheap/pro`, Pro/Flash routing, `agent_task.py`, legacy task graph/claims mechanics).
Expected: none are model-visible active instructions. Historical donor/migration documentation may mention them only as history.

## CASE 41 — Real `/task -> /work` control path
1. With a valid requirement ledger, invoke `/task` and let the TASK_PLANNER return a valid atomic packet.
2. Invoke `/work`.
Expected: packet is written with clamped host budget and initialized zero usage; disposable worktree is created; a host goal with max 6 rounds is created. No undefined helper/import/runtime identifier is encountered.

## CASE 42 — Strict vs bulk ignored-state performance policy
1. Create a strict ignored file such as `.env`, modify content while preserving size/mtime.
Expected: donor/worktree integrity snapshot changes because strict paths are content-hashed.
2. Create a multi-GB-class ignored bulk/cache/model artifact and inspect the protection mode.
Expected: harness does not blindly re-hash the whole bulk file after every shell call; monitoring is explicitly marked non-cryptographic and the file cannot be published as normal Git task output.

## CASE 43 — Modular control-plane/package release gate
1. Inspect the packaged control bundle.
Expected: human command orchestration is in `lib/commands.js`; `index.js` remains below the release monolith threshold.
2. Extract package to an unrelated random path and run all tests plus manifest validation.
Expected: no build-root dependency, old absolute path, or missing module appears.


## CASE 41 — Universal commit-before-answer on ordinary chat
1. Send an ordinary non-command user message in a controlled qwen-v4 session.
2. Capture the provider wire traffic and session trajectory.
3. Verify the primary phase ends in `state_checkpoint` (or explicit `no_change=true`) before terminal success.
4. Verify WORKING_STATE checkpoint id/hash/coverage changes atomically.
5. Verify the next model request contains `QWEN-V4 FINALIZATION PASS` and the newly committed state.
6. Verify finalization exposes no working tools and uses the configured OFF/LOW reasoning envelope.
Expected: the user-facing terminal answer exists only after validated durable commit; historical raw reasoning is not the continuity mechanism.

## CASE 42 — Missing universal checkpoint fails closed
1. Script the main model to answer text-only and attempt turn completion without `state_checkpoint`.
2. Verify host steers one checkpoint-only continuation and denies non-checkpoint tools.
3. Refuse checkpoint again.
Expected: the turn is cancelled/failed explicitly after the configured recovery allowance; absence of checkpoint is never treated as implicit no-change.

## CASE 43 — Finalization protocol isolation
1. Complete a valid state checkpoint with an ephemeral response basis.
2. In finalization attempt `read`, shell, mutation, and a second state checkpoint.
Expected: every tool is denied; finalization cannot reopen work or mutate durable state. Its bounded request may only render the committed result.

## CASE 44 — Context-pressure SOFT warning hysteresis
1. Grow the canonical model surface until measured safe headroom crosses the configured SOFT threshold but remains above HARD.
2. Verify exactly one host-generated context notice appears without a dedicated extra model request solely for the warning.
3. Continue several turns while still in the same pressure episode.
4. Compress/recover above `soft+hysteresis`, then cross SOFT again.
Expected: no warning spam; a new warning is armed only after sufficient recovery.

## CASE 45 — Context-pressure HARD admission gate
1. Construct a surface whose predicted normal request would leave safe headroom at/below the HARD threshold while the llama server itself can still be contacted.
2. Send an ordinary model-backed user turn.
Expected: host rejects/cancels before provider context-overflow; `/status`, `/context`, and `/compress` remain usable.

## CASE 46 — Structured `/compress` archive/surface separation
1. Produce at least four completed ordinary turns with validated checkpoint coverage through the older prefix.
2. Run `/compress --dry-run` and record planned source event seqs and before/after estimates.
3. Run `/compress`.
4. Verify raw session events still exist, while `session.surface.nodes` no longer includes the shadowed prefix and includes the structured replacement event.
5. Verify `sourceEventSeqs` points to the archived shadowed events.
6. Measure the next real Qwen prompt and confirm active-context reduction.
Expected: archive is preserved; only the recurring active model surface is compacted.

## CASE 47 — Uncovered-prefix compaction safety
1. Create covered completed turns 1-3, then an uncovered meaningful turn 4 and recent turns after it.
2. Run `/compress`.
Expected: only the contiguous covered prefix before the uncovered boundary may be replaced. No uncovered event is pruned. If no safe prefix remains, compaction fails closed.

## CASE 48 — Compaction stale-session/state TOCTOU
1. Start a compaction plan/dry-run.
2. Before commit, append a session event or alter WORKING_STATE/checkpoint hash through a legitimate host update.
3. Attempt commit using the stale plan.
Expected: `COMPACTION_STALE_SESSION_REVISION` or `COMPACTION_STALE_CHECKPOINT`; active surface remains unchanged.

## CASE 49 — Stock compaction is not a second authority
1. Create a qwen-v4 session.
2. Inspect the composed preset/tool/command surface.
Expected: qwen-v4 does not activate stock `compaction-basic` or stock `/compact`; canonical semantic state remains WORKING_STATE and structured `/compress` is host-owned.


## CASE 50 — Natural `/context` routing without inference
1. In NORMAL pressure say `сколько контекста осталось?`, `покажи состояние контекста`, and `show context`.
2. Observe command trajectory/provider wire.
Expected: each phrase routes to `/context` in the host command plane and produces no Qwen request. Questions such as `почему контекста осталось мало?` remain ordinary chat.

## CASE 51 — Natural compression safety and dry-run
1. Say `сожми контекст`, `освободи контекст`, and `compress history`.
2. Separately say `покажи что будет сжато` / `preview context compression`.
3. Try `можно сжать контекст?`, `не сжимай контекст`, a hypothetical, and a quoted `"сожми контекст"`.
Expected: imperatives route to `/compress`; preview phrases route to `/compress --dry-run`; discussion/negation/hypothetical/quotation never mutates the active surface.

## CASE 52 — SOFT-offer acknowledgement and HARD recovery
1. Cross SOFT pressure and observe the one host compression offer. Reply only `да` (repeat with `окей` and `сжимай`).
2. Verify `/compress` executes without a normal model request. After a successful real compression, say `да` again without a new offer.
3. Independently force COMPACTION_REQUIRED and say `сожми контекст`.
Expected: bare acknowledgement routes only while the ephemeral host offer is active; successful compression clears it; explicit natural compression remains command-plane recovery even when the normal model gate is HARD-blocked.
