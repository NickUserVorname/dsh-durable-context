import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { workflowIntent } from '../dsh-bundle-v4-control/lib/intent-router.js'
import { clearCompressionOffer, compressionOfferActive } from '../dsh-bundle-v4-control/lib/universal-commit.js'
import { ensureProject, initialState, saveState } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){ const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'}); if(r.status!==0) throw new Error(r.stderr||r.stdout); return r.stdout }
function repo(prefix='qv4-v071-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T'); fs.writeFileSync(path.join(root,'README.md'),'x\n'); git(root,'add','-A'); git(root,'commit','-m','base'); ensureProject(root); return root
}

// 1) New host commands have the same natural-language command-plane parity as
//    existing workflow commands. /context is read-only and accepts specific
//    question forms; /compress remains imperative/high precision.
for (const text of [
  'сколько контекста осталось?', 'ну сколько контекста осталось?', 'сколько осталось контекста?',
  'какой остаток контекста?', 'покажи контекст', 'покажи состояние контекста',
  'context status', 'show context', 'how much context is left?',
]) {
  assert.deepEqual(workflowIntent(text,{taskState:'NO_TASK'}),{command:'context',rawInput:'',confidence:'grammar-readonly'},`context route: ${text}`)
}

for (const text of [
  'сожми контекст', 'давай сожми контекст', 'сжимай старую историю', 'освободи контекст',
  'выполни сжатие контекста', 'compress context', 'compact history',
]) {
  assert.equal(workflowIntent(text,{taskState:'NO_TASK'})?.command,'compress',`compress route: ${text}`)
  assert.equal(workflowIntent(text,{taskState:'NO_TASK'})?.rawInput,'')
}

for (const text of [
  'покажи что будет сжато', 'проверь сжатие без изменений', 'предварительно оцени сжатие контекста',
  'сделай dry run сжатия контекста', 'preview context compression', 'dry-run context compaction',
]) {
  assert.deepEqual(workflowIntent(text,{taskState:'NO_TASK'}),{command:'compress',rawInput:'--dry-run',confidence:'grammar-dry-run'},`dry-run route: ${text}`)
}

// 2) Questions, negations, hypotheticals and quoted phrases must not mutate the
//    context surface merely because they mention compression.
for (const text of [
  'можно сжать контекст?', 'стоит ли сжимать контекст?', 'что будет если сжать контекст?',
  'не сжимай контекст', 'почему ты сжал контекст?', '"сожми контекст"',
  'контекста осталось мало - сжимаем контекст?', 'if we compress context what happens?',
]) assert.equal(workflowIntent(text,{taskState:'NO_TASK'}),null,`must stay chat: ${text}`)

// 3) A bare acknowledgement is actionable only while a host-generated SOFT
//    compression offer is active.
for (const text of ['да','ага','ок','окей','давай','сжимай','да, сжимай','окей, сожми']) {
  assert.equal(workflowIntent(text,{taskState:'NO_TASK'}),null,`no offer => no route: ${text}`)
  assert.deepEqual(workflowIntent(text,{taskState:'NO_TASK',compressionOffer:true}),{command:'compress',rawInput:'',confidence:'context-offer'},`active offer route: ${text}`)
}
for (const text of ['нет','не надо','почему?','да?']) assert.equal(workflowIntent(text,{taskState:'NO_TASK',compressionOffer:true}),null)

// 4) Host integration: an explicit natural compression request executes in the
//    command plane before the ordinary model lifecycle can hit HARD pressure.
{
  const root=repo('qv4-v071-hard-recovery-'); const paths=ensureProject(root)
  const state=initialState(); state.task_state='NO_TASK'; saveState(paths,state)
  const pre=[]; const executed=[]
  const ctx={
    logger:{warn(){},error(){}}, agents:{get(){}},
    on(name,fn){if(name==='agent/pre-step')pre.push(fn)},
    tokenMeter:{measure(){return {totalTokens:120000}},estimateMessage(){return 0}},
    tools:{guard(){},register(){}},
    commands:{register(){},async execute(_agent,line){executed.push(line);return {commandId:'c',result:{kind:'success',text:'compressed'}}}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(){throw new Error('n/a')}}, sessions:{},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]},cancel(){}}
  const msg={id:'m',role:'user',content:[{type:'text',text:'сожми контекст'}],source:{kind:'user'}}
  const decision=await pre[0]({agent,messages:[msg],turn:1,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[msg]}))
  assert.equal(decision.kind,'reject'); assert.deepEqual(executed,['/compress'])
}

// 5) The SOFT warning itself arms a contextual compression offer; a subsequent
//    bare "да" is routed to /compress. Successful compression code can clear it.
{
  const root=repo('qv4-v071-offer-'); const paths=ensureProject(root)
  const state=initialState(); state.task_state='NO_TASK'; saveState(paths,state)
  const pre=[]; const executed=[]
  const ctx={
    logger:{warn(){},error(){}}, agents:{get(){}},
    on(name,fn){if(name==='agent/pre-step')pre.push(fn)},
    tokenMeter:{measure(){return {totalTokens:80000}},estimateMessage(){return 0}},
    tools:{guard(){},register(){}},
    commands:{register(){},async execute(_agent,line){executed.push(line);return {commandId:'c',result:{kind:'success',text:'ok'}}}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(){throw new Error('n/a')}}, sessions:{},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]},cancel(){},steer(){}}
  const first={id:'u1',role:'user',content:[{type:'text',text:'обычный вопрос'}],source:{kind:'user'}}
  const universalPre=pre.at(-1)
  const entered=await universalPre({agent,messages:[first],turn:1,step:1},async()=>({kind:'enter',messages:[first]}))
  assert.equal(entered.kind,'enter'); assert.equal(compressionOfferActive(agent),true)
  const second={id:'u2',role:'user',content:[{type:'text',text:'да'}],source:{kind:'user'}}
  const routed=await pre[0]({agent,messages:[second],turn:2,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[second]}))
  assert.equal(routed.kind,'reject'); assert.deepEqual(executed,['/compress'])
  clearCompressionOffer(agent); assert.equal(compressionOfferActive(agent),false)
}

console.log('hardening-v071.test.mjs: PASS')
