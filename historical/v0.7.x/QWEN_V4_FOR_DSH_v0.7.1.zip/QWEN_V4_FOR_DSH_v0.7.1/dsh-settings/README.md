Merge the `llm-pi-ai:` section into the active DSH home `settings.yaml`; do not overwrite unrelated settings. On the target portable install this is `C:\DSH-QWEN\dsh-home\settings.yaml`. Set `LLAMA_LOCAL_API_KEY=local`.

`runtime-policy.example.json` is the v0.7 external host-policy template, including fresh-role budgets, universal commit/finalization limits, and context-pressure/compaction thresholds.
