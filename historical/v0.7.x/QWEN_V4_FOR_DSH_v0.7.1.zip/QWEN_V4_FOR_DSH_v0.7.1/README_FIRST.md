# QWEN-V4-FOR-DSH v0.7.1

DeepSeek Harness remains the host runtime and Qwen3.8-27B remains the bounded local executor. v0.7.1 keeps all v0.6 integration fixes and adds two host-owned context/memory mechanisms:

1. **Universal commit-before-answer** for ordinary top-level model turns.
2. **Context-pressure gate + structured `/compress`** using checkpoint coverage rather than free-form transcript summary.

Read `FINAL_SPEC_V0_7.md` and `HARDENING_V0_7.md` for normative behavior.

## What changed from v0.6

- new model-facing `state_checkpoint` for ordinary main-session turns;
- existing `task_checkpoint` remains the stricter `/work` specialization;
- ordinary model turns now follow primary phase -> checkpoint -> reinjection -> bounded finalization;
- canonical semantic memory is still only `WORKING_STATE` (`known`, `decisions`, `evidence`, `failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`);
- checkpoint metadata now carries checkpoint id, state hash, session/source revision, and active-surface coverage high-water mark;
- new host commands `/context`, `/compress`, `/compress --dry-run`;
- natural-language command-plane routing now covers `/context`, `/compress`, and compression dry-run; a bare acknowledgement such as `да`/`окей` routes to `/compress` only while a host SOFT-pressure compression offer is active;
- `/status` includes deterministic context-pressure and compaction availability;
- SOFT context pressure gives a host-generated DSH context notice; HARD pressure rejects an unsafe ordinary model request before llama overflow;
- stock qwen-v4 `compaction-basic` / `/compact` is removed so it cannot become a second memory authority;
- `/compress` preserves the raw session archive and only shadows a proven-covered completed-turn prefix from the recurring model surface;
- protocol checkpoint calls do not consume the ordinary per-turn tool anti-runaway budget;
- all v0.6 local-only, BOM, budget-boundary and structured-output fixes remain.

## Install

Portable/normal installer:

```powershell
.\INSTALL_V0_7_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home
```

Direct DSH plugin install:

```powershell
dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.7.1.tgz"
```

For the already-qualified target machine layout use:

```powershell
.\_LOCAL_C_DSH-QWEN\02-install-v071-qualification.ps1
```

It targets a new `C:\DSH-QWEN\qualification-v071` project so the v0.6 qualification tree can remain untouched.

## First live checks

After llama-server and DSH are running in a **new** qwen-v4 session at the v0.7 qualification repo:

```text
/status
/context
```

Then test an ordinary user message and verify on the wire that it performs:

```text
primary Qwen request
-> state_checkpoint
-> WORKING_STATE update
-> finalization Qwen request with updated state
-> final user answer
```

Then use `/compress --dry-run` before testing a real surface replacement.

## Static release status

The package validator, existing regression suite, v0.6 hardening suite, and new v0.7 context/memory tests must pass before the archive is produced. These static tests do **not** replace live DSH 0.1.1-rc.1 qualification; the exact hook/stream/surface behavior is explicitly left as a live acceptance item.
