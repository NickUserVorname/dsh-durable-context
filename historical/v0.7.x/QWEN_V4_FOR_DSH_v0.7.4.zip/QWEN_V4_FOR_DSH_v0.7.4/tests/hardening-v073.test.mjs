import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { registerContextCommands } from '../dsh-bundle-v4-control/lib/context-commands.js'
import { runFresh } from '../dsh-bundle-v4-control/lib/fresh-role.js'
import { readJson, loadState, loadTask } from '../dsh-bundle-v4-control/lib/state.js'
import { resolveSourceIntake, sourceIntakeChanged } from '../dsh-bundle-v4-control/lib/source-intake.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v073-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix))
  git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T'); git(root,'config','core.autocrlf','false'); git(root,'config','core.eol','lf')
  fs.mkdirSync(path.join(root,'src')); fs.writeFileSync(path.join(root,'src','a.js'),'export const a=1\n'); fs.writeFileSync(path.join(root,'.gitignore'),'.dsh/runtime/\n')
  git(root,'add','-A'); git(root,'commit','-m','base'); return root
}
function fullBudget(){return {max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2}}

// 1) Real DSH command API rejects empty hints; /context must omit input entirely.
{
  const defs=[]
  const ctx={commands:{register(def){if(def.input && !String(def.input.hint??'').trim()) throw new TypeError(`command "${def.name}" input hint must not be empty`); defs.push(def)}}}
  registerContextCommands(ctx)
  const context=defs.find(x=>x.name==='context')
  const compress=defs.find(x=>x.name==='compress')
  assert.ok(context); assert.equal(context.input,undefined)
  assert.equal(compress.input.hint,'[--dry-run]')
}

// 2) structured_output is dynamic outputSchema machinery, not a global toolFilter entry.
{
  let captured
  const ctx={subagents:{async start(_provider,req){captured=req;return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:{ok:true}}),async dispose(){}}}}}
  const parent={session:{header:{cwd:process.cwd()}}}
  const result=await runFresh(ctx,parent,new AbortController().signal,{label:'source-triage',persona:'x',prompt:'x',outputSchema:{type:'object'},agentOptions:{},runtime:null,allowedRoots:[process.cwd()]})
  assert.deepEqual(result,{ok:true})
  assert.deepEqual(captured.toolFilter.allow,['read','grep','glob'])
  assert.ok(captured.outputSchema)
}

// 3) Host hard guard still admits structured_output for fresh roles after filter fix.
{
  const guards=[]
  const ctx={
    logger:{warn(){},error(){}}, tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}}, sessions:{}, agents:{get(){}},
    on(){}, tools:{guard(fn){guards.push(fn)},register(){}}, commands:{register(){}},
    subagents:{async start(){throw new Error('not used')}}, goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const { freshRoleContexts }=await import('../dsh-bundle-v4-control/lib/fresh-role.js')
  const agent={session:{id:'R',header:{cwd:process.cwd(),parentSession:'P'},events:[]},cancel(){}}
  freshRoleContexts.set(agent,{role:'SOURCE_CURATOR',budget:{max_tool_calls:16,max_read_result_bytes:65536},read_bytes:0,tool_calls:0,violation:null,projectRoot:process.cwd(),allowedRoots:[process.cwd()]})
  assert.equal(guards[0]({name:'structured_output',arguments:{},agent}),undefined)
  assert.match(guards[0]({name:'write',arguments:{},agent}),/ROLE_TOOL_DENIED/)
  freshRoleContexts.delete(agent)
}


// 4) Intake host validation is fail-closed: READY needs a primary, clean+dirty needs a dirty/supplementary source,
//    roles cannot overlap, and a material free-form relationship instruction changes the source revision semantics.
{
  const sources=[
    {source_id:'S1',path_or_label:'clean.md'},
    {source_id:'S2',path_or_label:'dirty.txt'},
  ]
  const base={status:'READY',mode:'CLEAN_PLUS_DIRTY_INTERSECTION',primary_sources:['clean.md'],supplementary_sources:['dirty.txt'],historical_sources:[],compatibility_policy:'STRICT_PRESERVE',unmatched_dirty_policy:'DO_NOT_IMPLEMENT',assistant_transcript_policy:'NON_NORMATIVE_UNLESS_USER_ADOPTED',conflict_policy:'STOP_BEFORE_MUTATION',historical_source_policy:'CONTEXT_COMPATIBILITY_REGRESSION_ONLY',material_unknown_policy:'BLOCK',nonmaterial_unknown_policy:'RECORD_AND_DEFER',user_relationship_instruction:'dirty only intersects clean'}
  const resolved=resolveSourceIntake(base,sources)
  assert.deepEqual(resolved.primary_source_ids,['S1'])
  assert.deepEqual(resolved.supplementary_source_ids,['S2'])
  assert.throws(()=>resolveSourceIntake({...base,primary_sources:[]},sources),/requires at least one primary/)
  assert.throws(()=>resolveSourceIntake({...base,supplementary_sources:[]},sources),/requires at least one supplementary/)
  assert.throws(()=>resolveSourceIntake({...base,supplementary_sources:['clean.md']},sources),/cannot be both PRIMARY and SUPPLEMENTARY/)
  // Rewording the user's prose without changing resolved relationship semantics must not churn source_revision.
  assert.equal(sourceIntakeChanged(resolved,{...resolved,user_relationship_instruction:'same relationship, different wording'}),false)
  // A real resolved-policy change must invalidate the source relationship revision.
  assert.equal(sourceIntakeChanged(resolved,{...resolved,compatibility_policy:'NONE'}),true)
  const mixed={...resolved,mode:'MIXED_EXPLICIT',user_relationship_instruction:'custom precedence A over B'}
  assert.equal(sourceIntakeChanged(mixed,{...mixed,user_relationship_instruction:'custom precedence B over A'}),true)
}

// 5) /triage accepts ordinary clean+dirty+previous-spec prose through one existing command,
//    persists relationship semantics durably, and /task snapshots them.
{
  const root=repo('qv4-v073-triage-')
  const commands=new Map(); const starts=[]
  let requirementId=null
  const triageStructured={
    normative_change:true,
    summary:'Current clean spec is primary; dirty material is intersection-only; previous spec is historical compatibility context.',
    classified_sources:[
      {label:'current-spec.md',class:'CANONICAL_SPEC',authority:'NORMATIVE',precedence:'CURRENT_PRIMARY',notes:'current clean target'},
      {label:'dirty-ideas.txt',class:'DIRTY_IDEA',authority:'CONDITIONAL',precedence:'BELOW_PRIMARY',notes:'matching details only'},
      {label:'previous-spec-v1.md',class:'CANONICAL_SPEC',authority:'HISTORICAL_CONTEXT',precedence:'HISTORY_ONLY',notes:'compatibility/regression context'},
    ],
    requirements:[{text:'Implement the current requirement while preserving backward compatibility.',source_label:'current-spec.md',source_ref:'section 2',authority:'NORMATIVE',supersedes:[]}],
    conflicts:[],
    resolved_conflict_ids:[],
    intake:{
      status:'READY', mode:'CLEAN_PLUS_DIRTY_INTERSECTION',
      primary_sources:['current-spec.md'], supplementary_sources:['dirty-ideas.txt'], historical_sources:['previous-spec-v1.md'],
      compatibility_policy:'STRICT_PRESERVE', unmatched_dirty_policy:'DO_NOT_IMPLEMENT',
      assistant_transcript_policy:'NON_NORMATIVE_UNLESS_USER_ADOPTED', conflict_policy:'STOP_BEFORE_MUTATION',
      historical_source_policy:'CONTEXT_COMPATIBILITY_REGRESSION_ONLY', material_unknown_policy:'BLOCK', nonmaterial_unknown_policy:'RECORD_AND_DEFER',
      user_relationship_instruction:'во втором файле грязная идея; совпадающее учитывать; при конфликте остановиться; сохранить обратную совместимость; также посмотреть предыдущие ТЗ',
    },
  }
  const ctx={
    logger:{warn(){},error(){}}, tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}}, sessions:{}, agents:{get(){}},
    on(){}, tools:{guard(){},register(){}}, commands:{register(d){commands.set(d.name,d)},execute(){}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(_provider,req){
      starts.push(req)
      let structured
      if(req.label==='source-triage') structured=triageStructured
      else if(req.label==='task-planner') structured={
        objective:'implement current requirement',requirement_refs:[requirementId],
        preserve:['Backward-compatible retained behavior from current/historical source context'],replace:[],remove:[],add:['current behavior'],
        forbidden:['Do not implement dirty-only ideas','Do not regress retained behavior'],write_set:['src/a.js'],
        acceptance:['Current requirement is implemented','Backward compatibility regression coverage is required'],
        qualification:{mode:'REQUIRED',rationale:'implementation change with strict compatibility'},budget:fullBudget(),
      }
      else throw new Error(`unexpected subagent ${req.label}`)
      return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured}),async dispose(){}}
    }},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={id:'A',session:{id:'S',header:{cwd:root},events:[],seq:0},cancel(){},steer(){}}
  const triage=await commands.get('triage').handler({agent,rawInput:'Первый файл основной. Во втором грязная идея: бери только совпадающее, конфликт покажи до действий, сохрани обратную совместимость. Также посмотри предыдущие ТЗ.',signal:new AbortController().signal})
  assert.equal(triage.kind,'success',triage.text)
  assert.match(triage.text,/CLEAN_PLUS_DIRTY_INTERSECTION/)
  const state=loadState({state:path.join(root,'.dsh','project','state.json')})
  assert.equal(state.source_revision,1)
  assert.equal(state.source_intake_status,'READY')
  assert.equal(state.source_intake_mode,'CLEAN_PLUS_DIRTY_INTERSECTION')
  assert.equal(state.source_compatibility_policy,'STRICT_PRESERVE')
  const index=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(index.intake.status,'READY')
  assert.equal(index.intake.mode,'CLEAN_PLUS_DIRTY_INTERSECTION')
  assert.equal(index.intake.compatibility_policy,'STRICT_PRESERVE')
  assert.equal(index.intake.primary_source_ids.length,1)
  assert.equal(index.intake.supplementary_source_ids.length,1)
  assert.equal(index.intake.historical_source_ids.length,1)
  const roles=Object.fromEntries(index.sources.map(s=>[s.path_or_label,s.relationship_role]))
  assert.deepEqual(roles,{'current-spec.md':'PRIMARY','dirty-ideas.txt':'SUPPLEMENTARY','previous-spec-v1.md':'HISTORICAL'})
  const intakeMd=fs.readFileSync(path.join(root,'.dsh','project','SOURCE_INTAKE.md'),'utf8')
  assert.match(intakeMd,/historical_source_ids:/)
  assert.match(intakeMd,/STRICT_PRESERVE/)
  assert.match(intakeMd,/HISTORICAL.*compatibility\/regression/i)
  const ledger=readJson(path.join(root,'.dsh','project','ACTIVE_REQUIREMENTS.json'))
  requirementId=ledger.requirements[0].id
  const taskResult=await commands.get('task').handler({agent,rawInput:'',signal:new AbortController().signal})
  assert.equal(taskResult.kind,'success',taskResult.text)
  const post=loadState({state:path.join(root,'.dsh','project','state.json')})
  const task=loadTask({taskPackets:path.join(root,'.dsh','project','task_packets')},post.active_task_id)
  assert.equal(task.source_intake.mode,'CLEAN_PLUS_DIRTY_INTERSECTION')
  assert.equal(task.source_intake.compatibility_policy,'STRICT_PRESERVE')
  assert.equal(task.source_intake.historical_source_ids.length,1)
  const preserve=readJson(path.join(root,'.dsh','project','task_packets',`${task.id}.PRESERVE_CONTRACT.json`))
  assert.equal(preserve.source_intake.compatibility_policy,'STRICT_PRESERVE')
  const plannerReq=starts.find(x=>x.label==='task-planner')
  const plannerPrompt=plannerReq.prompt.map(x=>x.text??'').join('\n')
  assert.match(plannerPrompt,/Effective source intake:/)
  assert.match(plannerPrompt,/STRICT_PRESERVE/)
}

// 6) A BLOCKED intake is a host-level gate: /task does not invoke the planner.
{
  const root=repo('qv4-v073-blocked-')
  const project=path.join(root,'.dsh','project'); fs.mkdirSync(project,{recursive:true})
  fs.writeFileSync(path.join(project,'SOURCE_INDEX.json'),JSON.stringify({schema_version:3,status:'blocked',revision:1,sources:[],intake:{status:'BLOCKED',revision:1,mode:'CLEAN_PLUS_DIRTY_INTERSECTION',primary_source_ids:[],supplementary_source_ids:[],historical_source_ids:[],compatibility_policy:'STRICT_PRESERVE',unmatched_dirty_policy:'DO_NOT_IMPLEMENT',assistant_transcript_policy:'NON_NORMATIVE_UNLESS_USER_ADOPTED',conflict_policy:'STOP_BEFORE_MUTATION',historical_source_policy:'CONTEXT_COMPATIBILITY_REGRESSION_ONLY',material_unknown_policy:'BLOCK',nonmaterial_unknown_policy:'RECORD_AND_DEFER',user_relationship_instruction:'conflict'}},null,2))
  fs.writeFileSync(path.join(project,'state.json'),JSON.stringify({schema:'qwen-v4-project-state-0.7.2',source_revision:1,source_conflict_count:0,source_intake_status:'BLOCKED',source_intake_mode:'CLEAN_PLUS_DIRTY_INTERSECTION',source_compatibility_policy:'STRICT_PRESERVE',current_phase:'UNSET',active_task_id:null,task_state:'NO_TASK',worker_session_id:null,last_test:null,last_review:null,last_acceptance:null,operation:null,budget_defaults:fullBudget(),updated_at:null},null,2))
  let started=0; const commands=new Map()
  const ctx={logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)},execute(){}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){started++;throw new Error('planner should not start')}}}
  apply(ctx,{tokenizerEndpoint:''})
  const agent={id:'A',session:{id:'S',header:{cwd:root},events:[],seq:0},cancel(){},steer(){}}
  const res=await commands.get('task').handler({agent,rawInput:'x',signal:new AbortController().signal})
  assert.equal(res.kind,'error')
  assert.match(res.text,/source intake is BLOCKED/)
  assert.equal(started,0)
}

// 7) No command-surface sprawl: the v0.7.3 patch reuses /triage and existing lifecycle commands.
{
  const commands=new Map()
  const ctx={logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)},execute(){}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('unused')}}}
  apply(ctx,{tokenizerEndpoint:''})
  for(const invented of ['audit','discuss','spec','triage-history','triage-current']) assert.equal(commands.has(invented),false,invented)
  for(const existing of ['triage','task','work','review','accept','status','context']) assert.equal(commands.has(existing),true,existing)
}


// 8) DSH's terminal structured_output protocol call must not consume productive role tool budget.
{
  const root=repo('qv4-v073-roletools-')
  const paths=(await import('../dsh-bundle-v4-control/lib/state.js')).ensureProject(root)
  const guards=[]
  let finish
  const localAgent={id:'ROLE',session:{id:'ROLE',header:{cwd:root,parentSession:'P'},events:[]},cancel(){}}
  const ctx={
    subagents:{async start(){return {localAgent,result:new Promise(r=>{finish=r}),async dispose(){}}}},
  }
  const pending=runFresh(ctx,{session:{header:{cwd:root}}},new AbortController().signal,{
    label:'source-triage',persona:'x',prompt:'x',outputSchema:{type:'object'},agentOptions:{},runtime:{root,paths,lock:Promise.resolve()},role:'SOURCE_CURATOR',allowedRoots:[root],tokenizerEndpoint:'',
  })
  while(!(await import('../dsh-bundle-v4-control/lib/fresh-role.js')).freshRoleContexts.has(localAgent)) await new Promise(r=>setTimeout(r,1))
  const {freshRoleContexts}=await import('../dsh-bundle-v4-control/lib/fresh-role.js')
  const roleCtx=freshRoleContexts.get(localAgent)
  // Simulate the host guard's productive counter and a session event stream that includes
  // two productive tools plus the terminal structured_output protocol event.
  roleCtx.tool_calls=16
  roleCtx.guard_seen=true
  localAgent.session.events=[
    ...Array.from({length:16},(_,i)=>({seq:i+1,time:i+1,type:'tool/call',data:{name:i%2?'grep':'read'}})),
    {seq:17,time:17,type:'tool/call',data:{name:'structured_output'}},
  ]
  finish({stopReason:'completed',structured:{ok:true}})
  const out=await pending
  assert.deepEqual(out,{ok:true})
}

console.log('hardening-v073.test.mjs: PASS')
