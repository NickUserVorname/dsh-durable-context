import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { ensureProject, loadState, readJson, saveState, saveTask } from '../dsh-bundle-v4-control/lib/state.js'
import { workflowIntent } from '../dsh-bundle-v4-control/lib/intent-router.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v073-audit-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix))
  git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');git(root,'config','core.autocrlf','false');git(root,'config','core.eol','lf')
  fs.writeFileSync(path.join(root,'README.md'),'x\n');fs.writeFileSync(path.join(root,'.gitignore'),'.dsh/runtime/\n');git(root,'add','-A');git(root,'commit','-m','base')
  return root
}
function ctxWithStarts(startImpl){
  const commands=new Map()
  const ctx={
    logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},
    on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)},execute(){}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{start:startImpl},
  }
  apply(ctx,{tokenizerEndpoint:''})
  return {ctx,commands}
}
function agent(root,id='A'){return {id,session:{id,header:{cwd:root},events:[],seq:0},cancel(){},steer(){}}}
function intake(primary,{status='READY',mode='MIXED_EXPLICIT',compatibility='NONE'}={}){return {
  status,mode,primary_sources:[primary],supplementary_sources:[],historical_sources:[],compatibility_policy:compatibility,
  unmatched_dirty_policy:'DO_NOT_IMPLEMENT',assistant_transcript_policy:'NON_NORMATIVE_UNLESS_USER_ADOPTED',conflict_policy:'STOP_BEFORE_MUTATION',
  historical_source_policy:'CONTEXT_COMPATIBILITY_REGRESSION_ONLY',material_unknown_policy:'BLOCK',nonmaterial_unknown_policy:'RECORD_AND_DEFER',user_relationship_instruction:'explicit current source',
}}
function triage(label,{normative=false,requirements=[],conflicts=[],resolved=[],intakeValue=null}={}){return {
  normative_change:normative,summary:label,classified_sources:[{label,class:'CANONICAL_SPEC',authority:'NORMATIVE',precedence:'PRIMARY',notes:'test'}],
  requirements,conflicts,resolved_conflict_ids:resolved,intake:intakeValue??intake(label),
}}

// A) In-place hotfix must migrate same-schema v0.7.2 states with new intake fields.
{
  const root=repo();const paths=ensureProject(root)
  fs.writeFileSync(paths.state,JSON.stringify({schema:'qwen-v4-project-state-0.7.2',source_revision:7,source_conflict_count:0,current_phase:'UNSET',active_task_id:null,task_state:'NO_TASK',budget_defaults:{}},null,2))
  const s=loadState(paths)
  assert.equal(s.source_revision,7)
  assert.equal(s.source_intake_status,'UNRESOLVED')
  assert.equal(s.source_intake_mode,'UNSET')
  assert.equal(s.source_compatibility_policy,'NONE')
}

// B) Relationship-only revision change must not launder requirements when curator says normative_change=false.
{
  const root=repo();let response=triage('clean.md',{normative:false,requirements:[{text:'SHOULD NOT ENTER LEDGER',source_label:'clean.md',source_ref:'§1',authority:'NORMATIVE',supersedes:[]}]})
  const {commands}=ctxWithStarts(async()=>({localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:response}),async dispose(){}}))
  const r=await commands.get('triage').handler({agent:agent(root),rawInput:'clean text',signal:new AbortController().signal})
  assert.equal(r.kind,'error')
  assert.match(r.text,/requirements while normative_change=false/)
  const ledger=readJson(path.join(root,'.dsh','project','ACTIVE_REQUIREMENTS.json'),{requirements:[]})
  assert.equal(ledger.requirements.length,0)
  const idx=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(Number(idx.generation??0),0)
  assert.equal(fs.readdirSync(path.join(root,'.dsh','project','source_material')).filter(x=>x.endsWith('.raw.txt')).length,0,'failed triage must not become durable historical material')
  assert.equal(fs.readdirSync(path.join(root,'.dsh','runtime','triage-staging')).filter(x=>x.endsWith('.raw.txt')).length,1,'failed triage keeps only a non-authoritative staged payload')
}

// C) Conflicts are durable across unrelated triage and clear only by explicit stable conflict id.
{
  const root=repo();const responses=[]
  const {commands}=ctxWithStarts(async()=>({localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:responses.shift()}),async dispose(){}}))
  responses.push(triage('clean.md',{normative:true,conflicts:['clean requirement contradicts dirty requirement']}))
  let r=await commands.get('triage').handler({agent:agent(root),rawInput:'first intake',signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text)
  let idx=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(idx.conflicts.length,1)
  assert.equal(idx.intake.status,'BLOCKED')
  const conflictId=idx.conflicts[0].id
  const primary=idx.intake.primary_source_ids[0]
  const rev1=idx.revision

  responses.push(triage('unrelated.log',{normative:false,intakeValue:intake(primary,{status:'READY'})}))
  r=await commands.get('triage').handler({agent:agent(root),rawInput:'unrelated evidence only',signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text)
  idx=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(idx.conflicts.length,1,'prior conflict must survive omission')
  assert.equal(idx.conflicts[0].id,conflictId)
  assert.equal(idx.intake.status,'BLOCKED')
  assert.equal(idx.revision,rev1,'unrelated evidence should not churn normative revision')

  responses.push(triage('resolution.txt',{normative:false,resolved:[conflictId],intakeValue:intake(primary,{status:'READY'})}))
  r=await commands.get('triage').handler({agent:agent(root),rawInput:'resolve the prior conflict in favor of current primary',signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text)
  idx=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(idx.conflicts.length,0)
  assert.equal(idx.intake.status,'READY')
  assert.equal(idx.revision,rev1+1)
}

// D) Two long-running /triage calls cannot commit against the same stale authority basis.
{
  const root=repo();const deferred=[]
  const {commands}=ctxWithStarts(async()=>{
    let resolve;const result=new Promise(r=>{resolve=r});deferred.push(resolve)
    return {localAgent:undefined,result,async dispose(){}}
  })
  const a=agent(root,'A'),b=agent(root,'B')
  const p1=commands.get('triage').handler({agent:a,rawInput:'first',signal:new AbortController().signal})
  const p2=commands.get('triage').handler({agent:b,rawInput:'second',signal:new AbortController().signal})
  while(deferred.length<2) await new Promise(r=>setTimeout(r,5))
  deferred[0]({stopReason:'completed',structured:triage('first.md',{normative:true})})
  const r1=await p1;assert.equal(r1.kind,'success',r1.text)
  deferred[1]({stopReason:'completed',structured:triage('second.md',{normative:true})})
  const r2=await p2;assert.equal(r2.kind,'error');assert.match(r2.text,/TRIAGE_STALE_BASIS/)
  const idx=readJson(path.join(root,'.dsh','project','SOURCE_INDEX.json'))
  assert.equal(idx.generation,1)
  assert.equal(idx.sources.length,1)
}

// E) Full inline material is persisted before the fresh role, so boundedPrompt cannot silently erase the middle.
{
  const root=repo();const huge=`BEGIN\n${'A'.repeat(90000)}\nMIDDLE_SENTINEL\n${'B'.repeat(90000)}\nEND`
  let saw=false
  const {commands}=ctxWithStarts(async(_provider,req)=>{
    const prompt=req.prompt.map(x=>x.text??'').join('\n')
    const m=/FULL NEW USER MATERIAL \(host-staged raw copy; read this file with tools\): (.+)/.exec(prompt)
    assert.ok(m)
    const file=m[1].trim()
    const raw=fs.readFileSync(file,'utf8')
    assert.equal(raw,huge)
    assert.ok(prompt.length<50000,'prompt should carry preview/path, not duplicate the full huge input')
    saw=true
    return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:triage('inline-huge',{normative:true})}),async dispose(){}}
  })
  const r=await commands.get('triage').handler({agent:agent(root),rawInput:huge,signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text);assert.equal(saw,true)
  const durable=fs.readdirSync(path.join(root,'.dsh','project','source_material')).filter(x=>x.endsWith('.raw.txt'))
  assert.equal(durable.length,1,'successful triage promotes exactly one durable raw payload')
  assert.equal(fs.readFileSync(path.join(root,'.dsh','project','source_material',durable[0]),'utf8'),huge)
}

// F) Natural no-payload triage phrases must fail open to chat; explicit payload routing still works.
{
  assert.equal(workflowIntent('triage',{taskState:'NO_TASK'}),null)
  assert.equal(workflowIntent('разбери требования',{taskState:'NO_TASK'}),null)
  assert.deepEqual(workflowIntent('run triage: use current spec',{taskState:'NO_TASK'}),{command:'triage',rawInput:'use current spec',confidence:'explicit-payload'})
}

console.log('hardening-v073-audit.test.mjs: PASS')
