import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { createRuntime, ensureProject, withRuntimeLock } from '../dsh-bundle-v4-control/lib/state.js'
import { current } from '../dsh-bundle-v4-control/lib/host-runtime.js'
import { _transactionTest, commitProjectTransaction, listProjectTransactions, recoverProjectTransactions } from '../dsh-bundle-v4-control/lib/project-transaction.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v074-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix))
  git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');git(root,'config','core.autocrlf','false');git(root,'config','core.eol','lf')
  fs.writeFileSync(path.join(root,'README.md'),'x\n');fs.writeFileSync(path.join(root,'.gitignore'),'.dsh/runtime/\n');git(root,'add','-A');git(root,'commit','-m','base')
  ensureProject(root)
  return root
}
function ctxWithStarts(startImpl){
  const commands=new Map()
  const ctx={
    logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:0,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},
    on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)},execute(){}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{start:startImpl},
  }
  apply(ctx,{tokenizerEndpoint:''})
  return {ctx,commands}
}
function agent(root,id='A'){return {id,session:{id,header:{cwd:root},events:[],seq:0},cancel(){},steer(){}}}
function triage(label){return {
  normative_change:true,summary:'ok',classified_sources:[{label,class:'CANONICAL_SPEC',authority:'NORMATIVE',precedence:'PRIMARY',notes:'test'}],
  requirements:[{text:'Keep behavior',source_label:label,source_ref:'§1',authority:'NORMATIVE',supersedes:[]}],conflicts:[],resolved_conflict_ids:[],
  intake:{status:'READY',mode:'MIXED_EXPLICIT',primary_sources:[label],supplementary_sources:[],historical_sources:[],compatibility_policy:'STRICT_PRESERVE',unmatched_dirty_policy:'DO_NOT_IMPLEMENT',assistant_transcript_policy:'NON_NORMATIVE_UNLESS_USER_ADOPTED',conflict_policy:'STOP_BEFORE_MUTATION',historical_source_policy:'CONTEXT_COMPATIBILITY_REGRESSION_ONLY',material_unknown_policy:'BLOCK',nonmaterial_unknown_policy:'RECORD_AND_DEFER',user_relationship_instruction:'primary current spec'},
}}

// A) PREPARED is not a commit decision. Recovery aborts it and preserves the before-state.
{
  const root=repo();const paths=ensureProject(root)
  const a=path.join(root,'.dsh','project','tx-a.txt');fs.writeFileSync(a,'before\n')
  const prepared=_transactionTest.prepareProjectTransaction(paths,{kind:'test',writes:[{file:a,content:'after\n'}]})
  assert.equal(_transactionTest.readJournal(prepared.txDir).phase,'PREPARED')
  const result=recoverProjectTransactions(paths)
  assert.equal(result[0].action,'ROLLBACK')
  assert.equal(fs.readFileSync(a,'utf8'),'before\n')
  assert.equal(listProjectTransactions(paths.transactions).length,0)
}

// B) A hard crash after the commit decision and only one file write rolls forward atomically.
{
  const root=repo();const paths=ensureProject(root)
  const a=path.join(root,'.dsh','project','tx-b-a.txt'),b=path.join(root,'.dsh','project','tx-b-b.txt')
  fs.writeFileSync(a,'old-a\n');fs.writeFileSync(b,'old-b\n')
  const prepared=_transactionTest.prepareProjectTransaction(paths,{kind:'test',writes:[{file:a,content:'new-a\n'},{file:b,content:'new-b\n'}]})
  _transactionTest.updatePhase(prepared.txDir,prepared.journal,'COMMITTING')
  _transactionTest.applyAfterEntry(root,prepared.txDir,prepared.journal.files[0])
  // Simulated process death: no more commit code runs. A fresh recovery sees a mixed before/after set.
  assert.equal(fs.readFileSync(a,'utf8'),'new-a\n');assert.equal(fs.readFileSync(b,'utf8'),'old-b\n')
  const result=recoverProjectTransactions(paths)
  assert.equal(result[0].action,'COMMIT')
  assert.equal(fs.readFileSync(a,'utf8'),'new-a\n');assert.equal(fs.readFileSync(b,'utf8'),'new-b\n')
  assert.equal(listProjectTransactions(paths.transactions).length,0)
}

// C) Normal in-process write failure is recovered before returning; callers never keep a mixed set.
{
  const root=repo();const paths=ensureProject(root)
  const a=path.join(root,'.dsh','project','tx-c-a.txt'),b=path.join(root,'.dsh','project','tx-c-b.txt')
  fs.writeFileSync(a,'old-a\n');fs.writeFileSync(b,'old-b\n')
  let injected=false
  const result=commitProjectTransaction(paths,{kind:'test',writes:[{file:a,content:'new-a\n'},{file:b,content:'new-b\n'}]}, {hooks:{afterWrite(count){if(count===1&&!injected){injected=true;throw new Error('INJECTED_COMMIT_FAILURE')}}}})
  assert.equal(result.action,'COMMIT');assert.equal(result.recovered,true)
  assert.equal(fs.readFileSync(a,'utf8'),'new-a\n');assert.equal(fs.readFileSync(b,'utf8'),'new-b\n')
  assert.equal(listProjectTransactions(paths.transactions).length,0)
}

// D) Unknown external divergence is never silently overwritten during recovery.
{
  const root=repo();const paths=ensureProject(root)
  const a=path.join(root,'.dsh','project','tx-d-a.txt'),b=path.join(root,'.dsh','project','tx-d-b.txt')
  fs.writeFileSync(a,'old-a\n');fs.writeFileSync(b,'old-b\n')
  const prepared=_transactionTest.prepareProjectTransaction(paths,{kind:'test',writes:[{file:a,content:'new-a\n'},{file:b,content:'new-b\n'}]})
  _transactionTest.updatePhase(prepared.txDir,prepared.journal,'COMMITTING')
  _transactionTest.applyAfterEntry(root,prepared.txDir,prepared.journal.files[0])
  fs.writeFileSync(b,'manual-divergence\n')
  assert.throws(()=>recoverProjectTransactions(paths),/PROJECT_TRANSACTION_RECOVERY_FAILED/)
  assert.equal(fs.readFileSync(b,'utf8'),'manual-divergence\n')
}

// E) Host current() fails closed while a crash journal exists; the next project-locked command path recovers first.
{
  const root=repo();const runtime=createRuntime(root);const file=path.join(root,'.dsh','project','tx-e.txt');fs.writeFileSync(file,'old\n')
  const prepared=_transactionTest.prepareProjectTransaction(runtime.paths,{kind:'test',writes:[{file,content:'new\n'}]})
  _transactionTest.updatePhase(prepared.txDir,prepared.journal,'COMMITTING')
  assert.throws(()=>current(runtime),/PROJECT_TRANSACTION_RECOVERY_REQUIRED/)
  const state=await withRuntimeLock(runtime,()=>current(runtime))
  assert.equal(state.state.source_revision,0)
  assert.equal(fs.readFileSync(file,'utf8'),'new\n')
  assert.equal(listProjectTransactions(runtime.paths.transactions).length,0)
}

// F) Successful /triage uses the durable raw file + metadata hash without duplicating huge raw_input in JSON.
{
  const root=repo();const huge=`BEGIN\n${'A'.repeat(70000)}\nEND`
  const response=triage('current-spec.txt')
  const {commands}=ctxWithStarts(async()=>({localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:response}),async dispose(){}}))
  const r=await commands.get('triage').handler({agent:agent(root),rawInput:huge,signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text)
  const sourceDir=path.join(root,'.dsh','project','source_material')
  const raw=fs.readdirSync(sourceDir).find(x=>x.endsWith('.raw.txt'))
  const meta=fs.readdirSync(sourceDir).find(x=>/^SRC-.*\.json$/.test(x))
  assert.ok(raw);assert.ok(meta)
  assert.equal(fs.readFileSync(path.join(sourceDir,raw),'utf8'),huge)
  const record=JSON.parse(fs.readFileSync(path.join(sourceDir,meta),'utf8'))
  assert.equal('raw_input' in record,false)
  assert.equal(record.raw_input_chars,huge.length)
  assert.equal(typeof record.raw_input_sha256,'string')
  assert.equal(fs.readdirSync(path.join(root,'.dsh','runtime','triage-staging')).filter(x=>x.endsWith('.raw.txt')).length,0)
  assert.equal(listProjectTransactions(path.join(root,'.dsh','runtime','transactions')).length,0)
}

console.log('hardening-v074.test.mjs: PASS')
