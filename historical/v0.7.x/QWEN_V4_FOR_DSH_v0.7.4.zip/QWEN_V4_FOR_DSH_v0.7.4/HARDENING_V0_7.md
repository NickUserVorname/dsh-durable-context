# Hardening v0.7.4 — universal state commit and context-pressure compaction

v0.7.4 is an integration/source-authority hardening patch over v0.7.2 while preserving the v0.7 universal context/memory mechanisms and all v0.6 integration fixes. It preserves all v0.6 fixes: structured-output admission, exact-cap budget semantics, no-BOM Windows policy writes, fail-closed critical task guards, local-only DeepSeek route neutralization, expanded fresh-role budgets, and the qualified llama profile.

## H7-1 — One semantic memory model

`WORKING_STATE` schema is bumped to 6. No parallel conversation-summary authority is introduced. Extended checkpoint metadata separates protocol completion from prune authority and keeps stable state identity.

## H7-2 — Universal commit-before-answer

A top-level ordinary model turn is intercepted by the host. The host injects the committed state plus a primary commit protocol. A turn that attempts natural completion without a checkpoint is steered once by default into checkpoint-only mode. Failure after the bounded recovery allowance is cancelled explicitly.

`state_checkpoint` permits model-owned semantic fields only. Host-owned fields are re-derived from authoritative project/task state.

## H7-3 — Rendering-only finalization

After accepted checkpoint, a separate continuation is injected with the updated state and ephemeral response basis. All tool calls are denied in finalization. Request output is capped and reasoning defaults to `off`.

## H7-4 — Protocol-tool accounting

`state_checkpoint` and `task_checkpoint` are excluded from the normal per-turn tool anti-runaway counter because they are mandatory protocol operations. This does not erase their real events or provider token usage.

## H7-5 — Coverage metadata

Every universal checkpoint and `/work` task checkpoint writes:

```text
checkpoint_id
checkpoint_kind
protocol_committed_through_seq
prune_safe_through_seq
session_revision
source_revision
state_hash
```

Protocol success and pruning authority are not equivalent. A substantive semantic commit may advance both only while coverage remains contiguous. `no_change=true` advances only the protocol watermark and creates a prune barrier; later ordinary commits cannot leapfrog that gap. `/compress` is forbidden from reading protocol-only coverage as permission to shadow raw history. `task_failed_hypothesis` also refreshes host-owned state identity so compaction never relies on a stale semantic hash.

## H7-6 — Context-pressure gate

The host measures the canonical session/model surface through `tokenMeter` and subtracts completion, compression-recovery, and safety reserves. SOFT warning uses deterministic context injection with hysteresis. HARD pressure rejects the ordinary model step before context overflow.

## H7-7 — Structured compaction only

The qwen-v4 preset no longer enables stock `compaction-basic`, stock `/compact`, or its tool-result-pruner group. `/compress` replaces only a validated **prune-safe** prefix with a structured state snapshot. Raw session events stay in the archive and are referenced through `sourceEventSeqs`.

## H7-8 — Conservative turn boundaries

Compaction never splits a completed turn. User messages that precede `turn/start` are assigned conservatively to the following completed turn. Unknown/unowned surface nodes stop the compactable prefix rather than being guessed safe.

## H7-9 — Stale-safe commit

`/compress` records session revision, checkpoint id, and state hash, then rechecks them immediately before surface replacement. Any mismatch aborts without modifying the active surface.

## H7-10 — Deterministic inspection

`/context`, `/status`, and `/compress --dry-run` expose context/compaction state without a model inference.

## H7-11 — Natural intent parity and pressure-offer recovery

`/context` and `/compress` are registered slash commands **and** participate in the same conservative host intent router as the older workflow commands. Read-only context questions such as `сколько контекста осталось?` route directly to `/context` without a model request. Only unambiguous imperative compression phrases route to `/compress`; questions, negations, hypotheticals, and quoted examples remain ordinary chat. Dry-run phrases route to `/compress --dry-run`.

A SOFT-pressure notice arms an ephemeral host-side compression offer. While that offer is active, short acknowledgements such as `да`, `окей`, or `сжимай` may route to `/compress`. The same words do nothing without an active offer. Successful real compression clears the offer. Because the intent-router hook runs before the universal model-pressure gate, an explicit natural compression request remains a recovery path even when the next normal model request would be `COMPACTION_REQUIRED`.


## H7-12 — Dynamic remaining-validation reserve

Worker admission protects the sum of the maxima for validation roles that are still mandatory. The default chain starts at TEST+REVIEW+ACCEPT (11 requests / 32K reasoning / 13K visible / 30 tools / 25 min), drops to REVIEW+ACCEPT after TEST, to ACCEPT after REVIEW, and to zero after acceptance. Effective reserve is derived from actual configured role caps. This closes the v0.7.1 case where a smaller static reserve could let the worker legally consume budget later required by ACCEPTANCE.

## H7-13 — Host-owned ASK/AUTO execution broker

`.dsh/project/EXECUTION_POLICY.json` defaults to ASK. `/ask`, `/auto`, `/approve`, `/deny`, and `/permissions` are slash-only; the phrase router cannot silently change trust mode. Unknown gated execution in ASK becomes one pending exact approval and is denied before execution. Allow/deny decisions are persisted by exact normalized signature. AUTO suppresses only interactive approval; it does not suppress hard protocol, authority, budget, context, worktree/donor, or acceptance guards.

An autonomous `/work` goal that reaches a new pending approval is blocked/cancelled without changing its worktree/task epoch, preventing automatic rounds from being consumed while waiting for a human. `/approve` followed by `/work` resumes that same task.

## H7-14 — Execution side-effect provenance is not publish authority

`write_set` is the publishable output contract. Approved/AUTO execution may create additional task-worktree side effects. The host records their originating operation id, permission kind/signature and path classification. Proven ignored runtime/cache output is disposable and omitted from publication. Nonignored output outside `write_set` is explicitly unpublishable until removed or scope-expanded. Unproven ignored changes remain blockers. Reserved paths and donor/project-authority mutations remain immediate hard violations.

## H7-15 — Qualification identifiers

The runtime adversarial suite is sequentially numbered and every case has a stable `QV4-ADV-NNN` id. Later insertions must preserve stable ids even if presentation ordering changes.

## H7-16 — DSH command/subagent integration compatibility

`/context` omits the optional `input` field rather than registering an empty hint, matching DSH 0.1.1-rc.1 command normalization. Fresh roles restrict global tools to `read`, `grep`, and `glob`; `structured_output` is supplied dynamically by the subagent output schema and remains allowed by the host role guard.

## H7-17 — Durable source relationship intake

`/triage` remains the only source-intake command. The source curator converts ordinary user prose into an effective intake contract stored under `SOURCE_INDEX.json.intake` and rendered to `SOURCE_INTAKE.md`. The contract records primary, supplementary/dirty and historical source sets, clean+dirty intersection behavior, conflict-before-mutation, transcript authority policy and backward-compatibility policy. Historical prior specs are compatibility/regression context and never silently outrank the current primary source. `/task` requires `READY` intake and snapshots the contract into the task packet and preserve contract.

## H7-18 — Recoverable multi-file triage transaction

A successful `/triage` changes several authority artifacts together: `SOURCE_INDEX.json`, `ACTIVE_REQUIREMENTS.json`, generated source/spec/conflict views, durable provenance material, project state, and sometimes the active task packet. Per-file atomic rename is insufficient because a process crash between those writes can expose a mixed authority generation.

v0.7.4 stages every post-triage target plus before-images under `.dsh/runtime/transactions`, writes a journal with an explicit commit phase, and then applies the set under the project-wide process lock. `PREPARED` is not a commit decision and is aborted on recovery. `COMMITTING` is a commit decision: recovery attempts idempotent roll-forward; if roll-forward cannot be completed, it may roll back only when every target is still recognizably the journaled before/after image. Any unknown external divergence fails closed rather than being overwritten. `COMMITTED` is verified/finished and then the journal is removed.

The full user triage payload remains non-authoritative in `.dsh/runtime/triage-staging` until this transaction commits. A successful transaction promotes one raw source material file plus compact metadata (hash/byte/character counts); failed or stale triage attempts do not become historical source authority. Host reads that encounter an interrupted transaction fail closed unless they enter a project-locked path, which recovers pending transactions before exposing authority state.

## Known live-qualification boundary

The plugin uses public DSH hook/surface concepts (`agent/pre-step`, `agent/turn-stopping`, tool guards, session surface replacement, token-meter). Static tests validate the intended contracts using mocks, but v0.7.4 must still be qualified on the installed DSH 0.1.1-rc.1 before being treated as production-proven. In particular, primary-response streaming suppression is not claimed as a custom DSH-core feature.

