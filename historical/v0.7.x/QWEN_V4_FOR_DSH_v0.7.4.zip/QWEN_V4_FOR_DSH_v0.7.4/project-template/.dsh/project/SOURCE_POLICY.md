# Source authority policy

This project distinguishes **requirements** from **evidence/discussion**. Do not treat every Markdown/text attachment as equally normative.

## Supported classes

`CANONICAL_SPEC`, `NORMATIVE_CORRECTION`, `SUPPLEMENTARY_CLEAN_SPEC`, `DIRTY_REQUIREMENT_DRAFT`, `DIRTY_IDEA`, `CONVERSATION_TRANSCRIPT`, `AUDIT_REVIEW`, `IMPLEMENTATION_LOG`, `CURRENT_STATE_REPORT`, `REPO_EVIDENCE`, `UNKNOWN`.

- `DIRTY_REQUIREMENT_DRAFT`: requirement-shaped but explicitly rough/unclean material; conditional unless the user promotes it.
- `CURRENT_STATE_REPORT`: user-supplied “what exists now” snapshot/audit/transcript. Evidence only until checked against the actual repository/runtime.

## Default authority

- Formal source explicitly presented/adopted by the user as the target: normative.
- Explicit user correction/prohibition: candidate normative delta; apply according to recorded precedence.
- Dirty requirement draft/idea/brainstorm: conditional, not automatically normative.
- Conversation transcript: mixed; direct user statements and assistant/model text must be separated.
- Assistant/model proposals/summaries inside transcripts: non-normative unless the user explicitly adopts them.
- Tool output, benchmark logs, implementation status claims and current-state reports: evidence only; verify against repository/runtime.
- Audit/review: evidence/repair overlay by default. If the user explicitly says "work from this audit", findings become task acceptance targets but may not silently override higher normative architecture.
- Current repository: factual state, not desired behavior.

## Precedence

1. Current explicit user instruction about source relationships.
2. Explicit precedence declared inside adopted source documents.
3. Explicit normative correction/override.
4. Canonical clean specification.
5. Conditional/supplementary sources according to `SOURCE_INTAKE.md`.
6. Historical prior specs according to `SOURCE_INTAKE.md`: compatibility/regression context only unless explicitly promoted by the current user.
7. Audits/logs/current-state reports/repository evidence for verification.

Never infer that “newer = stronger” when explicit precedence exists.

## Durable conflict registry

`SOURCE_INDEX.json.conflicts` is the machine-authoritative unresolved conflict set. `/triage` may add new conflicts, but an existing conflict is removed only when the fresh curator explicitly returns its stable conflict id in `resolved_conflict_ids` based on current user/source authority. Omission is never resolution. `SOURCE_CONFLICTS.md` is generated from that registry.

## Conflict gate

Any unresolved **material** semantic conflict between candidate/approved requirements blocks production/test/benchmark mutation. Read-only analysis is allowed. The conflict must be reported before implementation.

Unknown/ambiguous source authority is blocking only when it can materially affect approved semantics, precedence, compatibility, active scope or a user-requested conflict decision. Record clearly nonmaterial unknowns without freezing all work.

## Clean + dirty intersection

When `mode: CLEAN_PLUS_DIRTY_INTERSECTION`:

- the clean source defines scope and authority;
- dirty material is consulted only to clarify/enrich a matching requirement;
- unmatched dirty ideas/requirements are not implemented automatically;
- contradictory dirty content blocks mutation and is shown to the user;
- assistant/model content in dirty transcripts is ignored as requirement text unless user-adopted.
- if the user asks to consult previous specs/TZs, record them as historical sources; use them to detect compatibility/regression obligations, but never let them silently override the current clean/primary source.

## Backward compatibility

When intake says `compatibility_policy: STRICT_PRESERVE`, every changed public/API/config/persisted/CLI/retained legacy behavior must either remain compatible or have an explicit approved migration requirement. Task packets must include compatibility tests. Historical prior specs are evidence for previously promised behavior and regression constraints, not automatic authority over newer primary requirements.

## Source revision

Whenever approved authority, precedence, compatibility or normative content changes, increment `SOURCE_INTAKE.revision` / `SOURCE_INDEX.revision`. Task packets from older source revisions are stale and must not execute.
