# v0.7.2 implementation status

## Static/package status

Implemented in source:

- all v0.6 integration fixes;
- universal top-level `state_checkpoint` protocol;
- host checkpoint recovery steer and fail-closed cancellation;
- bounded tool-free finalization request;
- WORKING_STATE schema 6 with separate protocol-commit and prune-safe watermarks;
- task/universal checkpoint metadata with checkpoint id, state hash and session/source revision;
- context-pressure measurement from token-meter;
- SOFT warning context injection with hysteresis;
- HARD normal-request rejection;
- `/context` and context block in `/status`;
- structured `/compress` and `--dry-run` using DSH surface replacement;
- raw session archive preservation via replacement/source-event references;
- stock free-form compaction removed from qwen-v4 preset;
- v0.7 regression tests;
- dynamic remaining-validation reserve derived from actual TEST/REVIEW/ACCEPT role caps;
- host-owned ASK/AUTO execution policy with persistent exact allow/deny decisions;
- operation provenance for disposable ignored side effects and explicit nonpublishable out-of-write-set changes;
- `/compress` admission from contiguous prune-safe coverage only; `no_change` creates a protocol-only prune barrier that later ordinary commits cannot leapfrog;
- sequential runtime CASE numbering with stable `QV4-ADV-NNN` ids.

## Live qualification still required

Do not treat the following as proven until tested on the installed DSH 0.1.1-rc.1:

- actual middleware ordering of the new universal hooks;
- exact user-visible streaming behavior before a primary checkpoint;
- real ordinary-turn state checkpoint followed by finalization reinjection;
- actual token-meter values on the local web profile;
- SOFT warning visibility as a DSH context-injection card;
- HARD pressure cancellation UX;
- session surface replacement compatibility and measured post-compression reduction.

The previously qualified llama runtime remains 131072 context, 4:1 split, q8_0/q5_1 KV and custom CUDA FlashAttention all-quants.

- v0.7.2 closes command-plane parity for `/context` and `/compress`, including SOFT-offer acknowledgement routing and HARD-pressure recovery before model dispatch.

## v0.7.2 permission/publish boundary

`write_set` is publish intent, not a complete runtime sandbox. `/auto` removes interactive approval only for tools that are otherwise available. It does not disable worktree/donor confinement, `.dsh/.git` protection, budgets, source authority, checkpoint/context gates or acceptance rules. Proven ignored runtime caches remain disposable and are never staged; unexplained ignored changes and nonignored output outside `write_set` block completion/publication.
