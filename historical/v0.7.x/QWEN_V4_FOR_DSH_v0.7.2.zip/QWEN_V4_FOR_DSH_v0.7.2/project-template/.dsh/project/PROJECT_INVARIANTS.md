# Project invariants

- Preserve donor functionality unless an active normative requirement explicitly supersedes it.
- Never count shadow/sidecar/stub/placeholder work as canonical production integration when production integration is required.
- Green tests and proxy metrics do not substitute for a different user-visible outcome.
- Old packets cannot mutate after `source_revision` changes.
- `write_set` is publish intent, not the full execution sandbox. Shell/direct mutations remain confined to the disposable task worktree and require ASK approval unless execution mode is AUTO. Nonignored output outside `write_set` cannot be accepted/published until cleaned or scope-expanded; proven ignored runtime side effects remain disposable.
- One active mutator per project by default.
- Two evidence-backed failed hypotheses pause autonomous work rather than inviting an endless third patch.
- Do not hide failures/fallbacks/NOT_PROVEN evidence.
- Do not begin the next phase automatically.
- Requirement ledger entries retain exact source provenance and explicit active/superseded lifecycle; tasks cannot cite unknown or superseded requirement ids.
- `FULL_SPEC.md` is a deterministic generated projection of the ledger, never an independently editable authority.
- Raw hidden reasoning is not durable memory. Automatic goal continuation rehydrates explicit `WORKING_STATE.json`; dirty continuation is checkpoint-gated before further tools.

- Execution trust mode is host-owned (`/ask` default, explicit `/auto` override). AUTO suppresses interactive approval only; source authority, budgets, checkpoint/context gates, worktree/donor boundaries, evidence and acceptance invariants remain hard.
- Commit protocol coverage and compaction authority are separate: `no_change=true` never by itself advances the prune-safe watermark.
