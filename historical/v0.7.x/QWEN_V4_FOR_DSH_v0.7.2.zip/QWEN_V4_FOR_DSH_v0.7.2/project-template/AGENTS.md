# QWEN-V4 Project Instructions

Project authority lives in `.dsh/project/`. Use `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status`, `/context`, `/compress`, and human-only `/phase set <id>`. Execution trust is also human-controlled with slash-only `/ask` (default) and `/auto`; `/approve`/`/deny` resolve the pending exact execution request and `/permissions` inspects policy.
During `/work`, source-code mutation must occur only inside the disposable task worktree shown by `/status` and task packet. `write_set` names intended publishable output; authorized execution may create disposable runtime side effects, but nonignored output outside `write_set` cannot be accepted until cleaned or scope-expanded. Never mutate `.dsh/project` from model tools. Preserve donor functionality unless a current normative requirement explicitly supersedes it. Shadow/sidecar/stub work does not satisfy a requirement for canonical production integration. `task_done` advances only to `TEST_REQUIRED`; the host must run mandatory TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR gates. Test/review/acceptance failure becomes authoritative rework on the same worktree. `ACCEPTED` stops; next phase is never automatic.

During automatic continuation, obey the host checkpoint barrier: if required, call `task_checkpoint(mode="merge", ...)` before any other tool. Do not reconstruct discarded raw reasoning; continue from injected durable state and evidence.


Command-like natural-language workflow phrases may be routed by the host, but slash commands remain the deterministic API. Do not attempt to self-delegate mandatory roles.
