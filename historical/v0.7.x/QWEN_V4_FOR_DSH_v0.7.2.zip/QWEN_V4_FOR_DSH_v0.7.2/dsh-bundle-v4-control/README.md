# local-dsh-v4-control 0.7.2

Host-owned control bundle for QWEN-V4-FOR-DSH.

The bundle keeps DSH in control of source authority, task lifecycle, budgets, evidence, checkpoints and acceptance. v0.7 adds universal commit-before-answer and structured active-context compaction without introducing a second semantic memory table.

Important model-facing tools:

- `state_checkpoint` — ordinary top-level turn durable commit before finalization;
- `task_checkpoint` — active `/work` evidence-aware checkpoint;
- task terminal/scope/hypothesis tools from the existing worker protocol.

Important human commands:

- `/ask`, `/auto`, `/approve`, `/deny`, `/permissions` — host-owned execution approval policy (slash-only)
- `/status`
- `/context`
- `/compress [--dry-run]`
- `/triage`, `/task`, `/work`, `/review`, `/accept`, `/phase`

`WORKING_STATE.json` remains the canonical distilled semantic state. Raw historical reasoning is not durable memory.

The qwen-v4 preset deliberately does not activate stock free-form DSH compaction. v0.7.2 `/compress` shadows only prune-safe completed-turn history while the append-only raw session remains available for audit/recovery.


Execution permission is distinct from publication scope. In ASK, unknown `bash`/`pwsh`/`write`/`edit` actions require a remembered exact decision. AUTO suppresses that interactive approval but never disables hard host invariants. `write_set` remains the accepted Git-output contract; proven ignored execution side effects are disposable, while nonignored output outside `write_set` cannot be accepted until cleaned or scope-expanded.
