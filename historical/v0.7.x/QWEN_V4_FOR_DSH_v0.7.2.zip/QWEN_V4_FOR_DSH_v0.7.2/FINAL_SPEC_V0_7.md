# QWEN-V4-FOR-DSH — Final Specification v0.7.2

## 1. Architecture

DeepSeek Harness is the host runtime. Qwen3.8-27B is a bounded local executor. Project authority, lifecycle, budgets, guards, evidence, durable memory, and context-pressure policy are host-owned.

The canonical semantic memory is still the single `WORKING_STATE.json` structure:

- `known`
- `decisions`
- `evidence`
- `failed_hypotheses` — host-authoritative
- `do_not_repeat`
- `open_acceptance` — host-authoritative
- `next_action`

No `TURN_CAPSULE`, second summary table, or free-form compaction summary becomes an authority source.

Raw historical reasoning is not durable memory. The local llama profile keeps `--no-reasoning-preserve`; useful results are externalized into structured state.

## 2. Universal commit-before-answer

Every **top-level model-backed user-facing turn** in a controlled project uses this lifecycle:

```text
USER
  -> PRIMARY PHASE
       reasoning on
       normal mode-appropriate tools
       one or more model/tool steps
  -> mandatory state_checkpoint
  -> host schema/authority validation
  -> atomic WORKING_STATE merge + coverage metadata
  -> host reinjection
  -> FINALIZATION PASS
       reasoning off/low
       no tools
       no state mutation
       bounded output
  -> USER-FACING ANSWER
```

Host-only commands such as `/status`, `/context`, and `/compress` do not fabricate a model checkpoint because they do not create a model-backed answer.

A primary phase must explicitly produce either a semantic delta or `state_checkpoint(no_change=true)`. Missing checkpoint is a protocol failure, not an implicit no-change result.

`task_checkpoint` remains the evidence-aware `/work` specialization. A main `/work` worker continues using task checkpoint barriers and does not use the general conversation checkpoint.

Internal fresh roles (`SOURCE_CURATOR`, `TASK_PLANNER`, `TEST_ANALYST`, `REVIEWER`, `ACCEPTANCE_AUDITOR`) continue to return their typed schemas. Their tentative internal output is not automatically merged into `WORKING_STATE`.

### 2.1 Primary answer publication rule

The primary prompt requires the model to finish with a checkpoint tool call rather than a user-facing answer. A checkpoint call containing provisional text is rejected as a protocol violation. Finalization is requested only after commit.

DSH UI streaming behavior remains a live-qualification item: the plugin can reject an invalid primary assistant message and refuse terminal success, but v0.7.2 does not claim a custom core stream-buffer implementation until verified on the installed DSH build.

### 2.2 Ephemeral response basis

The checkpoint may include a bounded `response_basis` with:

- `conclusion`
- `details`
- `warnings`

It exists only between primary commit and finalization. It is not persisted as a second memory store and is discarded after finalization.

### 2.3 Commit coverage vs prune authority

Successful checkpoints update metadata only after schema/authority validation and atomic state persistence. `checkpoint_meta` includes:

- `checkpoint_id`
- `checkpoint_kind`
- `updated_at`
- `protocol_committed_through_seq`
- `prune_safe_through_seq`
- `session_revision`
- `source_revision`
- `state_hash`
- task evidence coverage where applicable

The two high-water marks are deliberately different:

- `protocol_committed_through_seq` means the commit-before-answer protocol completed successfully through that active-surface point;
- `prune_safe_through_seq` is the strictly smaller/equal prefix that `/compress` is allowed to shadow.

A substantive validated semantic delta may advance both only while the prune-safe watermark is still contiguous with prior protocol coverage. `state_checkpoint(no_change=true)` advances protocol coverage but **does not advance prune safety**, because protocol success is not proof that the raw turn contains no semantically important correction. Once such a protocol-only gap exists, later ordinary semantic commits must not leapfrog it; prune safety stays frozen at the last contiguous proven prefix. Raw session events are never deleted by either watermark.

## 3. Context-pressure gate

The host uses DSH token-meter/canonical session-surface measurement when available. The generic UI token badge is not the policy sensor.

```text
safe_headroom =
    context_window
  - estimated_next_input
  - completion_reserve
  - compression_recovery_reserve
  - safety_margin
```

Default v0.7 policy for the qualified 131072-token local runtime:

```text
context_window                        131072
completion_reserve_tokens             16384
compression_recovery_reserve_tokens    8192
safety_margin_tokens                    4096
soft_headroom_tokens                   24576
hard_headroom_tokens                    4096
hysteresis_tokens                       4096
min_recent_turns                           3
max_recent_tokens                      24000
```

All values are runtime-policy fields and must be empirically qualified; the architecture is not hard-coded to a specific 90K/105K prompt threshold.

Pressure states:

- `NORMAL`
- `SOFT_PRESSURE`
- `COMPACTION_REQUIRED`
- `UNKNOWN` if canonical measurement is unavailable

At SOFT pressure the host injects one deterministic DSH context notice per pressure episode. This does not consume a separate inference solely to phrase the warning. Hysteresis re-arms the warning only after recovery.

At COMPACTION_REQUIRED a normal top-level model request is rejected before llama context overflow. Recovery/inspection commands remain usable.

## 4. `/context`

`/context` is deterministic and model-free. It reports:

- context window
- estimated active/next input surface
- completion reserve
- compression recovery reserve
- safety margin
- safe headroom
- pressure state

`/status` includes the same pressure block plus whether a covered compaction prefix is currently available.

## 5. Structured `/compress`

Stock free-form `compaction-basic` and stock `/compact` are deliberately absent from the qwen-v4 preset. They must not become a second semantic source of truth.

`/compress` is a host-owned active-surface operation:

1. read the latest committed `WORKING_STATE` and `prune_safe_through_seq`;
2. measure the current tokenized surface;
3. identify only a contiguous **prune-safe** prefix composed of completed turns;
4. retain at least the configured recent completed turns verbatim;
5. never prune uncovered/current/incomplete material;
6. build one structured compaction snapshot containing the committed state and archive/source event references;
7. verify session revision and checkpoint id/state hash immediately before replacement;
8. atomically append a DSH surface replacement;
9. leave the raw append-only session log intact;
10. report before/after estimates.

`/compress --dry-run` performs planning and reports the candidate without changing the surface.

If recent whole-turn integrity causes the retained window to exceed `max_recent_tokens`, v0.7.2 keeps the whole turns and reports the advisory cap overrun rather than splitting a turn/tool pair unsafely. If the prune-safe prefix is insufficient to recover meaningful headroom, compaction fails closed rather than consuming protocol-only/no-change coverage.

Compaction is refused while a project operation or `/work` task is active. The active task must checkpoint/pause/finish first.

## 5.1 Natural-language command-plane routing

Slash syntax is an explicit escape hatch, not the only supported interface. The existing conservative phrase router also recognizes the new context operations.

Read-only examples routed directly to `/context` include `сколько контекста осталось?`, `покажи состояние контекста`, and `show context`. Because this operation is model-free and non-mutating, narrowly defined question forms are allowed.

Mutation is stricter. Imperatives such as `сожми контекст`, `освободи контекст`, or `compress history` route to `/compress`; phrases such as `покажи что будет сжато` or `preview context compression` route to `/compress --dry-run`. Questions (`можно сжать контекст?`), negations (`не сжимай контекст`), hypotheticals, quoted examples, and explanatory discussion never auto-run compaction.

When the host has emitted a SOFT-pressure compression offer, an ephemeral `compression_offer` state is armed. Only during that episode may a short acknowledgement such as `да`, `окей`, or `сжимай` mean `/compress`. Without that host offer the same acknowledgement is ordinary chat. A successful non-dry-run compression clears the offer. Explicit/natural compression routing executes in the command plane before the universal HARD-pressure model gate, so it remains usable as a recovery path when normal inference is blocked.

## 6. Execution permission policy

Execution authorization is host-owned and stored in `.dsh/project/EXECUTION_POLICY.json`. Default mode is `ask`. Trust-mode commands are deliberately slash-only and are not recognized through the natural-language workflow router.

Human commands:

- `/ask` — unknown gated shell/mutation actions require an explicit remembered decision;
- `/auto` — otherwise available gated execution/mutation actions do not require an interactive approval;
- `/approve` — persist ALLOW for the current exact normalized pending action;
- `/deny` — persist DENY for the current exact normalized pending action;
- `/permissions` — inspect mode, remembered rule counts and pending approval.

The initial gated tool set is shell/direct mutation (`bash`, `pwsh`, `write`, `edit`). Rules are exact normalized signatures, not model-written wildcard policy. The policy file is host-owned; Qwen cannot directly edit permission decisions.

In `/ask`, a new unknown action is denied before execution and becomes the single persistent pending approval. During autonomous `/work`, hitting a new approval blocks/cancels that goal instance instead of burning automatic rounds; after `/approve`, `/work` resumes the same task/worktree. Remembered DENY remains denied in ASK.

`/auto` disables **only interactive execution approval**. It does not disable worktree/donor confinement, reserved `.dsh/.git` guards, source authority, phase ownership, budgets, checkpoint barriers, context hard admission, evidence/acceptance integrity, or local-only model routing.

### 6.1 Execution scope vs publish scope

`write_set` is the intended **publishable task output** contract, not a complete prediction of every file a permitted command may touch. Authorized execution may create side effects inside the disposable task worktree. The host records newly changed out-of-publish-scope paths with originating operation/permission provenance:

- ignored side effects produced by an approved/AUTO operation are `ephemeral_ignored`; they are disposable and never staged/published;
- nonignored paths outside `write_set` are `unpublishable`; they may exist during execution but block `task_done`, validation and publication until removed or admitted through task scope expansion;
- ignored changes without proven execution provenance remain fail-closed validation blockers;
- reserved worktree paths, donor-root changes and project-authority changes remain immediate hard violations regardless of AUTO.

## 7. Budget accounting

v0.6 exact-cap fixes remain in force. `state_checkpoint` and `task_checkpoint` are protocol tools and do not consume the ordinary **per-turn tool-call** anti-runaway counter. Their real DSH events/tokens still exist and remain visible to absolute/session/task accounting where the underlying DSH exposes them.

Worker admission also protects a **dynamic remaining-validation reserve** derived from the configured role maxima, rather than trusting a smaller static number. With the default v0.7.2 caps:

```text
IMPLEMENTING / before TEST:  TEST + REVIEW + ACCEPT = 11 req / 32K reasoning / 13K visible / 30 tools / 25 min
after TEST:                  REVIEW + ACCEPT        =  7 req / 20K reasoning /  8K visible / 18 tools / 15 min
after REVIEW:                ACCEPT                 =  3 req /  8K reasoning /  3K visible /  6 tools /  5 min
after ACCEPT:                                        0
```

If per-role caps are lowered by runtime policy, the effective reserve is re-derived from those actual caps. The worker may consume exactly its permitted boundary but cannot begin the next request/epoch once the remaining validation share would be invaded.

Finalization receives its own request cap (`4096` tokens default) and reasoning effort (`off` default). v0.7 does not claim complete provider-level separation of every protocol token from the global DSH counters until live qualification proves the installed 0.1.1-rc.1 accounting surface.

## 8. Authority boundaries

Universal conversation checkpointing cannot:

- create or supersede `ACTIVE_REQUIREMENTS`;
- alter source authority or source revision;
- forge acceptance truth;
- overwrite host-owned failed-hypothesis or open-acceptance state;
- bypass `/triage`, `/review`, or `/accept` policy.

An active task owned by another session blocks universal conversation state mutation fail-closed.

## 9. Local-only composition

The v0.6 local-only hardening remains:

- default agent model pinned to `llama-local/qwen3.8-27b`;
- `session-title-llm` disabled;
- `web-search-deepseek` disabled;
- `llm-deepseek` disabled;
- session telemetry plugin disabled;
- qwen-v4 preset exposes no web tool by default.

## 10. Runtime baseline

Qualified target-machine llama baseline remains:

- llama.cpp build 10566 / commit `bb4caa754`
- custom CUDA FlashAttention all-quants build
- Qwen3.8-27B Q4_K_M
- context 131072
- split `4,1`
- KV `q8_0/q5_1`
- FlashAttention on
- fit off
- reasoning medium / 6144 block budget
- historical reasoning preservation off

## 11. Qualification status

Package-level tests are required before shipping. The following are **live acceptance items**, not claims made by static tests:

- installed DSH 0.1.1-rc.1 hook compatibility for universal turn continuation;
- real `state_checkpoint -> WORKING_STATE -> finalization reinjection` wire trace;
- no historical reasoning in the final rendered Qwen prompt;
- actual SOFT/HARD pressure behavior using installed token-meter;
- actual surface replacement and post-compression token reduction;
- user-visible handling of invalid primary provisional text/streaming.
