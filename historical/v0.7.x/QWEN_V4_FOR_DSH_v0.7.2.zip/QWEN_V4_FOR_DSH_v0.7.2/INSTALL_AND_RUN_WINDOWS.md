# Install and run v0.7.2 on Windows

Prerequisites: Git project, DSH web profile, local llama-server, Qwen3.8-27B GGUF. The target-machine overlay assumes the already-qualified `C:\DSH-QWEN` layout.

## Generic install

```powershell
Set-ExecutionPolicy -Scope Process Bypass

.\INSTALL_V0_7_WINDOWS.ps1 `
  -ProjectRoot C:\path\to\git-repo `
  -DshHome C:\DSH-QWEN\dsh-home
```

The installer:

- installs `dist\local-dsh-v4-control-0.7.2.tgz` into the DSH web profile;
- installs the `qwen-v4` preset;
- installs/merge-missing Project Pack files;
- writes runtime policy as UTF-8 without BOM;
- refuses to overwrite an existing `.dsh` by default.

For an existing controlled project use `-ExistingProjectPolicy MergeMissing` only after reviewing migration impact.

## Target machine qualification install

From the package root:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\_LOCAL_C_DSH-QWEN\02-install-v072-qualification.ps1
```

Default qualification project:

```text
C:\DSH-QWEN\qualification-v072
```

Then start the qualified local model:

```powershell
& "C:\DSH-QWEN\start-qwen38-128k.ps1"
```

Verify the file/config/model layer:

```powershell
.\_LOCAL_C_DSH-QWEN\03-verify-live.ps1
```

Start DSH:

```powershell
& "C:\DSH-QWEN\start-dsh-qwen.cmd" "C:\DSH-QWEN\qualification-v072"
```

Create a **new** session:

```text
Workspace: C:\DSH-QWEN\qualification-v072
Preset:    qwen-v4
Provider:  llama-local
Model:     qwen3.8-27b
```

## First v0.7.2 commands

```text
/status
/context
/permissions
```

Execution permission mode defaults to `ASK`. To let the controlled agent execute available shell/direct mutation tools without interactive approval, use `/auto`. Return to remembered-approval mode with `/ask`. Trust-mode commands are slash-only. In ASK, use `/approve` or `/deny` for the one pending exact action; an autonomous `/work` blocked for approval is resumed with `/work` after approval.

`/status` now includes deterministic context-pressure values and compaction availability. `/context` prints only the context block.

For safe compaction inspection:

```text
/compress --dry-run
```

A real `/compress` is only admitted when `prune_safe_through_seq` proves a safe completed-turn prefix. A `no_change=true` checkpoint advances protocol coverage but does not grant pruning authority, and later ordinary commits cannot leapfrog that protocol-only gap. Raw session history is retained; only the recurring active model surface is replaced.

## Universal commit live qualification

Send an ordinary user message (not `/work`) and inspect the DSH trajectory/wire. Expected lifecycle:

```text
primary model step(s)
state_checkpoint tool call
host WORKING_STATE commit
next model step with QWEN-V4 FINALIZATION PASS injection
user-visible final answer
```

A model attempting to stop without checkpoint should receive one checkpoint-only steer by default. Finalization has no tools and defaults to reasoning `off`, max 4096 output tokens.

## Runtime policy

`project-template\.dsh\project\RUNTIME_POLICY.json` contains the v0.7 runtime sections. The effective validation reserve is derived dynamically from the remaining TEST/REVIEW/ACCEPT role caps; the template full-chain reserve is 11 requests / 32K reasoning / 13K visible / 30 tools / 25 minutes.

```json
{
  "universal_commit": {
    "checkpoint_recovery_attempts": 1,
    "response_basis_max_chars": 8000,
    "finalization_max_tokens": 4096,
    "finalization_reasoning_effort": "off"
  },
  "context_pressure": {
    "context_window": 131072,
    "completion_reserve_tokens": 16384,
    "compression_recovery_reserve_tokens": 8192,
    "safety_margin_tokens": 4096,
    "soft_headroom_tokens": 24576,
    "hard_headroom_tokens": 4096,
    "hysteresis_tokens": 4096,
    "min_recent_turns": 3,
    "max_recent_tokens": 24000
  }
}
```

These are policy defaults, not claimed final tuning. Qualify pressure thresholds against real prompt surfaces before production use.

## Model runtime baseline

The target launcher remains:

```text
ctx 131072
tensor split 4,1
K q8_0
V q5_1
FlashAttention on
fit off
reasoning medium / 6144
no reasoning preserve
API key local
```

## Local-only behavior

The bundle pins the DSH fallback model to local Qwen and disables stock DeepSeek session-title, DeepSeek LLM/search route, and session telemetry rows in the composed web profile. The qwen-v4 preset also omits web and stock free-form compaction.
