# QWEN-V4-FOR-DSH v0.7.2

DeepSeek Harness remains the host runtime and Qwen3.8-27B remains the bounded local executor. v0.7.2 is a narrow release-candidate patch over v0.7.1: it keeps the universal memory/context design and closes validation-reserve, execution-permission, side-effect-provenance, compaction-coverage, and qualification-bookkeeping gaps.

1. **Universal commit-before-answer** for ordinary top-level model turns.
2. **Context-pressure gate + structured `/compress`** using checkpoint coverage rather than free-form transcript summary.

Read `FINAL_SPEC_V0_7.md` and `HARDENING_V0_7.md` for normative behavior.

## What changed in v0.7.2

- validation reserve is now derived dynamically from the **remaining mandatory validation chain**: TEST+REVIEW+ACCEPT -> REVIEW+ACCEPT -> ACCEPT -> 0;
- default full reserve now matches current role maxima: 11 requests / 32K reasoning / 13K visible / 30 tools / 25 min;
- new host-owned execution permission policy in `.dsh/project/EXECUTION_POLICY.json`; default mode is `/ask`;
- new slash-only commands `/ask`, `/auto`, `/approve`, `/deny`, `/permissions`; trust mode is deliberately not phrase-routed;
- `/ask` remembers exact normalized allow/deny decisions; an autonomous `/work` goal that reaches a new approval requirement is blocked instead of burning goal rounds and can resume after `/approve` + `/work`;
- `/auto` disables only interactive execution approval for otherwise available agent tools; worktree confinement, reserved paths, budgets, source authority, checkpoint/context gates and acceptance/evidence rules stay hard;
- `write_set` is clarified as the **publishable output contract**, while approved/AUTO execution may create disposable runtime side effects;
- ignored side effects created by an approved/AUTO operation receive operation provenance and are never staged as accepted output; unexplained ignored changes remain validation blockers;
- nonignored changes outside `write_set` may occur during authorized execution but remain unpublishable until cleaned or admitted through task scope expansion;
- checkpoint coverage is split into `protocol_committed_through_seq` and `prune_safe_through_seq`; `state_checkpoint(no_change=true)` advances only protocol coverage and creates a prune barrier that later ordinary commits cannot leapfrog;
- `/compress` uses only the prune-safe watermark, remains manual, and fails closed if safe coverage is insufficient;
- runtime adversarial suite is renumbered sequentially and every case now has a stable `QV4-ADV-NNN` audit id.

## What changed from v0.6

- new model-facing `state_checkpoint` for ordinary main-session turns;
- existing `task_checkpoint` remains the stricter `/work` specialization;
- ordinary model turns now follow primary phase -> checkpoint -> reinjection -> bounded finalization;
- canonical semantic memory is still only `WORKING_STATE` (`known`, `decisions`, `evidence`, `failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`);
- checkpoint metadata carries checkpoint id, state hash, session/source revision, plus separate protocol-commit and prune-safe active-surface watermarks;
- new host commands `/context`, `/compress`, `/compress --dry-run`;
- natural-language command-plane routing now covers `/context`, `/compress`, and compression dry-run; a bare acknowledgement such as `да`/`окей` routes to `/compress` only while a host SOFT-pressure compression offer is active;
- `/status` includes deterministic context-pressure and compaction availability;
- SOFT context pressure gives a host-generated DSH context notice; HARD pressure rejects an unsafe ordinary model request before llama overflow;
- stock qwen-v4 `compaction-basic` / `/compact` is removed so it cannot become a second memory authority;
- `/compress` preserves the raw session archive and only shadows a proven-covered completed-turn prefix from the recurring model surface;
- protocol checkpoint calls do not consume the ordinary per-turn tool anti-runaway budget;
- all v0.6 local-only, BOM, budget-boundary and structured-output fixes remain.

## Install

Portable/normal installer:

```powershell
.\INSTALL_V0_7_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home
```

Direct DSH plugin install:

```powershell
dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.7.2.tgz"
```

For the already-qualified target machine layout use:

```powershell
.\_LOCAL_C_DSH-QWEN\02-install-v072-qualification.ps1
```

It targets a new `C:\DSH-QWEN\qualification-v072` project so earlier qualification trees can remain untouched.

## First live checks

After llama-server and DSH are running in a **new** qwen-v4 session at the v0.7 qualification repo:

```text
/status
/context
```

Then test an ordinary user message and verify on the wire that it performs:

```text
primary Qwen request
-> state_checkpoint
-> WORKING_STATE update
-> finalization Qwen request with updated state
-> final user answer
```

Then use `/compress --dry-run` before testing a real surface replacement.

## Static release status

The package validator, existing regression suite, v0.6 hardening suite, and new v0.7 context/memory tests must pass before the archive is produced. These static tests do **not** replace live DSH 0.1.1-rc.1 qualification; the exact hook/stream/surface behavior is explicitly left as a live acceptance item.
