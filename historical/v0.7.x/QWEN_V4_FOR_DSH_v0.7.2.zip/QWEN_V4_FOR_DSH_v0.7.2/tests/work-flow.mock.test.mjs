import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { ensureProject, initialState, saveState, saveTask } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-work-'));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.mkdirSync(path.join(root,'src'));fs.writeFileSync(path.join(root,'src','a.txt'),'a\n');git(root,'add','-A');git(root,'commit','-m','base')
const paths=ensureProject(root); const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='READY'; saveState(paths,state)
const task={schema_version:2,id:'T1',source_revision:1,objective:'change a',write_set:['src/a.txt'],preserve:[],replace:[],remove:[],add:[],forbidden:[],acceptance:['a changed'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{failed_hypotheses:[],worktree:null,baseline_commit:null,usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:null,epoch_start_seq:null,last_usage:null}}
saveTask(paths,task)
const hooks=new Map(), guards=[], commands=new Map(), tools=new Map(), goals=new WeakMap()
const ctx={logger:{warn(){}},on(n,f){hooks.set(n,f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)}},subagents:{async start(){throw new Error('not expected')}},goals:{get(a){return goals.get(a)},create(a,o){const g={id:'g',revision:1,phase:'active',activation:'armed',roundsStarted:0,maxGoalRounds:o.maxGoalRounds,objective:o.objective};goals.set(a,g);return g},clear(a){goals.delete(a)},complete(a){const g=goals.get(a);if(g)g.phase='complete'},block(a,_r,b){const g=goals.get(a);if(g){g.phase='blocked';g.blocker=b}}}}
apply(ctx,{maxGoalRounds:6})
const agent={id:'A',session:{id:'S',header:{cwd:root},events:[]},cancel(){}}
const res=await commands.get('work').handler({agent,rawInput:'',signal:new AbortController().signal}); assert.equal(res.kind,'success');assert.match(res.text,/goal rounds: 0\/6/)
const g=goals.get(agent);assert.equal(g.maxGoalRounds,6)
const auto=await commands.get('auto').handler({agent}); assert.equal(auto.kind,'success')
const saved=JSON.parse(fs.readFileSync(path.join(paths.taskPackets,'T1.json'),'utf8'));assert.ok(saved.execution.worktree);assert.equal(saved.execution.epoch_session_id,'S')
const inside={name:'write',arguments:{file_path:path.join(saved.execution.worktree,'src','a.txt')},agent};assert.equal(guards[0](inside),undefined)
const donor={name:'write',arguments:{file_path:path.join(root,'src','a.txt')},agent};assert.match(guards[0](donor),/DIRECT_WRITE_DENIED/)
const st=JSON.parse(fs.readFileSync(paths.state,'utf8'));st.source_revision=2;fs.writeFileSync(paths.state,JSON.stringify(st));assert.match(guards[0](inside),/STALE_PACKET/)
console.log('work-flow.mock.test.mjs: PASS')
