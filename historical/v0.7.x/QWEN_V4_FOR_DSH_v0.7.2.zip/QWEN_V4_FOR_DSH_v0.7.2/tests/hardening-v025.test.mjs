import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { VALIDATION_RESERVE, workerReserveExceeded, roleReadGuard, accountRoleReadResult, addRoleUsageToTask, combineTaskUsage } from '../dsh-bundle-v4-control/lib/role-control.js'
import { validateEvidenceRefs } from '../dsh-bundle-v4-control/lib/evidence.js'
import { ensureProject, initialState, loadState, loadTask, saveState, saveTask, _lockTest } from '../dsh-bundle-v4-control/lib/state.js'
import { changedPaths, createTaskWorktree, gitHead, ignoredSnapshot, stageAndPatch } from '../dsh-bundle-v4-control/lib/git.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v025-') { const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T'); fs.mkdirSync(path.join(root,'src')); fs.writeFileSync(path.join(root,'src','a.js'),'export const a=1\n'); git(root,'add','-A'); git(root,'commit','-m','base'); return root }
function ctxBase(commands, startImpl) { return { logger:{warn(){}}, agents:{get(){}}, on(){}, tools:{guard(){},register(){}}, commands:{register(d){commands.set(d.name,d)}}, goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}}, subagents:{start:startImpl ?? (async()=>{throw new Error('unexpected subagent')})} } }
function pkgRootForTest(){ return path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..') }

// 1) Worker reserve protects mandatory validation headroom.
{
  const budget={max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2}
  assert.equal(workerReserveExceeded({model_requests:18,reasoning_tokens:47000,visible_output_tokens:26000,tool_calls:89,active_execution_ms:0},budget,VALIDATION_RESERVE),undefined)
  assert.match(workerReserveExceeded({model_requests:19,reasoning_tokens:47000,visible_output_tokens:26000,tool_calls:89,active_execution_ms:0},budget,VALIDATION_RESERVE),/validation_reserve_max_model_requests/)
}

// 2) Deterministic qualification is fail-closed when REQUIRED and no commands exist.
{
  const root=repo('qv4-qual-'); const paths=ensureProject(root); const wt=path.join(root,'.dsh','runtime','worktrees','T'); const created=createTaskWorktree(root,wt,'T')
  const state=initialState(); state.source_revision=1; state.active_task_id='T'; state.task_state='TEST_REQUIRED'; saveState(paths,state)
  saveTask(paths,{schema_version:5,id:'T',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.js'],acceptance:['a'],qualification:{mode:'REQUIRED',rationale:'code change'},budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{...created,failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},role_usage:{},epoch_session_id:null,epoch_start_seq:null,token_accounting:{entries:{},latest_mode:'none'}}})
  const commands=new Map(); apply(ctxBase(commands),{tokenizerEndpoint:''}); const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const res=await commands.get('review').handler({agent,signal:new AbortController().signal})
  assert.equal(res.kind,'success'); assert.match(res.text,/BLOCKED_QUALIFICATION/); assert.equal(loadState(paths).task_state,'BLOCKED_QUALIFICATION')
}

// 3) Operation nonce prevents duplicate long review/test transactions.
{
  const root=repo('qv4-op-'); const paths=ensureProject(root); const wt=path.join(root,'.dsh','runtime','worktrees','T'); const created=createTaskWorktree(root,wt,'T')
  fs.writeFileSync(path.join(paths.taskPackets,'T.BASELINE_INVENTORY.json'),'{}'); fs.writeFileSync(path.join(paths.taskPackets,'T.PRESERVE_CONTRACT.json'),'{}')
  const state=initialState(); state.source_revision=1; state.active_task_id='T'; state.task_state='TEST_REQUIRED'; saveState(paths,state)
  saveTask(paths,{schema_version:5,id:'T',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.js'],acceptance:['a'],qualification:{mode:'NOT_APPLICABLE',rationale:'fixture'},budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{...created,failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},role_usage:{},epoch_session_id:null,epoch_start_seq:null,token_accounting:{entries:{},latest_mode:'none'}}})
  let resolveRun; const pending=new Promise(r=>{resolveRun=r}); const commands=new Map(); const ctx=ctxBase(commands,async(_p,req)=>({localAgent:undefined,result:pending,async dispose(){}})); apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const first=commands.get('review').handler({agent,signal:new AbortController().signal})
  await new Promise(r=>setTimeout(r,20)); assert.equal(loadState(paths).task_state,'TESTING'); assert.ok(loadState(paths).operation?.nonce)
  const second=await commands.get('review').handler({agent,signal:new AbortController().signal}); assert.equal(second.kind,'error'); assert.match(second.text,/TESTING/)
  const ev=[{type:'file',path:path.join(wt,'src','a.js'),line_start:1,line_end:1}]
  resolveRun({stopReason:'completed',structured:{pass:false,summary:'stop',evidence:ev,findings:[{id:'x',severity:'blocking',message:'x',evidence:ev}],tests_to_add:[]}})
  await first
}

// 4) Fresh-role reads are path bounded and reject symlink escapes.
{
  const root=repo('qv4-read-'); const outside=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-out-')); fs.writeFileSync(path.join(outside,'secret.txt'),'secret')
  const ctx={role:'REVIEWER',budget:{max_read_result_bytes:1000},read_bytes:0,allowedRoots:[root],projectRoot:root}
  const agent={session:{header:{cwd:root}}}
  assert.match(roleReadGuard({name:'read',arguments:{file_path:path.join(outside,'secret.txt')},agent},ctx),/ROLE_READ_PATH_DENIED/)
  try { fs.symlinkSync(path.join(outside,'secret.txt'),path.join(root,'link.txt')) } catch {}
  if (fs.existsSync(path.join(root,'link.txt'))) assert.match(roleReadGuard({name:'read',arguments:{file_path:path.join(root,'link.txt')},agent},ctx),/symlink\/junction escape/)
}

// 5) Typed evidence validates referential integrity, not semantic truth.
{
  const root=repo('qv4-ev-'); const f=path.join(root,'src','a.js');
  const ledger={requirements:[{id:'REQ-1',status:'active'}]}
  assert.equal(validateEvidenceRefs([{type:'file',path:f,line_start:1,line_end:1},{type:'requirement',requirement_id:'REQ-1'}],{roots:[root],ledger}).ok,true)
  assert.equal(validateEvidenceRefs([{type:'file',path:path.join(root,'missing.js')}],{roots:[root],ledger}).ok,false)
  assert.equal(validateEvidenceRefs([{type:'requirement',requirement_id:'REQ-X'}],{roots:[root],ledger}).ok,false)
}

// 6) Ignored runtime output is never staged into the accepted Git patch; provenance/policy is enforced above stageAndPatch in v0.7.2.
{
  const root=repo('qv4-ignpub-'); fs.writeFileSync(path.join(root,'.gitignore'),'.env\n'); git(root,'add','.gitignore'); git(root,'commit','-m','ignore')
  const wt=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'qv4-wtbase-')),'task'); const created=createTaskWorktree(root,wt,'T'); fs.writeFileSync(path.join(wt,'.env'),'A=1\n')
  assert.ok(changedPaths(wt,created.baseline_commit,created.worktree_ignored_baseline).includes('.env'))
  const patch=stageAndPatch(wt,created.baseline_commit,created.worktree_ignored_baseline); assert.doesNotMatch(patch,/A=1/)
}

// 7) Strict ignored .env content is detected even if size+mtime are restored.
{
  const root=repo('qv4-ignstrict-'); fs.writeFileSync(path.join(root,'.gitignore'),'.env\n'); fs.writeFileSync(path.join(root,'.env'),'AAAA'); git(root,'add','.gitignore'); git(root,'commit','-m','ignore')
  const before=ignoredSnapshot(root); const st=fs.statSync(path.join(root,'.env')); fs.writeFileSync(path.join(root,'.env'),'BBBB'); fs.utimesSync(path.join(root,'.env'),st.atime,st.mtime); const after=ignoredSnapshot(root)
  assert.notEqual(before['.env'],after['.env'])
}

// 8) Same-host dead PID lock is reclaimed immediately (no six-hour wait).
{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-lock-')); const lock=path.join(dir,'project.lock'); fs.mkdirSync(lock); fs.writeFileSync(path.join(lock,'owner.json'),JSON.stringify({pid:2147483000,hostname:os.hostname(),nonce:'dead',acquired_at_ms:Date.now()}))
  const t=Date.now(); const owner=await _lockTest.acquireProcessLock(lock,{timeoutMs:2000,staleMs:6*60*60*1000}); assert.ok(Date.now()-t<1500); _lockTest.releaseProcessLock(lock,owner)
}

// 9) Phase is human-only command and changing it stales a nonterminal packet.
{
  const root=repo('qv4-phase-'); const paths=ensureProject(root); const st=initialState(); st.source_revision=1; st.current_phase='P1'; st.active_task_id='T'; st.task_state='READY'; saveState(paths,st); saveTask(paths,{id:'T',source_revision:1,execution:{}})
  const commands=new Map(); apply(ctxBase(commands),{tokenizerEndpoint:''}); const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const res=await commands.get('phase').handler({agent,rawInput:'set P2'}); assert.equal(res.kind,'success'); const now=loadState(paths); assert.equal(now.current_phase,'P2'); assert.equal(now.task_state,'STALE')
}

// 10) Fresh-role usage is part of the same global atomic-task ledger.
{
  const task={execution:{role_usage:{}}}
  addRoleUsageToTask(task,'TEST_ANALYST',{model_requests:2,reasoning_tokens:3000,visible_output_tokens:1200,tool_calls:3,active_execution_ms:1000})
  addRoleUsageToTask(task,'REVIEWER',{model_requests:1,reasoning_tokens:1500,visible_output_tokens:600,tool_calls:1,active_execution_ms:500})
  const global=combineTaskUsage({model_requests:10,reasoning_tokens:20000,visible_output_tokens:8000,tool_calls:20,active_execution_ms:5000,failed_hypotheses:1},task)
  assert.equal(global.model_requests,13); assert.equal(global.reasoning_tokens,24500); assert.equal(global.visible_output_tokens,9800); assert.equal(global.tool_calls,24); assert.equal(global.active_execution_ms,6500)
}

// 11) Fresh-role read-result bytes are cumulative and fail closed.
{
  const roleCtx={role:'TEST_ANALYST',budget:{max_read_result_bytes:32},read_bytes:0,violation:null}
  const exec={name:'read'}
  accountRoleReadResult(roleCtx,exec,{value:'1234567890'})
  assert.equal(roleCtx.violation,null)
  accountRoleReadResult(roleCtx,exec,{value:'abcdefghijklmnopqrstuvwxyz'})
  assert.match(roleCtx.violation,/ROLE_READ_BUDGET_EXCEEDED/)
}

// 12) /review persists real fresh-role session usage into the atomic task budget.
{
  const root=repo('qv4-roleusage-'); const paths=ensureProject(root); const wt=path.join(root,'.dsh','runtime','worktrees','T'); const created=createTaskWorktree(root,wt,'T')
  fs.writeFileSync(path.join(paths.taskPackets,'T.BASELINE_INVENTORY.json'),'{}'); fs.writeFileSync(path.join(paths.taskPackets,'T.PRESERVE_CONTRACT.json'),'{}')
  const state=initialState(); state.source_revision=1; state.active_task_id='T'; state.task_state='TEST_REQUIRED'; saveState(paths,state)
  saveTask(paths,{schema_version:5,id:'T',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.js'],acceptance:['a'],qualification:{mode:'NOT_APPLICABLE',rationale:'fixture'},budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{...created,failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},role_usage:{},epoch_session_id:null,epoch_start_seq:null,token_accounting:{entries:{},latest_mode:'none'}}})
  let seq=0; const commands=new Map();
  const ctx=ctxBase(commands,async(_provider,req)=>{
    seq+=1
    const roleAgent={session:{id:`R${seq}`,header:{cwd:root,parentSession:'S'},events:[
      {seq:1,time:1000,type:'step/start',data:{turn:1,step:1}},
      {seq:2,time:1100,type:'assistant/message',data:{turn:1,step:1,usage:{outputTokens:100,reasoningTokens:60},message:{content:[{type:'reasoning',text:'x'},{type:'text',text:'y'}]}}},
      {seq:3,time:1200,type:'tool/call',data:{}},
      {seq:4,time:1500,type:'step/end',data:{turn:1,step:1}},
    ]}}
    const ev=[{type:'file',path:path.join(wt,'src','a.js'),line_start:1,line_end:1}]
    const structured=req.label==='test-analyst'?{pass:true,summary:'ok',evidence:ev,findings:[],tests_to_add:[]}:{pass:true,summary:'ok',evidence:ev,findings:[]}
    return {localAgent:roleAgent,result:Promise.resolve({stopReason:'completed',structured}),async dispose(){}}
  })
  apply(ctx,{tokenizerEndpoint:''}); const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const res=await commands.get('review').handler({agent,signal:new AbortController().signal}); assert.equal(res.kind,'success')
  const task=loadTask(paths,'T'); assert.equal(task.execution.role_usage.TEST_ANALYST.total.model_requests,1); assert.equal(task.execution.role_usage.REVIEWER.total.model_requests,1); assert.equal(task.execution.role_usage.TEST_ANALYST.total.reasoning_tokens,60); assert.equal(task.execution.role_usage.REVIEWER.total.tool_calls,1)
}

console.log('hardening-v025.test.mjs: PASS')

// 13) Real /task -> /work path executes without hidden undefined identifiers and creates the bounded goal/worktree.
{
  const root=repo('qv4-taskwork-'); const paths=ensureProject(root)
  fs.writeFileSync(paths.toolchain, JSON.stringify({focused_tests:[],regression_tests:[]},null,2))
  const commands=new Map(); let activeGoal=null
  const planner={
    objective:'change a', requirement_refs:[], preserve:['existing public surface'], replace:[], remove:[], add:['small change'], forbidden:['no shadow-only'],
    write_set:['src/a.js'], acceptance:['src/a.js remains valid'], qualification:{mode:'NOT_APPLICABLE',rationale:'fixture exercises control path only'}, budget:{}
  }
  const ctx={
    logger:{warn(){}}, agents:{get(){}}, on(){}, tools:{guard(){},register(){}},
    commands:{register(d){commands.set(d.name,d)}},
    goals:{
      get(){return activeGoal},
      create(_agent,{objective,maxGoalRounds}){ activeGoal={id:'G1',revision:1,phase:'active',objective,maxGoalRounds}; return activeGoal },
      clear(){activeGoal=null}, block(){}, complete(){ if(activeGoal) activeGoal.phase='complete' },
    },
    subagents:{start:async()=>({localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:planner}),async dispose(){}})},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const planned=await commands.get('task').handler({agent,rawInput:'change a',signal:new AbortController().signal})
  assert.equal(planned.kind,'success'); assert.equal(loadState(paths).task_state,'READY')
  const started=await commands.get('work').handler({agent})
  assert.equal(started.kind,'success'); assert.match(started.text,/goal rounds: 0\/6/)
  const st=loadState(paths); const task=loadTask(paths,st.active_task_id)
  assert.equal(st.task_state,'IN_PROGRESS'); assert.equal(st.worker_session_id,'S'); assert.ok(fs.existsSync(task.execution.worktree)); assert.equal(activeGoal.maxGoalRounds,6)
}

// 14) Active model-visible project material contains no obsolete OpenCode tier/orchestration fossils.
{
  const pkgRoot=pkgRootForTest()
  const bases=[path.join(pkgRoot,'project-template','.dsh','skills'),path.join(pkgRoot,'project-template','.dsh','project')]
  const bad=[]; const patterns=[/model_class\s*:\s*cheap/i,/route to Pro/i,/Mark each task `cheap`/i,/scripts\/agent_task\.py/i,/task_graph\.json/i,/claims\.json/i]
  const walk=(dir)=>{for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else{const t=fs.readFileSync(p,'utf8');for(const re of patterns)if(re.test(t))bad.push(`${p}:${re}`)}}}
  for(const b of bases)walk(b)
  assert.deepEqual(bad,[])
}

// 15) Installer treats DSH_HOME as first-class and entrypoint is actually split into command/module layers.
{
  const pkgRoot=pkgRootForTest()
  const installer=fs.readFileSync(path.join(pkgRoot,'INSTALL_V0_7_WINDOWS.ps1'),'utf8')
  assert.match(installer,/\$env:DSH_HOME/); assert.match(installer,/\$DshHome/)
  const indexLines=fs.readFileSync(path.join(pkgRoot,'dsh-bundle-v4-control','index.js'),'utf8').split(/\r?\n/).length
  assert.ok(indexLines<900,`index.js should stay split, got ${indexLines} lines`)
  assert.ok(fs.existsSync(path.join(pkgRoot,'dsh-bundle-v4-control','lib','commands.js')))
}

// 16) Large bulk ignored state is monitored without full content hashing, while policy marks it non-cryptographic.
{
  const root=repo('qv4-ignbulk-'); fs.writeFileSync(path.join(root,'.gitignore'),'bulk.bin\n'); git(root,'add','.gitignore'); git(root,'commit','-m','ignore')
  fs.writeFileSync(path.join(root,'bulk.bin'),Buffer.alloc(1024*1024+4096,7))
  const snap=ignoredSnapshot(root); assert.match(snap['bulk.bin'],/bulk-metadata$/)
  const policy=fs.readFileSync(path.join(pkgRootForTest(),'project-template','.dsh','project','IGNORED_POLICY.md'),'utf8')
  assert.match(policy,/not presented as cryptographic content integrity/i)
}

// 17) Typed command evidence validates against actual deterministic command result ids.
{
  const root=repo('qv4-evcmd-'); const ledger={requirements:[]}; const runs=[{id:'CMD-001'}]
  assert.equal(validateEvidenceRefs([{type:'command',command_result_id:'CMD-001'}],{roots:[root],ledger,commandResults:runs}).ok,true)
  assert.equal(validateEvidenceRefs([{type:'command',command_result_id:'CMD-999'}],{roots:[root],ledger,commandResults:runs}).ok,false)
}
