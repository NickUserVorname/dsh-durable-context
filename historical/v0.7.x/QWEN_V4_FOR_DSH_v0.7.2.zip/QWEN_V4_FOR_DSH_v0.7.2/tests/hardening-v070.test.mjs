import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { commitUniversalWorkingState, validateUniversalCheckpoint } from '../dsh-bundle-v4-control/lib/context-memory.js'
import { planStructuredCompaction } from '../dsh-bundle-v4-control/lib/context-pressure.js'
import { ensureProject, atomicWriteJson } from '../dsh-bundle-v4-control/lib/state.js'
import { DEFAULT_RUNTIME_POLICY } from '../dsh-bundle-v4-control/lib/runtime-policy.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(){const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-v070-'));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.writeFileSync(path.join(root,'README.md'),'x\n');git(root,'add','-A');git(root,'commit','-m','base');return root}
function pkgRoot(){return path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')}

// 1) Universal checkpoint schema has explicit no-change semantics.
assert.equal(validateUniversalCheckpoint({no_change:true}).ok,true)
assert.equal(validateUniversalCheckpoint({known:['x']}).ok,true)
assert.match(validateUniversalCheckpoint({no_change:true,known:['x']}).reason,/CONFLICT/)
assert.match(validateUniversalCheckpoint({}).reason,/EMPTY/)

// 2) A top-level user model turn receives universal state + commit instruction,
//    checkpoint is persisted, protocol tool does not consume normal tool budget,
//    and finalization is tool-free/low-cost.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const hooks=new Map(),guards=[],tools=new Map(),commands=new Map(); let cancelled=[]; let steered=[]
  const ctx={
    logger:{warn(){},error(){}},
    tokenMeter:{measure(){return {totalTokens:1000,surfaceTokens:1000,nodes:[{seq:1,tokens:100}]}},estimateMessage(){return 100}},
    sessions:{async flush(){}},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},
    tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}},
  }
  apply(ctx,{tokenizerEndpoint:''})
  assert.ok(tools.has('state_checkpoint')); assert.ok(commands.has('context')); assert.ok(commands.has('compress'))
  const session={id:'S',seq:1,header:{cwd:root},surface:{nodes:[1]},events:[{seq:1,type:'user/message',data:{message:{role:'user'}}}]}
  const agent={id:'A',session,cancel(x){cancelled.push(x)},steer(x){steered.push(x)}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  const entered=await pre({agent,messages:[{role:'user',source:{kind:'user'},content:[{type:'text',text:'hello'}]}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  assert.equal(entered.kind,'enter')
  const injected=entered.messages.map(m=>m.content?.[0]?.text??'').join('\n')
  assert.match(injected,/DURABLE WORKING STATE SNAPSHOT/); assert.match(injected,/COMMIT-BEFORE-ANSWER PRIMARY PHASE/)

  // checkpoint call is an assistant tool-call with no provisional visible text
  session.events.push({seq:2,type:'assistant/message',data:{turn:1,step:1,message:{content:[{type:'tool-call',name:'state_checkpoint'}]}}})
  session.surface.nodes.push(2); session.seq=2
  const cp=tools.get('state_checkpoint')
  const result=await cp.execute({known:['durable fact'],response_basis:{conclusion:'answer'}},{agent})
  assert.equal(result.ok,true); assert.ok(result.checkpoint_id); assert.equal(result.protocol_committed_through_seq,2); assert.equal(result.prune_safe_through_seq,2)
  const saved=JSON.parse(fs.readFileSync(paths.workingState,'utf8')); assert.deepEqual(saved.known,['durable fact']); assert.ok(saved.checkpoint_meta.state_hash)

  const finalEntered=await pre({agent,messages:[],turn:1,step:2},async()=>({kind:'enter',messages:[]}))
  assert.match(finalEntered.messages[0].content[0].text,/FINALIZATION PASS/)
  const protocolGuard=guards.at(-1)
  assert.match(protocolGuard({name:'read',arguments:{},agent}),/FINALIZATION_TOOL_DENIED/)
  const requestHook=(hooks.get('agent/request')??[]).at(-1)
  const req=await requestHook({agent,turn:1,step:2},async()=>({maxTokens:16000,reasoningEffort:'medium'}))
  assert.equal(req.maxTokens,4096); assert.equal(req.reasoningEffort,'off')
  assert.equal(cancelled.length,0)
}

// 3) A model that tries to stop without checkpoint is steered exactly into a
//    checkpoint-only recovery phase, then fail-closes after the configured bound.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const hooks=new Map(),guards=[],tools=new Map(); const ctx={
    logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:100,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(){},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}},
  }; apply(ctx,{tokenizerEndpoint:''})
  let steered=0,cancelled=0; const session={id:'S',seq:0,header:{cwd:root},surface:{nodes:[]},events:[]}; const agent={id:'A',session,steer(){steered++},cancel(){cancelled++}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1); await pre({agent,messages:[{source:{kind:'user'}}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  const stop=(hooks.get('agent/turn-stopping')??[]).at(-1); await stop({agent,turn:1}); assert.equal(steered,1)
  assert.match(guards.at(-1)({name:'read',arguments:{},agent}),/STATE_CHECKPOINT_REQUIRED/)
  await stop({agent,turn:1}); assert.equal(cancelled,1)
}

// 4) Structured compaction plans only a covered completed-turn prefix and
//    keeps the configured recent completed turns verbatim.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const events=[]; const surface=[]; let seq=0
  for(let turn=1;turn<=4;turn++){
    events.push({seq:++seq,type:'user/message',data:{message:{role:'user'}}}); surface.push(seq)
    events.push({seq:++seq,type:'turn/start',data:{turn}})
    events.push({seq:++seq,type:'assistant/message',data:{turn,message:{content:[{type:'text',text:`a${turn}`}]}}}); surface.push(seq)
    events.push({seq:++seq,type:'turn/end',data:{turn,reason:{kind:'completed'}}})
  }
  const session={id:'S',seq,header:{cwd:root},events,surface:{nodes:surface}}
  let working=JSON.parse(fs.readFileSync(paths.workingState,'utf8'))
  working=commitUniversalWorkingState(working,{known:['K']},{session,sourceRevision:0})
  atomicWriteJson(paths.workingState,working)
  const ctx={tokenMeter:{measure(){return {totalTokens:800,nodes:surface.map(s=>({seq:s,tokens:100}))}},estimateMessage(){return 80}}}
  const plan=planStructuredCompaction(ctx,{session}, {paths}, {dryRun:true})
  assert.equal(plan.ok,true); assert.deepEqual(plan.retainedRecentTurns,[2,3,4]); assert.deepEqual(plan.shadowedSeqs,[1,3]); assert.equal(plan.start,1); assert.equal(plan.end,3)
}

// 5) v0.7 preset does not enable stock free-form compaction; package policy
//    contains context-pressure + universal-commit sections.
{
  const preset=fs.readFileSync(path.join(pkgRoot(),'dsh-preset-qwen-v4','agent.cordis.yml'),'utf8')
  assert.doesNotMatch(preset,/@deepseek-ai\/dsh-compaction-basic/); assert.doesNotMatch(preset,/@deepseek-ai\/dsh-command-compact/)
  const policy=JSON.parse(fs.readFileSync(path.join(pkgRoot(),'project-template','.dsh','project','RUNTIME_POLICY.json'),'utf8'))
  assert.equal(policy.schema_version,'qwen-v4-runtime-policy-0.7.2'); assert.equal(policy.context_pressure.context_window,131072); assert.equal(policy.universal_commit.finalization_max_tokens,4096)
}

console.log('hardening-v070.test.mjs: PASS')
