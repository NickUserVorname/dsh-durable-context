import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { ensureProject } from '../dsh-bundle-v4-control/lib/state.js'
import { DEFAULT_RUNTIME_POLICY, loadRuntimePolicy, normalizeRuntimePolicy, remainingValidationRoles, roleBudgetFor, validationReserveFor, validateBudgetEnvelope } from '../dsh-bundle-v4-control/lib/runtime-policy.js'

// External policy can lower frozen role/task ceilings. validation_reserve is
// derived from validation role maxima rather than trusted as an independent knob.
{
  const p=normalizeRuntimePolicy({
    task_budget_defaults:{max_reasoning_tokens:60000},
    validation_reserve:{max_reasoning_tokens:15000}, // accepted only for upgrade compatibility; not authoritative
    roles:{TEST_ANALYST:{max_reasoning_tokens:9000,max_tokens_per_request:4096,max_input_chars:24000}}
  })
  assert.equal(p.task_budget_defaults.max_reasoning_tokens,60000)
  assert.equal(p.validation_reserve.max_reasoning_tokens,9000+12000+8000)
  assert.equal(p.roles.TEST_ANALYST.max_tokens_per_request,4096)
  assert.equal(p.roles.TEST_ANALYST.max_input_chars,24000)
}

// Policy cannot silently raise the compiled safety ceiling.
{
  const p=normalizeRuntimePolicy({
    task_budget_defaults:{max_reasoning_tokens:999999},
    validation_reserve:{max_reasoning_tokens:999999},
    roles:{TEST_ANALYST:{max_tokens_per_request:999999}}
  })
  assert.equal(p.task_budget_defaults.max_reasoning_tokens,DEFAULT_RUNTIME_POLICY.task_budget_defaults.max_reasoning_tokens)
  assert.equal(p.validation_reserve.max_reasoning_tokens,DEFAULT_RUNTIME_POLICY.validation_reserve.max_reasoning_tokens)
  assert.equal(p.roles.TEST_ANALYST.max_tokens_per_request,DEFAULT_RUNTIME_POLICY.roles.TEST_ANALYST.max_tokens_per_request)
}

// Per-project RUNTIME_POLICY.json is live-loaded; dynamic reserve follows the
// remaining mandatory validation chain.
{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-policy-'))
  fs.mkdirSync(path.join(root,'.git'))
  const paths=ensureProject(root)
  fs.writeFileSync(paths.runtimePolicy,JSON.stringify({
    task_budget_defaults:{max_model_requests:20,max_reasoning_tokens:50000,max_visible_output_tokens:30000,max_tool_calls:80,max_active_execution_minutes:60,max_failed_hypotheses:2},
    validation_reserve:{max_model_requests:6,max_reasoning_tokens:12000,max_visible_output_tokens:9000,max_tool_calls:16,max_active_execution_minutes:20},
    roles:{
      TEST_ANALYST:{max_model_requests:3,max_reasoning_tokens:9000,max_visible_output_tokens:4000,max_tool_calls:10,max_active_execution_minutes:8,max_tokens_per_request:4096,max_input_chars:20000,max_read_result_bytes:16000},
      REVIEWER:{max_model_requests:4,max_reasoning_tokens:11000,max_visible_output_tokens:5000,max_tool_calls:11,max_active_execution_minutes:9},
      ACCEPTANCE_AUDITOR:{max_model_requests:2,max_reasoning_tokens:7000,max_visible_output_tokens:2500,max_tool_calls:5,max_active_execution_minutes:4}
    }
  },null,2))
  const runtime={root,paths}
  const p=loadRuntimePolicy(runtime)
  assert.equal(p.task_budget_defaults.max_model_requests,20)
  assert.deepEqual(remainingValidationRoles('IN_PROGRESS'),['TEST_ANALYST','REVIEWER','ACCEPTANCE_AUDITOR'])
  assert.deepEqual(remainingValidationRoles('REVIEW_REQUIRED'),['REVIEWER','ACCEPTANCE_AUDITOR'])
  assert.deepEqual(remainingValidationRoles('ACCEPTANCE_REQUIRED'),['ACCEPTANCE_AUDITOR'])
  assert.deepEqual(remainingValidationRoles('ACCEPTED'),[])
  assert.equal(validationReserveFor(runtime,'IN_PROGRESS').max_reasoning_tokens,27000)
  assert.equal(validationReserveFor(runtime,'REVIEW_REQUIRED').max_reasoning_tokens,18000)
  assert.equal(validationReserveFor(runtime,'ACCEPTANCE_REQUIRED').max_reasoning_tokens,7000)
  assert.equal(validationReserveFor(runtime,'ACCEPTED').max_reasoning_tokens,0)
  assert.equal(roleBudgetFor(runtime,'TEST_ANALYST').max_tokens_per_request,4096)
  assert.equal(roleBudgetFor(runtime,'TEST_ANALYST').max_input_chars,20000)
}

// Tiny task budgets fail immediately instead of leaving zero worker headroom.
{
  const reserve={max_model_requests:11,max_reasoning_tokens:32000,max_visible_output_tokens:13000,max_tool_calls:30,max_active_execution_minutes:25}
  assert.throws(()=>validateBudgetEnvelope(
    {max_model_requests:11,max_reasoning_tokens:32000,max_visible_output_tokens:13000,max_tool_calls:30,max_active_execution_minutes:25},reserve
  ),/TASK_BUDGET_TOO_SMALL_FOR_MANDATORY_VALIDATION/)
  assert.equal(validateBudgetEnvelope(
    {max_model_requests:12,max_reasoning_tokens:32001,max_visible_output_tokens:13001,max_tool_calls:31,max_active_execution_minutes:26},reserve
  ),true)
}

// Typos/unknown policy fields fail closed instead of being silently ignored.
{
  assert.throws(()=>normalizeRuntimePolicy({roles:{TEST_ANALYST:{max_tokenz_per_request:1234}}}),/RUNTIME_POLICY_UNKNOWN_FIELD/)
  assert.throws(()=>normalizeRuntimePolicy({roles:{MYSTERY_ROLE:{max_tokens_per_request:1234}}}),/RUNTIME_POLICY_UNKNOWN_FIELD/)
}

console.log('runtime-policy.test.mjs: PASS')
