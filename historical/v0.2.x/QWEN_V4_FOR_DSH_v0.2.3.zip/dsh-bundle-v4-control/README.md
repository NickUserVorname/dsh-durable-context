# local-dsh-v4-control 0.2.3

Host-side QWEN-V4 control plane for DeepSeek Harness. It registers `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status`, task-control tools, source-revision/write-set enforcement, bounded goals, task budgets, forced distilled checkpoints, disposable Git-worktree publication, high-precision host intent routing, and mandatory test/review/acceptance gates.

The model does **not** receive `tool-goal` or a generic subagent tool. DSH goal state and goal-round-driver remain host-side. Native Windows shell containment outside the selected workspace is reported as degraded/not proven rather than mislabelled HARD.

v0.2.3 adds:

- a high-precision natural-language workflow-intent router that executes registered host slash commands without spending a main-model turn; ambiguous/questions/negations remain ordinary chat;
- a mandatory fresh read-only `TEST_ANALYST` role between implementation and independent review, plus deterministic configured test commands and same-worktree rework on failure;
- request-wide reasoning-output-starvation detection and one bounded action-only rescue request with `reasoningEffort=off`; repeated starvation pauses the task;
- corrected reasoning guarantee: llama.cpp `--reasoning-budget` is treated as a per-reasoning-block budget, while DSH `maxTokens` is the hard request-wide completion cap.
