# Install and run on Windows

This is the v0.2.3 launch path. It assumes a Git project, current DSH, llama-server and the already selected Qwen3.8-27B Q4_K_M GGUF.

## 1. Prerequisites

- Git on PATH.
- Node.js + pnpm.
- DSH runnable as `dsh` or `npx @deepseek-ai/dsh`.
- llama-server build that supports Qwen3.8 and the reasoning flags used here.
- Project root must itself be the Git toplevel.
- A clean donor tree is recommended but not required; v0.2.3 snapshots donor state when `/work` begins and refuses publish if the donor changes underneath the task. Only `.dsh/runtime/` is automatically excluded from Git worktree noise.

## 2. Install the v4-control bundle into DSH Web profile

From this package directory:

```powershell
# If dsh is globally installed:
dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.2.3.tgz"

# Or with npx:
npx @deepseek-ai/dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.2.3.tgz"
```

DSH treats a package declaring `dsh.bundle.patch` as an out-of-tree profile layer.

## 3. Install the per-session Qwen preset

```powershell
$dst = Join-Path $HOME ".dsh\.agent-presets\qwen-v4"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item ".\dsh-preset-qwen-v4\*" $dst -Recurse -Force
```

This preset deliberately has no model-facing `tool-goal`, generic subagent/fork tools, Ralph/workflows or background jobs.
The host still owns goals, goal-round-driver, commands and the spawn provider.

## 4. Install the Project Pack into your project

Example project: `C:\Mini-whisper-bot`.

Do not blindly overwrite an existing `.dsh` state tree. For a fresh project integration:

```powershell
$project = "C:\Mini-whisper-bot"
Copy-Item ".\project-template\.dsh" "$project\.dsh" -Recurse

# Copy AGENTS.md only if the project does not already have one.
if (-not (Test-Path "$project\AGENTS.md")) {
    Copy-Item ".\project-template\AGENTS.md" "$project\AGENTS.md"
}
```

If `.dsh/project` already exists, merge/migrate intentionally rather than replacing it.

## 5. Configure the local model route

Merge `dsh-settings/llama-local.settings.example.yaml` into:

```text
%USERPROFILE%\.dsh\settings.yaml
```

Set a dummy local key (llama-server does not need to validate it, but the client route names a credential):

```powershell
$env:LLAMA_LOCAL_API_KEY = "local"
```

The example config sets `retryPolicy.maxRetries: 0`, so DSH does not turn one failed local model request into up to five hidden retries.

## 6. Start llama-server

First list devices:

```powershell
& "C:\path\to\llama-server.exe" --list-devices
```

Then:

```powershell
.\llama-server\start-qwen38-windows.ps1 `
  -LlamaServer "C:\path\to\llama-server.exe" `
  -Model "C:\models\Qwen3.8-27B-Q4_K_M.gguf" `
  -V100Device "<exact V100 id from --list-devices>" `
  -Rtx3070TiDevice "<exact 3070 Ti id from --list-devices>"
```

Baseline is 128K context, layer split 3:1 starting point, Q5/Q4 KV, no MTP, MEDIUM reasoning, llama reasoning budget 6144 **per reasoning block**, and DSH total completion cap 16384/request.

## 7. Start DSH

```powershell
npx @deepseek-ai/dsh web
```

Open the Web UI. For a **new session**:

- workspace = your project Git root;
- the v4-control host maps this durable DSH `session.cwd` Git root to the Project Pack; process cwd is not used as project authority;
- multiple DSH sessions on the same Git root share `source_revision`/task state, while different Git roots are isolated;
- agent preset = `qwen-v4`;
- provider = `llama-local`;
- model = `qwen3.8-27b`.

A preset is session-scoped. Do not reuse an old session that was created under another preset.

## 8. Workflow

```text
/triage <new specs/corrections/transcripts/files>
/status
/task <one atomic objective>
/work
/review
/accept
```

`/work` creates a host-owned active goal with at most six rounds. Qwen cannot change that limit. `task_done` advances only to `TEST_REQUIRED`; the next `/review` first runs deterministic configured tests and the mandatory fresh TEST_ANALYST before the independent reviewer.

If review/acceptance fails, use `/work` again: v0.2.3 reuses the same disposable task worktree.

If a normative correction arrives while work is running, run `/triage` in any session. A changed revision marks the old packet `STALE`, blocks the goal and cancels the active worker.

`/accept` PASS publishes only the approved worktree changes. Then it **stops**. No next phase is started.



## 8a. Natural-language workflow routing

Explicit slash commands remain deterministic. v0.2.3 additionally recognizes a **small high-precision set** of command-like human phrases (for example `перейди к планированию`, `начинай реализацию`, `проверь всё`, `проведи приёмку`). The host executes the corresponding registered command and rejects the original main-model step, so Qwen does not spend tokens deciding the workflow transition.

Questions, negations, hypotheticals, quoted discussion, or unsupported wording are **not** routed and remain ordinary chat. If routing is ever surprising, use the explicit slash command.

## 8b. TEST_ANALYST and reasoning-starvation recovery

The TEST_ANALYST is a fresh read-only host spawn using the same physical `llama-local/qwen3.8-27b` sequentially. No second llama-server slot or persistent second KV context is required. Its selected input is bounded and its output is capped.

The global llama reasoning sampler budget is 6144 per reasoning block. Because current llama.cpp can re-arm that budget if another reasoning block starts in the same response, DSH `maxTokens=16384` remains the true request-wide completion cap. If reasoning starves the visible/tool reserve, host permits one bounded action-only rescue request with reasoning disabled; repeated starvation pauses the task instead of silently burning more goal rounds.

## 9. Windows write guard status

On native Windows:

```text
DIRECT_WRITE_GUARD: HARD
SHELL_WRITE_GUARD: DEGRADED_WINDOWS
SHELL_OUTSIDE_WORKSPACE: NOT_PROVEN
```

Direct `write/edit` is denied before execution outside packet `write_set`.
Shell is forced to use the disposable worktree and is diff-checked after every call, but native Windows sandbox enforcement does not prove that arbitrary PowerShell cannot touch an absolute path elsewhere. Do not read a green Git diff as proof of outside-workspace security.

## 10. Before real project mutation

Run the local test suite and then execute the runtime adversarial suite in a throwaway repository/session. The local test suite validates policy/worktree logic; it does **not** prove the package boots against the exact DSH release installed on your machine.
