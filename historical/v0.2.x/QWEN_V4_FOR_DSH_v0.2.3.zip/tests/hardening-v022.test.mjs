import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { createRuntime, ensureProject, initialState, loadState, loadTask, saveState, saveTask } from '../dsh-bundle-v4-control/lib/state.js'
import { checkpointPayloadValidation, emptyWorkingState, mergeWorkingState, projectWorkingState } from '../dsh-bundle-v4-control/lib/working-state.js'
import { createTaskWorktree, donorFingerprint, gitHead, removeTaskWorktree, unauthorizedPaths } from '../dsh-bundle-v4-control/lib/git.js'

function git(cwd,...args){ const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'}); if(r.status!==0) throw new Error(r.stderr||r.stdout); return r.stdout }
function initRepo(prefix='qv4-v022-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T'); fs.writeFileSync(path.join(root,'a.txt'),'a\n'); git(root,'add','-A'); git(root,'commit','-m','base'); return root
}

// 1) Cross-session ownership: every model-facing task terminal/control tool is owner-only.
{
  const root=initRepo('qv4-owner-'); const paths=ensureProject(root)
  const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='IN_PROGRESS'; state.worker_session_id='S1'; saveState(paths,state)
  const task={schema_version:4,id:'T1',source_revision:1,objective:'x',write_set:['a.txt'],acceptance:['must stay'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{worker_session_id:'S1',failed_hypotheses:[],worktree:root,baseline_commit:gitHead(root),worktree_ignored_baseline:{},pending_evidence:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:'S1',epoch_start_seq:0,token_accounting:{entries:{},latest_mode:'none'}}}; saveTask(paths,task)
  const tools=new Map(), hooks=new Map(), guards=[]
  const ctx={logger:{warn(){}},on(n,f){hooks.set(n,f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(){}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return {id:'g',revision:1}}},subagents:{async start(){throw new Error('n/a')}},agents:{get(){}}}
  apply(ctx,{tokenizerEndpoint:''})
  const other={id:'A2',session:{id:'S2',header:{cwd:root},events:[]},cancel(){}}
  for (const [name,args] of [
    ['task_failed_hypothesis',{hypothesis:'h',evidence:'e'}],
    ['task_done',{summary:'done',evidence:['e']}],
    ['task_blocked',{kind:'external',reason:'r',evidence:'e'}],
    ['task_scope_expansion',{requested_paths:['b.txt'],reason:'r'}],
  ]) {
    await assert.rejects(()=>tools.get(name).execute(args,{agent:other}),/owned by another session/)
    assert.equal(loadState(paths).task_state,'IN_PROGRESS')
    assert.equal(loadTask(paths,'T1').execution.failed_hypotheses.length,0)
  }
}

// 2) Checkpoint must cover all host pending evidence and cannot be empty when evidence is pending.
assert.equal(checkpointPayloadValidation({covered_evidence_ids:['EV-1'],known:[],decisions:[],evidence:[],do_not_repeat:[],next_action:[]},['EV-1']).ok,false)
assert.match(checkpointPayloadValidation({covered_evidence_ids:[],known:['x']},['EV-1']).reason,/COVERAGE_MISSING/)
assert.equal(checkpointPayloadValidation({covered_evidence_ids:['EV-1'],evidence:['EV-1: test result establishes X']},['EV-1']).ok,true)


// 2b) Actual model-facing checkpoint tool rejects formal empty coverage and cannot clear the barrier.
{
  const root=initRepo('qv4-emptycp-'); const paths=ensureProject(root)
  const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='IN_PROGRESS'; state.worker_session_id='S1'; saveState(paths,state)
  const task={schema_version:4,id:'T1',source_revision:1,objective:'x',write_set:['a.txt'],acceptance:['A1'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{worker_session_id:'S1',failed_hypotheses:[],worktree:root,baseline_commit:gitHead(root),worktree_ignored_baseline:{},pending_evidence:[{id:'EV-00001',tool:'read',outcome:'OK'}],evidence_seq:1,meaningful_since_checkpoint:1,steps_since_checkpoint:1,checkpoint_required:true,usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:'S1',epoch_start_seq:0,token_accounting:{entries:{},latest_mode:'none'}}}; saveTask(paths,task)
  const tools=new Map(),ctx={logger:{warn(){}},on(){},tools:{guard(){},register(d){tools.set(d.name,d)}},commands:{register(){}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}},agents:{get(){}}}
  apply(ctx,{tokenizerEndpoint:''})
  const owner={id:'A1',session:{id:'S1',header:{cwd:root},events:[]},cancel(){}}
  await assert.rejects(()=>tools.get('task_checkpoint').execute({mode:'merge',covered_evidence_ids:['EV-00001'],known:[],decisions:[],evidence:[],do_not_repeat:[],next_action:[]},{agent:owner}),/CHECKPOINT_EMPTY_FOR_PENDING_EVIDENCE/)
  assert.equal(loadTask(paths,'T1').execution.checkpoint_required,true)
  await tools.get('task_checkpoint').execute({mode:'merge',covered_evidence_ids:['EV-00001'],evidence:['EV-00001 establishes repository fact']},{agent:owner})
  assert.equal(loadTask(paths,'T1').execution.checkpoint_required,false)
  assert.deepEqual(JSON.parse(fs.readFileSync(paths.workingState,'utf8')).open_acceptance,['A1'])
}

// 3) open_acceptance is host-authoritative; omission does not erase it, and model payload has no authority over it.
{
  let ws=emptyWorkingState('T1')
  ws=mergeWorkingState(ws,{mode:'merge',known:['k'],covered_evidence_ids:[]},{taskId:'T1',hostOpenAcceptance:['A1','A2']})
  assert.deepEqual(ws.open_acceptance,['A1','A2'])
  ws=mergeWorkingState(ws,{mode:'merge',next_action:[]},{taskId:'T1',hostOpenAcceptance:['A2']})
  assert.deepEqual(ws.open_acceptance,['A2'])
  assert.deepEqual(ws.next_action,[])
}

// 4) Field-aware projection: huge known must never erase critical later fields.
{
  const ws=emptyWorkingState('T1')
  ws.known=Array.from({length:600},(_,i)=>`KNOWN-${i}-${'x'.repeat(120)}`)
  ws.decisions=['CRITICAL_DECISION']
  ws.evidence=['CRITICAL_EVIDENCE']
  ws.failed_hypotheses=[{hypothesis:'CRITICAL_FAIL',evidence:'E'}]
  ws.do_not_repeat=['CRITICAL_DNR']
  ws.open_acceptance=['CRITICAL_ACCEPT']
  ws.next_action=['CRITICAL_NEXT']
  const projection=projectWorkingState(ws,{maxChars:12000,pendingEvidence:[{id:'EV-9',tool:'read',outcome:'OK'}]})
  const text=JSON.stringify(projection)
  for (const marker of ['CRITICAL_DECISION','CRITICAL_EVIDENCE','CRITICAL_FAIL','CRITICAL_DNR','CRITICAL_ACCEPT','CRITICAL_NEXT','EV-9']) assert.match(text,new RegExp(marker))
  assert.equal(projection.projection_meta.field_aware,true)
  assert.ok(projection.projection_meta.omitted.known>0)
}

// 5) Gitignored worktree mutations are observable and checked against write_set; ignored donor changes affect donor fingerprint.
{
  const root=initRepo('qv4-ignore-')
  fs.writeFileSync(path.join(root,'.gitignore'),'.env\ncache.db\n'); git(root,'add','.gitignore'); git(root,'commit','-m','ignore')
  fs.writeFileSync(path.join(root,'.env'),'SECRET=1\n')
  const fp1=donorFingerprint(root); fs.writeFileSync(path.join(root,'.env'),'SECRET=2\n'); const fp2=donorFingerprint(root)
  assert.notEqual(fp1.hash,fp2.hash)
  const wt=path.join(root,'.dsh','runtime','worktrees','T1'); const created=createTaskWorktree(root,wt,'T1')
  fs.writeFileSync(path.join(wt,'cache.db'),'generated\n')
  assert.deepEqual(unauthorizedPaths(wt,created.baseline_commit,['a.txt'],created.worktree_ignored_baseline),['cache.db'])
  assert.deepEqual(unauthorizedPaths(wt,created.baseline_commit,['a.txt','cache.db'],created.worktree_ignored_baseline),[])
  fs.mkdirSync(path.join(wt,'.dsh','evil'),{recursive:true}); fs.writeFileSync(path.join(wt,'.dsh','evil','x.txt'),'x')
  assert.ok(unauthorizedPaths(wt,created.baseline_commit,['**'],created.worktree_ignored_baseline).some(x=>x.startsWith('.dsh/')))
  removeTaskWorktree(root,wt)
}

// 6) Process-shared lock: a second Node process cannot enter the same project critical section concurrently.
{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-lock-')); const log=path.join(root,'order.log')
  const stateUrl=pathToFileURL(path.resolve('/mnt/data/v022build/dsh-bundle-v4-control/lib/state.js')).href
  const childCode=`import fs from 'node:fs'; import {createRuntime,withRuntimeLock} from ${JSON.stringify(stateUrl)}; const [root,log,label,hold]=process.argv.slice(1); const rt=createRuntime(root); await withRuntimeLock(rt,async()=>{fs.appendFileSync(log,label+'-start\\n'); await new Promise(r=>setTimeout(r,Number(hold))); fs.appendFileSync(log,label+'-end\\n')});`
  const run=(label,hold)=>spawn(process.execPath,['--input-type=module','-e',childCode,root,log,label,String(hold)],{stdio:['ignore','pipe','pipe']})
  const wait=p=>new Promise((resolve,reject)=>{let err='';p.stderr.on('data',d=>err+=d);p.on('exit',c=>c===0?resolve():reject(new Error(err||`exit ${c}`)))})
  const a=run('A',350)
  for(let i=0;i<100 && (!fs.existsSync(log)||!fs.readFileSync(log,'utf8').includes('A-start'));i++) await new Promise(r=>setTimeout(r,10))
  const b=run('B',10); await Promise.all([wait(a),wait(b)])
  assert.deepEqual(fs.readFileSync(log,'utf8').trim().split(/\r?\n/),['A-start','A-end','B-start','B-end'])
}

console.log('hardening-v022.test.mjs: PASS')
