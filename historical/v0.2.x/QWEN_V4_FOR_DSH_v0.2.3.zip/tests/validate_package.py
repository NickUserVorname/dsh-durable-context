from pathlib import Path
import hashlib, json, tarfile, yaml
root=Path(__file__).resolve().parents[1]
required=[
 'dist/local-dsh-v4-control-0.2.3.tgz','dsh-bundle-v4-control/package.json','dsh-bundle-v4-control/cordis.patch.yml',
 'dsh-bundle-v4-control/lib/intent-router.js','dsh-bundle-v4-control/lib/test-gate.js',
 'dsh-preset-qwen-v4/agent.cordis.yml','dsh-settings/llama-local.settings.example.yaml','llama-server/start-qwen38-windows.ps1',
 'project-template/.dsh/project/state.json','project-template/.dsh/project/SOURCE_POLICY.md','project-template/.dsh/project/ACTIVE_REQUIREMENTS.json',
 'ADDENDUM_MODEL_GPU_REASONING_TUNING.md','FINAL_SPEC_V0_2_3.md','HARDENING_V0_2_3.md','INSTALL_V0_2_3_WINDOWS.ps1',
 'tests/hardening-v023.test.mjs','tests/checkpoint-barrier.mock.test.mjs','tests/checkpoint-force-pause.mock.test.mjs','tests/checkpoint-pre-goal.mock.test.mjs',
 'tests/RUNTIME_ADVERSARIAL_SUITE.md','PACKAGE_MANIFEST.json'
]
for r in required:
    assert (root/r).exists(), f'missing {r}'
for p in root.rglob('*.json'):
    if p.name == 'PACKAGE_MANIFEST.json':
        continue
    json.loads(p.read_text(encoding='utf-8'))
class Loader(yaml.SafeLoader): pass
Loader.add_constructor('tag:yaml.org,2002:js', lambda loader,node: loader.construct_scalar(node))
for p in list(root.rglob('*.yml'))+list(root.rglob('*.yaml')):
    yaml.load(p.read_text(encoding='utf-8'),Loader=Loader)
with tarfile.open(root/'dist/local-dsh-v4-control-0.2.3.tgz','r:gz') as t:
    names=set(t.getnames())
    for n in [
      'package/package.json','package/index.js','package/cordis.patch.yml','package/lib/core.js','package/lib/state.js','package/lib/git.js',
      'package/lib/ledger.js','package/lib/working-state.js','package/lib/token-accounting.js','package/lib/baseline.js',
      'package/lib/intent-router.js','package/lib/test-gate.js'
    ]:
        assert n in names, f'tgz missing {n}'
    pkg=json.loads(t.extractfile('package/package.json').read())
    assert pkg['version']=='0.2.3'
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest['version']=='0.2.3'
assert manifest['file_count']==len(manifest['files'])
for item in manifest['files']:
    p=root/item['path']
    assert p.exists(), f'manifest missing file {item["path"]}'
    data=p.read_bytes()
    assert len(data)==item['bytes'], f'manifest size mismatch {item["path"]}'
    assert hashlib.sha256(data).hexdigest()==item['sha256'], f'manifest hash mismatch {item["path"]}'
# Guard against stale release references in primary install docs.
for rel in ['README_FIRST.md','INSTALL_AND_RUN_WINDOWS.md','FINAL_SPEC_V0_2_3.md','HARDENING_V0_2_3.md','docs/IMPLEMENTATION_STATUS.md']:
    txt=(root/rel).read_text(encoding='utf-8')
    assert 'local-dsh-v4-control-0.2.2.tgz' not in txt, f'stale tgz ref in {rel}'
# Launcher guarantee must match current policy.
launcher=(root/'llama-server/start-qwen38-windows.ps1').read_text(encoding='utf-8')
assert '[int]$ReasoningBudget = 6144' in launcher
print('validate_package.py: PASS')
