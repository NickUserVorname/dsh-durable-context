# QWEN-V4-FOR-DSH v0.2.3

DeepSeek Harness is the runtime; OpenCode v4 is only the donor of source/task/acceptance semantics. v0.2.3 keeps the frozen architecture and adds the last agreed role/routing/reasoning hardening on top of v0.2.2.

## What v0.2.3 adds

- **Host-owned natural-language intent routing.** Exact command-like phrases such as `перейди к планированию`, `начинай реализацию`, `проверь всё`, `проведи приёмку` are routed by the host to registered DSH commands. The original main-model step is rejected, so the main Qwen does not spend a turn deciding which workflow transition to call. Questions, negations, hypotheticals and ambiguous discussion fail open to ordinary chat. Slash commands remain the deterministic escape hatch.
- **Mandatory TEST_ANALYST role.** `task_done` now means `TEST_REQUIRED`, not `REVIEW_REQUIRED`. The first stage of `/review` runs configured focused/regression commands and a fresh read-only `TEST_ANALYST`. FAIL produces authoritative rework findings and keeps the same worktree; PASS proceeds to the independent reviewer. Reviewer/acceptance remain mandatory host-owned roles.
- **Reasoning-output-starvation guard.** llama.cpp's reasoning budget is treated honestly as **per reasoning block**, not a hard request-wide reasoning cap. Baseline server budget is now 6144/block with DSH total completion <=16384/request. If a completed model step consumes >=10K reasoning while leaving <1024 visible/action tokens and no tool call, host steers one bounded action-only rescue and forces exactly the next request to `reasoningEffort=off`, `maxTokens<=4096`. Repeated starvation pauses the task.

All roles still use **one physical Qwen** and one `llama-server --parallel 1` slot sequentially. Fresh roles share selected durable project/task state, not the worker's raw transcript/reasoning.

## Install order (Windows)

1. Install/run DeepSeek Harness and llama.cpp separately.
2. Merge `dsh-settings/llama-local.settings.example.yaml` into `%USERPROFILE%\.dsh\settings.yaml`; set `LLAMA_LOCAL_API_KEY=local`.
3. Start Qwen with `llama-server/start-qwen38-windows.ps1` (first run `llama-server.exe --list-devices`).
4. Run `INSTALL_V0_2_3_WINDOWS.ps1 -ProjectRoot C:\path\to\your\git-project` or manually:
   - `dsh plugin --profile web add .\dist\local-dsh-v4-control-0.2.3.tgz`
   - copy `dsh-preset-qwen-v4` to `%USERPROFILE%\.dsh\.agent-presets\qwen-v4`
   - copy `project-template\.dsh` into the project root.
5. Restart DSH web and create a **new** session: workspace = project Git root, preset `qwen-v4`, provider `llama-local`, model `qwen3.8-27b`.
6. First command: `/status`.

## Normal workflow

`/triage` -> `/task` -> `/work` -> `/review` -> `/accept`.

`/review` is now a host pipeline: when task state is `TEST_REQUIRED`, it runs deterministic configured tests, then mandatory fresh TEST_ANALYST, and only on PASS runs the independent REVIEWER. TEST/REVIEW/ACCEPTANCE failure writes rework findings and `/work` resumes the same task/worktree.

Natural command-like phrases may be routed to the same command plane, but explicit slash commands remain authoritative.

`/work` continues the same main Qwen session through host goal rounds, max 6. `ACCEPTED` stops. The next phase never starts automatically.

Read `FINAL_SPEC_V0_2_3.md`, `HARDENING_V0_2_3.md`, `ADDENDUM_MODEL_GPU_REASONING_TUNING.md`, and `docs/IMPLEMENTATION_STATUS.md`.
