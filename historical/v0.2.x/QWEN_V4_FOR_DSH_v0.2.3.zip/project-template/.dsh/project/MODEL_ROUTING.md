# Inference / role policy (legacy filename retained for compatibility)

There is one physical local brain: Qwen3.8-27B Q4_K_M through llama.cpp. All roles run sequentially on the same `--parallel 1` server slot.

## Main worker

- persistent main DSH session / same transcript across bounded `/work` continuation;
- default reasoning effort: MEDIUM;
- LOW only for explicitly selected small well-normalized work;
- XHIGH only by host/user manual escalation;
- llama.cpp reasoning sampler budget: **6144 per reasoning block** (not a request-wide guarantee);
- DSH hard total completion cap: **16384 per model request**;
- if multiple reasoning blocks consume the action/output reserve, the host detects `REASONING_OUTPUT_STARVATION`, steers one action-only rescue step, and forces exactly the next request to `reasoningEffort=off`, `maxTokens<=4096`; repeated starvation pauses the task;
- raw hidden reasoning preservation: OFF by default; durable memory is explicit `WORKING_STATE`/evidence/checkpoint state.

## Host-owned ephemeral roles

The following are architectural roles but use fresh DSH `spawn` transport with selected state rather than inherited raw transcript:

- SOURCE_CURATOR (`/triage`);
- TASK_PLANNER (`/task`);
- TEST_ANALYST (mandatory first stage of `/review` after `TEST_REQUIRED`);
- REVIEWER;
- ACCEPTANCE_AUDITOR.

They use the same physical `llama-local/qwen3.8-27b` sequentially. The TEST_ANALYST input projection is bounded (default 64K characters, roughly a 10–16K-token target depending on content) and its total output is capped at 8192. It has read-only tools and cannot mutate the task.

There is no Pro/Flash model routing, model-controlled goal lifecycle, generic subagent tool, fork, swarm or second resident model context.

See repository-level `ADDENDUM_MODEL_GPU_REASONING_TUNING.md`.
