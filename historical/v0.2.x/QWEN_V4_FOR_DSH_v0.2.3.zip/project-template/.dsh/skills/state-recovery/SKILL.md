---
name: state-recovery
description: Recover source revision, active phase/task packet, claims, long runs, bugs and decisions from persisted repository state instead of compressed chat context.
---
# Recovery order

1. `git status` / current worktree facts.
2. Project `AGENTS.md`, `SOURCE_INTAKE.md` and current `source_revision`.
3. `CURRENT_PHASE.md` + invariants.
4. `.dsh/project/state.json` and `.dsh/project/task_graph.json`.
5. Active task packet; reject it if its source revision is stale.
6. `.dsh/project/claims.json` and handoffs.
7. Running long tasks via `scripts/agent_task.py status`.
8. Bug DB, decisions, last phase report and relevant diffs/tests.

Repository/runtime facts beat stale persisted claims. Normative source authority comes from source intake/index, not from a compacted chat summary.

After recovery, state the current source revision, active task, claims, long-run status and next safe action. Do not resume edits from a stale packet.
