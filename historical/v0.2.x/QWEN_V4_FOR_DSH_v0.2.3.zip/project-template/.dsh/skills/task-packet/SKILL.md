---
name: task-packet
description: Build a compact source-normalized implementation packet so a main implementation session never has to reinterpret the full or dirty source bundle.
---
# Purpose

A task packet is the only requirement authority a main implementation session should need in addition to current repository files and explicitly linked invariants.

# Staleness gate

Every packet records `source_revision`. If it differs from current source intake revision, the packet is STALE and must not execute. A user correction/source-precedence change invalidates affected READY packets before any further edit.

# Required fields

```yaml
task_id:
phase:
status: ready
model_class: cheap | pro
source_intake_status: READY
requirements:
  - id:
    text:
    source_id:
    source_location:
    authority:
compatibility_policy: NONE | STRICT_PRESERVE | EXPLICIT_MIGRATION
invariants:
  - exact invariant
scope:
  allowed_changes:
  forbidden_changes:
canonical_owners:
write_set:
dependencies:
acceptance_tests:
compatibility_tests:
negative_tests:
benchmark_owner: false
shared_mutable_resources: []
escalation_conditions:
expected_handoff:
```

# Rules

- Include only approved normalized requirements. Never paste a dirty transcript wholesale into a main-session packet.
- Preserve exact source provenance so fresh independent review can verify that no requirement was invented.
- State negative and backward-compatibility requirements explicitly.
- Identify the current canonical production owner from repository evidence, not desired architecture alone.
- Write sets must be concrete enough to detect overlap with another hand.
- If exact implementation algorithm is intentionally free, state which choices are free and which semantics are fixed.
- If real measured evidence is required, identify what makes evidence valid and what must not be used as a surrogate.
- If task scope cannot be made crisp, source authority is ambiguous, or repository reality contradicts the packet, route to Pro instead of guessing.
