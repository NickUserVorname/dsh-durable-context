# QWEN-V4-FOR-DSH v0.2.5

DeepSeek Harness is the runtime. OpenCode v4 remains only the donor of source/task/acceptance semantics. v0.2.5 keeps the frozen v0.2 architecture and closes the post-v0.2.4 P0/P1/P2 control-plane audit.

## What v0.2.5 adds

- **True whole-task budgets.** TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR usage is charged to the same atomic-task ledger as the persistent worker. Fresh roles also have per-role ceilings. Worker execution preserves a validation reserve so it cannot consume the resources required for mandatory validation.
- **Fail-closed qualification.** `qualification.mode=REQUIRED` with no configured focused/regression commands becomes `BLOCKED_QUALIFICATION`; `NOT_APPLICABLE` must be explicit task data with a rationale.
- **Validation operation leases.** Long TEST/REVIEW/ACCEPT transactions enter `TESTING` / `REVIEWING` / `ACCEPTING` with nonce, owner session, task id and source revision. A returned child result commits only if that exact operation still owns the state.
- **Bounded fresh-role reads.** Fresh roles may use only `read/grep/glob` within approved roots, with realpath/symlink checks and cumulative read-result byte ceilings. Initial prompt size is bounded separately from tool-result growth.
- **Typed evidence references.** File/range, diff, command-result, requirement and artifact/hash references are structurally validated by host. This proves referential integrity, not semantic truth.
- **Correct ignored-file publication semantics.** Ignored files are not publishable through the Git patch pipeline. Strict protected ignored state is content-hashed; very large/bulk ignored state uses bounded metadata monitoring instead of blindly hashing tens of gigabytes after every shell command.
- **Human-only phase transitions.** `/accept` never advances phase. `/phase set <id>` is the explicit host command.
- **Portable DSH home + better crash recovery.** Installer honors `DSH_HOME`; same-host definitely-dead process locks can be reclaimed immediately.
- **OpenCode fossil cleanup.** Active model-visible skills/project templates no longer contain old `cheap/pro`, Pro/Flash, `agent_task.py`, `task_graph.json`, claims/handoff runtime instructions that no longer exist.
- **Control-plane split.** Human-command orchestration moved to `lib/commands.js`; fresh-role, evidence, operation, usage and host-runtime logic remain separate modules instead of growing one monolithic `index.js`.

All prior protections remain: source revision/ownership, disposable worktree, direct write-set guard, ignored-file visibility, process-shared project lock, forced evidence-covered checkpoints, field-aware working-state projection, requirement supersession/provenance, deterministic FULL_SPEC, reasoning/visible token accounting, donor baseline inventory, bounded host goal, RU+EN state-aware intent grammar, mandatory TEST_ANALYST, and reasoning-output-starvation recovery.

## Install order (Windows)

1. Install/run DSH and llama.cpp separately.
2. Run:
   ```powershell
   .\INSTALL_V0_2_5_WINDOWS.ps1 -ProjectRoot C:\path\to\your\git-project
   ```
   The installer uses `$env:DSH_HOME` when set, otherwise `$HOME\.dsh`.
3. Merge `dsh-settings/llama-local.settings.example.yaml` into `<DSH_HOME>\settings.yaml`; set `LLAMA_LOCAL_API_KEY=local`.
4. Start Qwen with `llama-server/start-qwen38-windows.ps1` after checking `llama-server.exe --list-devices`.
5. Restart DSH web and create a **new** session: workspace = project Git root, preset `qwen-v4`, provider `llama-local`, model `qwen3.8-27b`.
6. Run `/status`.

Manual plugin install:

```powershell
dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.2.5.tgz"
```

## Normal workflow

```text
/triage <new specs/corrections/transcripts/files>
/status
/task <one atomic objective>
/work
/review
/accept
```

`task_done` advances only to `TEST_REQUIRED`. `/review` first enforces deterministic qualification, then mandatory TEST_ANALYST, then independent REVIEWER. `/accept` runs a fresh acceptance role and publishes only on PASS. TEST/REVIEW/ACCEPT failure writes authoritative rework findings and `/work` resumes the same task/worktree.

`/work` continues the same main Qwen session through a host-owned goal, max 6 rounds. Qwen cannot change that cap. `ACCEPTED` stops. The next phase never starts automatically; use `/phase set <id>` explicitly.

Natural command-like RU+EN phrases can route to the same host command plane, but slash commands remain authoritative and ambiguous/questions/negations/hypotheticals remain chat.

## Qualification status

Local syntax/regression/Git/process/portability tests are required for packaging and are rerun from a random extracted directory. This still does **not** replace the live installed-DSH adversarial suite on the target Windows host. Native Windows arbitrary shell writes outside the selected workspace remain `DEGRADED_WINDOWS / NOT_PROVEN`.

Read `FINAL_SPEC_V0_2_5.md`, `HARDENING_V0_2_5.md`, `ADDENDUM_MODEL_GPU_REASONING_TUNING.md`, `INSTALL_AND_RUN_WINDOWS.md`, and `docs/IMPLEMENTATION_STATUS.md`.
