# QWEN-V4-FOR-DSH v0.2.5 — host intent, mandatory test role, and request-wide reasoning hardening

v0.2.5 does **not** redesign the frozen v0.2 architecture. It consolidates the agreed role/routing/reasoning work and closes the post-v0.2.4 P0/P1/P2 control-plane audit.

## H1 — high-precision host intent router

Problem: registering `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status` does not mean a plain human phrase such as `перейди к планированию` will invoke the corresponding host transition. Leaving this to the main model recreates the old model-owned orchestration failure mode.

Implementation:

- `agent/pre-step` inspects only a single genuine user-source message on step 1;
- `workflowIntent()` matches only a small exact command-like phrase set;
- questions, negations, hypotheticals, quoted discussion, unsupported wording and overlong messages are not routed;
- on match, host calls `ctx.commands.execute(agent, slashCommand, signal)`;
- the original main-model step is rejected, so routing uses zero main-Qwen model requests;
- an audit record stores original text, routed command and command result;
- explicit slash commands remain the deterministic escape hatch.

This is **host intent dispatch**, not “Qwen guesses which command to call”.

## H2 — mandatory TEST_ANALYST role and feedback loop

Architectural roles are host-owned workflow stages, even when DSH transport is a fresh `spawn`.

`task_done` now transitions only to `TEST_REQUIRED`.

When `/review` sees `TEST_REQUIRED`:

1. host runs configured focused/regression commands from `TOOLCHAIN.json` in the disposable task worktree;
2. host persists deterministic results and verifies task scope/donor integrity;
3. if deterministic tests pass, host starts fresh read-only `TEST_ANALYST` using the same physical `llama-local/qwen3.8-27b` sequentially;
4. role input is selected/bounded (effective TEST_ANALYST initial projection <=48000 characters plus a cumulative 32768-byte read/grep/glob result ceiling); output is capped (`testRoleMaxTokens=8192`); no write/shell tools are exposed;
5. TEST_ANALYST FAIL -> `TEST_FAILED`, write `<task>.REWORK.json`, preserve same worktree, stop before reviewer;
6. `/work` on `TEST_FAILED` resumes the same worktree and receives the authoritative rework packet;
7. TEST_ANALYST PASS -> `REVIEW_REQUIRED`, then independent REVIEWER runs;
8. REVIEW/ACCEPTANCE FAIL also produce authoritative rework packets.

There is no persistent second model and no `--parallel 2`. The fresh role uses the one physical Qwen/server slot after the worker request has ended. It shares curated durable state/evidence, not inherited raw transcript/CoT.

## H3 — request-wide reasoning-output-starvation guard

Problem: current llama.cpp `--reasoning-budget` is a **per reasoning-block** sampler budget. If a model emits another reasoning start tag in the same response, the sampler can re-arm. Therefore the previous statement “8192 reasoning tokens per request” was too strong.

v0.2.5 baseline:

- `--reasoning-budget 6144` per reasoning block;
- DSH `maxTokens <= 16384` total completion per request;
- task cumulative reasoning <=80K / visible <=40K remain unchanged.

Main-worker starvation detector:

- after token accounting for a completed step, if there is no tool call;
- reasoning >=10000 tokens;
- visible/action output <1024 tokens;
- host records a starvation recovery and steers an action-only rescue step;
- exactly the next `agent/request` is rewritten to `reasoningEffort=off`, `maxTokens<=4096`;
- after the configured recovery count (default 2), another starvation transitions to `BUDGET_PAUSED` and blocks continuation.

This does not semantically inspect hidden CoT. It uses already-separated token accounting and the presence/absence of required action/tool output.

## H4 — retained v0.2.2 guarantees

All v0.2.2 hardening remains: worker ownership on terminal tools, ignored-file scope coverage, process-shared project lock, substantive evidence-covered checkpoints, field-aware WORKING_STATE projection, host-authoritative open acceptance, requirement supersession/provenance, donor baseline inventory, source revision/write-set/worktree guards and cumulative task budgets.

## Qualification status

Local regression/mock/Git/process tests cover the new router, mandatory test-role ordering/failure path and starvation rescue request. These tests do not replace a live installed-DSH adversarial run. Native Windows outside-workspace shell containment remains `DEGRADED_WINDOWS / NOT_PROVEN`.

## v0.2.5 — Intent grammar and packaging portability

- Natural workflow routing is deterministic and model-free: compositional RU+EN grammar, harmless discourse-filler normalization, explicit question/negation/hypothetical/quotation guards, and project-state-aware dispatch.
- Review commands now cover natural forms such as `проверь`, `проверь код`, `посмотри реализацию`, `review code`, and `check implementation`, but only route when the task state can legally enter review. Ambiguous/disallowed-state phrases remain ordinary chat; slash commands stay authoritative.
- Planning/work/review/accept routes are state-gated. `status` and explicit triage remain available regardless of task state. Explicit payload forms may contain negative requirements without being mistaken for command negation.
- No tiny LLM/classifier is used. Unknown language or ambiguous phrasing fails open to ordinary chat.
- Regression tests use package-relative imports via `import.meta.url`; build-machine absolute paths are prohibited by release validation.
- Release qualification must extract the ZIP to a fresh/random directory and run the complete local test set from that extracted copy.

# v0.2.5 P0/P1/P2 hardening

This release closes the post-v0.2.4 control-plane audit without changing the frozen architecture.

## Global task budget and validation reserve
- TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR usage is persisted into the same atomic-task ledger as worker usage.
- Fresh roles also have independent per-role ceilings.
- The worker is stopped before it can consume a protected validation reserve required for mandatory validation roles.

## Qualification
- Deterministic qualification is fail-closed. `qualification.mode=REQUIRED` with no configured focused/regression command becomes `BLOCKED_QUALIFICATION`.
- Only explicit `NOT_APPLICABLE` with rationale bypasses deterministic test commands.

## Operation leases
- Long validation transactions use `TESTING`, `REVIEWING`, `ACCEPTING` plus operation nonce/owner/revision.
- A returned child result commits only if the operation nonce and task/revision are still current.

## Fresh-role read boundary
- Fresh roles may only read/grep/glob approved roots.
- Absolute external paths and realpath/symlink escapes are denied.
- Cumulative tool-result bytes are bounded per role.

## Evidence
- TEST/REVIEW/ACCEPT outputs use typed evidence references.
- Host validates referential integrity (path/range, active requirement id, command result id, diff membership, artifact hash).
- This does **not** prove semantic truth; reviewer/acceptance remain responsible for relevance and meaning.

## Ignored files
- Gitignored paths are not valid publishable task output in the Git patch pipeline; such output is rejected instead of silently disappearing.
- Strict-protected ignored patterns such as env/config/key material receive content hashes.
- Large/bulk ignored state uses bounded metadata monitoring rather than blindly hashing multi-GB caches/models after every shell call. This is explicitly not a cryptographic content-integrity guarantee.

## Phase
- `current_phase` is host-managed but never model-advanced and never advanced by `/accept`.
- Human explicit `/phase set <id>` is the only phase transition command.

## Process lock and portability
- Same-host definitely-dead lock owners are reclaimed immediately; unverifiable/remote owners remain lease/TTL protected.
- Installer honors `DSH_HOME` first, falling back to `$HOME/.dsh`.

## Maintainability
- Control-plane orchestration was split out of the monolithic entrypoint into dedicated modules including `commands.js`, host runtime, execution usage, fresh-role execution, role control, typed evidence, operation leases, role schemas and role-result handling. Behavior remains test-covered.
