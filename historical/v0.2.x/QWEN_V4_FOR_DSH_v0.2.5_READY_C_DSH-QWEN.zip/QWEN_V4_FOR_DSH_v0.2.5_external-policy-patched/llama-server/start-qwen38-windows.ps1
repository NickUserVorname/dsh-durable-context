param(
  [Parameter(Mandatory=$true)][string]$LlamaServer,
  [Parameter(Mandatory=$true)][string]$Model,
  [Parameter(Mandatory=$true)][string]$V100Device,
  [Parameter(Mandatory=$true)][string]$RTX3070TiDevice,
  [int]$Context = 131072,
  [string]$TensorSplit = "3,1",
  [ValidateSet("low","medium","xhigh")][string]$ReasoningEffort = "medium",
  [int]$ReasoningBudget = 6144
)

& $LlamaServer `
  -m $Model `
  --device "$V100Device,$RTX3070TiDevice" `
  --n-gpu-layers all `
  --split-mode layer `
  --tensor-split $TensorSplit `
  --ctx-size $Context `
  --parallel 1 `
  --cache-type-k q5_0 `
  --cache-type-v q4_1 `
  --flash-attn auto `
  --jinja `
  --reasoning-format deepseek `
  --reasoning-effort $ReasoningEffort `
  --reasoning-budget $ReasoningBudget `
  --reasoning-budget-message "Reasoning budget reached. Use established evidence, persist useful state, then act or return a concise blocked handoff." `
  --no-reasoning-preserve `
  --metrics `
  --host 127.0.0.1 `
  --port 8080
