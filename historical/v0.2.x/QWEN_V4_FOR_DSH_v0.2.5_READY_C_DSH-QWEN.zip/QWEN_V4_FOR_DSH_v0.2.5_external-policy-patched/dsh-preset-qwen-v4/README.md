# qwen-v4 preset

Copy this directory to `%USERPROFILE%\.dsh\.agent-presets\qwen-v4`.

The main session is the persistent WORKER role. Mandatory SOURCE_CURATOR/TASK_PLANNER/TEST_ANALYST/REVIEWER/ACCEPTANCE_AUDITOR stages are host-owned and use fresh bounded DSH spawn transport on the same physical Qwen sequentially. The preset deliberately exposes no model-facing `tool-goal`, generic subagent/fork tool, Ralph, workflow loop or swarm.
