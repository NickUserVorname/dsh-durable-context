---
name: implementation-planner
description: Plan atomic implementation against active requirements, retained donor behavior, bounded scope and deterministic qualification.
---
# Implementation planner

1. Resolve the exact active requirement IDs and provenance.
2. Inspect the repository to identify the real production owner/call path.
3. Record donor behavior that must be preserved.
4. Define the smallest atomic objective and `write_set`.
5. Define forbidden substitutions/removals explicitly.
6. Define focused acceptance and negative/regression tests before implementation.
7. Set `qualification.mode=REQUIRED` unless tests are genuinely not applicable; `NOT_APPLICABLE` needs a concrete rationale.
8. Keep the packet within host budget ceilings and validation reserve.
9. If scope/source/repository reality is materially ambiguous, stop with `BLOCKED_SPEC` or request explicit scope expansion; do not invent another model tier or hidden workflow.
