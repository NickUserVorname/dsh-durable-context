---
name: state-recovery
description: Recover current project authority and task state from the active Project Pack/runtime files.
---
# State recovery

Read the current implementation's authoritative files only:
1. `.dsh/project/state.json` — source revision, human-owned phase, active task, task state, operation lease.
2. `.dsh/project/SOURCE_INDEX.json`, `ACTIVE_REQUIREMENTS.json`, `SOURCE_CONFLICTS.md`, `FULL_SPEC.md`.
3. Active `.dsh/project/task_packets/<task>.json`, preserve/baseline/rework records.
4. `.dsh/project/WORKING_STATE.json` and evidence/review artifacts for the active task.
5. Repository/worktree reality and configured deterministic qualification commands.

Repository/runtime facts beat stale model statements. Source authority comes from the requirement ledger/source policy. Never resume mutation from a stale packet or while another operation lease owns TESTING/REVIEWING/ACCEPTING.
