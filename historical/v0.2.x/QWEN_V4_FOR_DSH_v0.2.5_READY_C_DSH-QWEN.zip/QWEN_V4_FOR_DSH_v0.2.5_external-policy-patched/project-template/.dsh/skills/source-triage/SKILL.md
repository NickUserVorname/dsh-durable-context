---
name: source-triage
description: Classify mixed source bundles into formal specs, dirty requirement drafts, transcripts, audits/current-state reports and evidence; resolve precedence and block material conflicts before mutation.
---
# Purpose

Do not assume every attached/uploaded Markdown/text artifact is a specification. Establish source authority before implementation.

# Artifact classes

- `CANONICAL_SPEC` — clean/formal requirement source explicitly presented/adopted as target.
- `NORMATIVE_CORRECTION` — explicit correction/override/delta with normative authority.
- `SUPPLEMENTARY_CLEAN_SPEC` — clean additional specification with defined relationship to canonical source.
- `DIRTY_REQUIREMENT_DRAFT` — requirement-shaped but explicitly rough/unclean; conditional unless promoted by the user.
- `DIRTY_IDEA` — brainstorming/rough notes; conditional by default.
- `CONVERSATION_TRANSCRIPT` — mixed user/model dialogue; never normative as a whole.
- `AUDIT_REVIEW` — findings about gaps/quality/current state; evidence/repair overlay by default.
- `IMPLEMENTATION_LOG` — commands/progress/agent claims/benchmark status; evidence only.
- `CURRENT_STATE_REPORT` — user-supplied “what exists now” report/transcript/snapshot; evidence only until repository/runtime verification.
- `REPO_EVIDENCE` — current files/tests/runtime facts; evidence only.
- `UNKNOWN` — authority cannot be safely inferred.

# Statement authority inside transcripts

For each relevant statement distinguish origin:

- direct **user requirement/correction/prohibition** -> `CANDIDATE_NORMATIVE_DELTA`;
- assistant/model proposal, summary, architecture suggestion or “I will do X” -> `NON_NORMATIVE` unless the user explicitly adopts that exact semantic content;
- tool output/test result -> `EVIDENCE_ONLY`;
- assistant claim about current implementation -> `UNVERIFIED_EVIDENCE` until repository/runtime proof confirms it;
- speaker/origin that cannot be established -> `UNKNOWN_STATEMENT_AUTHORITY`.

Never let a model's own suggestion become a task merely because it appears beside user text.

# Precedence

1. explicit current user instruction about how sources relate;
2. explicit precedence declared inside adopted source documents;
3. explicit normative corrections/overrides;
4. canonical clean specification;
5. conditional/supplementary sources according to intake mode;
6. audits/logs/current-state/repository evidence for factual verification.

Do not use date, filename, size or apparent detail level to override explicit precedence.

# Intake modes

## FORMAL_SPEC_STACK
Preserve each raw base/correction/recovery source and its declared precedence. Compile an indexed active requirement view without erasing provenance.

## CLEAN_PLUS_DIRTY_INTERSECTION
Use when the user provides a clean spec plus dirty draft/discussion and instructs you to implement only matching/compatible requirements and report conflicts before action.

- clean is authoritative;
- dirty content is conditional;
- compatible dirty detail may enrich the matching clean requirement;
- unmatched dirty requirements/ideas are not implemented automatically;
- contradictory dirty content creates `BLOCKING_SOURCE_CONFLICT` before mutation;
- assistant/model text remains non-normative unless explicitly adopted.

## AUDIT_DRIVEN_REPAIR
Audit findings are repair/acceptance targets after verification against repository reality. Audit author's architectural suggestions do not silently override normative specs.

## DIRTY_TRANSCRIPT_RECOVERY
Extract relevant direct-user deltas, separate assistant/tool/status material, then verify every “already done” claim against repository/runtime before treating it as current state.

## MIXED_EXPLICIT
Use when the user explicitly defines another relationship among sources. Record that instruction verbatim and obey it.

# Conflict/unknown gate

A conflict is blocking when candidate/approved statements cannot both hold, or one violates an explicit negative/compatibility requirement.

Record:

```text
CONFLICT_ID
SOURCE_A / EXACT LOCATION / STATEMENT
SOURCE_B / EXACT LOCATION / STATEMENT
WHY THEY CANNOT BOTH HOLD
MATERIAL_SCOPE
STATUS = BLOCKING
```

Unknown authority is blocking only if material to approved semantics, precedence, compatibility, active scope or a requested conflict decision. Nonmaterial unknowns may be recorded/deferred.

# Large-source discipline

Do not rewrite a 7k-line formal spec into another 7k-line paraphrase. Preserve raw sources. `FULL_SPEC.md` is a compact compiled index/view with exact source IDs, sections/requirement IDs, precedence, negative requirements and phase mapping. Active phase/task packets carry the exact needed normative text and provenance.

# Revision invalidation

When approved authority/precedence/compatibility/normative content changes:

1. increment source revision;
2. mark task packets built on an older revision stale;
3. rebuild affected traceability/conflicts;
4. only then resume implementation.

# Required outputs

- `.dsh/project/SOURCE_INTAKE.md`;
- `.dsh/project/SOURCE_INDEX.json`;
- `.dsh/project/SOURCE_CONFLICTS.md`;
- compact normalized `.dsh/project/FULL_SPEC.md` / active requirement view;
- preserved raw source material when possible.
