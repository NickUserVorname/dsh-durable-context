---
name: task-packet
description: Build one atomic implementation contract from active requirements, repository reality and explicit qualification policy.
---
# Task packet

Create one atomic packet at the exact current `source_revision`.

Required fields:

```yaml
id: TASK-ID
source_revision: N
objective: ...
requirement_refs: [REQ-...]
preserve: []
replace: []
remove: []
add: []
forbidden: []
write_set: []
acceptance: []
qualification:
  mode: REQUIRED | NOT_APPLICABLE
  rationale: ...
budget: {}
```

Rules:
- Use only active requirement IDs with exact provenance.
- Preserve donor behavior unless an active normative requirement explicitly supersedes it.
- `write_set` is the smallest publishable Git scope that can satisfy the objective. Ignored files are not publishable task outputs in the Git patch pipeline.
- Shadow/sidecar/stub work never satisfies production integration unless the active requirement explicitly calls for that stage.
- `qualification.mode=REQUIRED` for code/runtime/behavioral work needing deterministic focused/regression commands. `NOT_APPLICABLE` requires an explicit rationale and is reviewable evidence, not a shortcut.
- Budgets may only reduce host ceilings; the task cannot grant itself more autonomy.
- Do not paste dirty transcripts wholesale into the packet. Carry normalized requirement text/provenance and the minimum relevant context.
