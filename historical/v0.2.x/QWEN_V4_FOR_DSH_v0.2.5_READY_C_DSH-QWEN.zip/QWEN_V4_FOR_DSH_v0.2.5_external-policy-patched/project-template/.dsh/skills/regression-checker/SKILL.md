---
name: regression-checker
description: Check retained behavior and compatibility across CLI, APIs, config, stored data, outputs, integrations and legacy capabilities explicitly kept by the spec.
---
# Workflow

Build a retained-capability list from the spec and repository evidence. For each changed owner check direct behavior plus callers, persisted formats, CLI/API surfaces and rollback/compatibility expectations.

Do not treat "new tests pass" as proof that retained legacy capability still exists. If a capability is intentionally removed, require explicit project authority rather than accidental loss.
