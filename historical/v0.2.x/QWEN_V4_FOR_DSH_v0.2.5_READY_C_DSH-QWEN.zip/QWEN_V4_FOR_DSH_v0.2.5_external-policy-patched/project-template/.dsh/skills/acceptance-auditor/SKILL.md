---
name: acceptance-auditor
description: Audit mandatory requirements through canonical production execution, tests and real evidence; mandatory NOT_PROVEN fails the phase.
---
# Evidence ladder

For every mandatory requirement verify:

```text
normative requirement
-> canonical implementation
-> production path invokes it
-> failure/fallback semantics
-> focused test
-> relevant regression/integration test
-> real measured evidence when required
```

Return PASS only if every required rung is present.

Explicitly reject surface evidence:
- class created;
- flag/field added;
- task type registered;
- branch exists but production bypasses it;
- default zero/empty value pretending to be measured state;
- synthetic provenance;
- mocks presented as hardware/production qualification;
- broad suite green while mandatory backend/path is rejected or untested.

Mandatory NOT_PROVEN = FAIL. Preserve negative requirements in the report.
