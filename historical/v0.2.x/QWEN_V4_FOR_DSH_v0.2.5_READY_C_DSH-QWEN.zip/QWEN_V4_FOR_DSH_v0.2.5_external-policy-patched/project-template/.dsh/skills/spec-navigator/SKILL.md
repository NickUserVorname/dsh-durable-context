---
name: spec-navigator
description: Retrieve exact approved requirements through source provenance and build requirement-to-production-to-test-to-evidence traceability without memory or surface compliance.
---
# Preconditions

Source intake must identify approved authority. If a required source relationship is unresolved, invoke/return to `source-triage` rather than inventing precedence.

# Workflow

For the active task:

1. Locate the exact approved normative requirement and source provenance.
2. Apply explicit precedence from `SOURCE_INDEX.json`/source documents; never infer precedence from date alone.
3. If the source is a transcript, use only approved direct-user deltas; assistant/model text is non-normative unless explicitly adopted.
4. Extract negative requirements, compatibility requirements and forbidden shortcuts.
5. Locate the actual current production owner and runtime call path.
6. Locate tests, fixtures and measured evidence that claim to prove the requirement.
7. Classify current state: `IMPLEMENTED`, `PARTIAL`, `MISSING`, `DIFFERENT`, `NOT_PROVEN`.
8. Record the smallest evidence chain that supports the classification.

# Traceability row

```text
REQ_ID
NORMATIVE_TEXT
SOURCE_ID / EXACT LOCATION
SOURCE_CLASS / AUTHORITY
PRECEDENCE
COMPATIBILITY_POLICY
CANONICAL_OWNER
PRODUCTION_CALL_PATH
TESTS
REAL_EVIDENCE
STATUS
GAP
FORBIDDEN_SURROGATES
```

A field, class, registration, mock, comment, default or passing unrelated test is never sufficient evidence of production semantics.
