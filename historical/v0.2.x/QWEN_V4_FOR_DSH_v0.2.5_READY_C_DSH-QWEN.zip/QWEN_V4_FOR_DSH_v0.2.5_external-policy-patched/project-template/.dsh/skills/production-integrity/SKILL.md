---
name: production-integrity
description: Use before replacing, deleting, shrinking or "temporarily" bypassing existing functionality; require canonical production-path integration and reject stubs, sidecars and green-test proxies as completion.
---
# Production integrity

1. Before changing an existing subsystem, enumerate the retained capabilities and user-visible surfaces that the current task/spec says must survive.
2. Do not replace a large/complete capability with a smaller substitute merely because the substitute is easier to implement.
3. If the requirement says a new router/engine/path replaces an old section of the production pipeline, prove the canonical runtime actually calls the new path. A shadow/sidecar implementation is not completion unless the normative source explicitly requires shadow-only operation at that stage.
4. Do not use placeholders, fake backends, no-op branches, synthetic "success" values or TODO-shaped stubs as completed implementation unless the exact task explicitly authorizes them.
5. Passing tests do not prove the right thing is implemented. Map every mandatory user outcome to the production call path and direct evidence.
6. Any intentional capability removal/reduction requires explicit normative authority and a retained-capability regression decision.
7. Report partial implementation as PARTIAL/NOT_PROVEN, not "done" followed by a list of core work that still needs implementation.

# Completion proof

For each changed mandatory capability record:

```text
REQUIREMENT -> RETAINED/NEW CAPABILITY -> CANONICAL OWNER -> PRODUCTION CALL PATH -> FOCUSED TEST -> REGRESSION -> REAL EVIDENCE
```

If the path ends at a detached module, shadow-only path, mock, flag, registration, placeholder or uncalled branch, completion fails.
