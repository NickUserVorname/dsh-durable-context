# Inference and role policy

One physical local model is used sequentially through llama.cpp/llama-server with `--parallel 1`.

## Main worker
- persistent main DSH session across bounded `/work` continuation;
- default reasoning effort: MEDIUM;
- LOW only for explicitly selected small, well-normalized work;
- XHIGH only by explicit host/user escalation;
- llama.cpp reasoning sampler budget: 6144 per reasoning block, not a request-wide guarantee;
- DSH total completion cap: 16384 per model request;
- request-wide starvation recovery may force one action-only request with reasoning disabled;
- raw reasoning preservation is off by default; durable memory is externalized into Project Pack working state/evidence.

## Host-owned fresh roles
SOURCE_CURATOR, TASK_PLANNER, TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR are host-owned stages using fresh bounded sessions on the same physical model. They receive selected state/evidence rather than the worker's raw transcript.

See repository-level `ADDENDUM_MODEL_GPU_REASONING_TUNING.md`.
