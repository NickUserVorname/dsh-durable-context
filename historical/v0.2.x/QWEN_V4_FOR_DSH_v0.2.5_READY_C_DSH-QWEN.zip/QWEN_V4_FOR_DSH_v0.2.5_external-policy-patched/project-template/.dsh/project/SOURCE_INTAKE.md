# Source intake

```yaml
status: UNRESOLVED   # UNRESOLVED | READY | BLOCKED
revision: 0          # increment whenever approved source authority/requirements change
mode: UNSET          # FORMAL_SPEC_STACK | CLEAN_PLUS_DIRTY_INTERSECTION | AUDIT_DRIVEN_REPAIR | DIRTY_TRANSCRIPT_RECOVERY | MIXED_EXPLICIT
primary_source_ids: []
supplementary_source_ids: []
compatibility_policy: NONE   # NONE | STRICT_PRESERVE | EXPLICIT_MIGRATION
unmatched_dirty_policy: DO_NOT_IMPLEMENT
assistant_transcript_policy: NON_NORMATIVE_UNLESS_USER_ADOPTED
conflict_policy: STOP_BEFORE_MUTATION
material_unknown_policy: BLOCK
nonmaterial_unknown_policy: RECORD_AND_DEFER
user_relationship_instruction: ""
```

## Notes

Populate this from the user's actual instruction before implementation. Do not infer `READY` merely because files exist.

If the user changes a requirement, source role, precedence or compatibility instruction, increment `revision`, re-run conflict checks and invalidate every READY task packet created against an older revision.

An UNKNOWN/ambiguous statement blocks intake only when it could materially affect approved requirements, precedence, compatibility, active scope or a requested conflict check. Clearly non-normative/nonmaterial ambiguity may be recorded and deferred instead of freezing the entire project.
