# Source conflicts

No conflicts have been classified yet.

For each conflict record:

```text
CONFLICT_ID:
STATUS: BLOCKING | RESOLVED | DEFERRED_NONMATERIAL
MATERIAL_SCOPE:
SOURCE_A / LOCATION / STATEMENT:
SOURCE_B / LOCATION / STATEMENT:
WHY_INCOMPATIBLE:
USER_DECISION:
SOURCE_REVISION_AFTER_RESOLUTION:
```

A material BLOCKING conflict forbids production/test/benchmark mutation until resolved. Nonmaterial unknowns/conflicts may be recorded as deferred only when they cannot affect approved semantics, precedence, compatibility or active scope.
