# Current phase

```yaml
source_revision: 0
phase: UNSET
status: not_started
active_mutators_max: 1
active_task_id: null
next_phase_automatic: false
```

Resolve source authority/conflicts and create an atomic packet before production mutation. The next phase never starts automatically after acceptance.
