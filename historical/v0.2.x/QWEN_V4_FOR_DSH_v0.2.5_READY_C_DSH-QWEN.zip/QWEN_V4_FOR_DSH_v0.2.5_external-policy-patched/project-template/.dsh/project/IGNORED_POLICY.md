# Ignored-file protection policy

Ignored files are **not publishable task outputs** in the Git patch pipeline. A task that needs a non-Git artifact requires a separate explicit artifact-delivery mechanism.

Integrity monitoring distinguishes:

- **strict protected ignored paths**: `.env` families, key/certificate files and config-like files; content is SHA-256 hashed even when ignored;
- **bulk ignored paths**: caches, media, models, virtual environments and other potentially huge ignored trees; metadata is monitored to avoid hashing tens of gigabytes after every shell call.

Bulk ignored monitoring is a performance/security trade-off and is not presented as cryptographic content integrity. Native-Windows outside-workspace shell containment remains `DEGRADED_WINDOWS / NOT_PROVEN`.
