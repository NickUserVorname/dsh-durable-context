# Concurrency policy — QWEN-V4 v0.2

- Default `max_active_mutators = 1` per project Git root.
- Unknown write-set/resource overlap serializes work.
- Reviewer/acceptance are read-only fresh contexts and do not count as mutators.
- Long/full benchmark resources have one explicit owner; a failed long run must have new root-cause evidence before rerun.
- Parallel mutation is not enabled by the qwen-v4 preset.
