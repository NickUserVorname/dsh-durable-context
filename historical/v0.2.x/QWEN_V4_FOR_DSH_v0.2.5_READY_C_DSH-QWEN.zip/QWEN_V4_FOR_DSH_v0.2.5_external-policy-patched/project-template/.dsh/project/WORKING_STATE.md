# Distilled working state — v0.2.5

Raw hidden reasoning is **not** durable project memory. The model-facing `task_checkpoint` externalizes only explicit state:

```yaml
mode: merge | replace
covered_evidence_ids: []
known: []
decisions: []
evidence: []
do_not_repeat: []
next_action: []
```

Host-authoritative fields are added independently:

```yaml
failed_hypotheses: []
open_acceptance: []
```

`open_acceptance` comes from the active task packet and cannot be erased by a model checkpoint. `failed_hypotheses` comes from task execution state.

Every completed non-checkpoint tool result receives a host evidence id (`EV-xxxxx`). If any such evidence is pending, the next checkpoint must cover every pending id and must contain substantive externalized state; an all-empty checkpoint is rejected and does **not** clear the continuation barrier.

`merge` deduplicates additive `known/decisions/evidence/do_not_repeat`. `next_action` is preserved when omitted and replaced only when explicitly supplied. `replace` intentionally rewrites the model-owned checkpoint fields, while host-owned fields remain host-owned.

Before an automatic goal round, the host injects a **field-aware** bounded projection rather than truncating raw JSON. Critical fields (`failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`, pending evidence ids) cannot disappear merely because `known` grew large; bulk `known/decisions/evidence` are bounded by recent items with omitted counts and a pointer to the full `.dsh/project/WORKING_STATE.json`.

If meaningful evidence exists without a fresh checkpoint, host `agent/turn-stopping` steers a checkpoint-only step in the same turn before goal-round-driver may continue. All other tools are denied while the barrier is active. If the model does not satisfy the checkpoint, autonomous work is paused rather than spending the next goal round.
