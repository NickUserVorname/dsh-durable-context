param(
  [string]$QualificationProject = "C:\DSH-QWEN\qualification-v025",
  [switch]$MergeExistingQualificationProject
)

$ErrorActionPreference = "Stop"

$Root        = "C:\DSH-QWEN"
$DshHome     = "$Root\dsh-home"
$DshRuntime  = "$Root\runtime\dsh"
$NodeRuntime = "$Root\runtime\node"
$DshCmd      = "$DshRuntime\node_modules\.bin\dsh.cmd"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$UpstreamInstaller = Join-Path $PackageRoot "INSTALL_V0_2_5_WINDOWS.ps1"
$SettingsSnippet    = Join-Path $PackageRoot "dsh-settings\llama-local.settings.example.yaml"
$LocalLauncher      = Join-Path $PSScriptRoot "01-start-qwen38-128k.ps1"

foreach ($p in @($DshHome,$DshRuntime,$NodeRuntime,$DshCmd,$UpstreamInstaller,$SettingsSnippet,$LocalLauncher)) {
  if (!(Test-Path -LiteralPath $p)) { throw "Required path not found: $p" }
}

# Make the portable DSH runtime authoritative for this installation process.
$env:DSH_HOME = $DshHome
$env:LLAMA_LOCAL_API_KEY = "local"
$env:Path = "$NodeRuntime;$DshRuntime\node_modules\.bin;$env:Path"

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Backup = "$Root\backups\v025-install-$stamp"
New-Item -ItemType Directory -Force -Path $Backup | Out-Null

if (Test-Path "$DshHome\settings.yaml") {
  Copy-Item "$DshHome\settings.yaml" "$Backup\settings.yaml.before" -Force
}
if (Test-Path "$DshHome\profiles\web") {
  Copy-Item "$DshHome\profiles\web" "$Backup\web-profile.before" -Recurse -Force
}
Write-Host "Backup created: $Backup"

# Create a disposable Git qualification project. Do not touch an important repo yet.
if (!(Test-Path -LiteralPath $QualificationProject)) {
  New-Item -ItemType Directory -Force -Path $QualificationProject | Out-Null
}
if (!(Test-Path -LiteralPath (Join-Path $QualificationProject ".git"))) {
  & git -C $QualificationProject init
  if ($LASTEXITCODE -ne 0) { throw "git init failed" }
  & git -C $QualificationProject config user.email "dsh-qualification@localhost"
  & git -C $QualificationProject config user.name "DSH Qualification"
  "# DSH v0.2.5 qualification project" | Set-Content (Join-Path $QualificationProject "README.md") -Encoding UTF8
  & git -C $QualificationProject add README.md
  & git -C $QualificationProject commit -m "qualification baseline"
  if ($LASTEXITCODE -ne 0) { throw "qualification baseline commit failed" }
}

$ExistingPolicy = if ($MergeExistingQualificationProject) { "MergeMissing" } else { "Stop" }

Write-Host "===== INSTALL HOST BUNDLE + PRESET + PROJECT PACK ====="
& $UpstreamInstaller `
  -ProjectRoot $QualificationProject `
  -DshCommand $DshCmd `
  -DshHome $DshHome `
  -ExistingProjectPolicy $ExistingPolicy
if ($LASTEXITCODE -ne 0) { throw "Upstream installer failed: $LASTEXITCODE" }

# Safe settings merge for the known portable setup. Refuse ambiguous existing llm-pi-ai config.
$SettingsPath = Join-Path $DshHome "settings.yaml"
if (!(Test-Path -LiteralPath $SettingsPath)) {
  New-Item -ItemType File -Path $SettingsPath -Force | Out-Null
}
$Current = Get-Content -LiteralPath $SettingsPath -Raw
if ($Current -match '(?m)^llm-pi-ai\s*:') {
  if ($Current -notmatch '(?m)^\s{4}llama-local\s*:') {
    throw "settings.yaml already has llm-pi-ai but no llama-local. Refusing an unsafe text merge. Backup: $Backup"
  }
  Write-Host "llama-local already present in settings.yaml; leaving it unchanged."
}
else {
  $Snippet = Get-Content -LiteralPath $SettingsSnippet -Raw
  if ($Current.Length -gt 0 -and -not $Current.EndsWith("`n")) { Add-Content -LiteralPath $SettingsPath -Value "" }
  Add-Content -LiteralPath $SettingsPath -Value ""
  Add-Content -LiteralPath $SettingsPath -Value $Snippet
  Write-Host "llama-local provider appended to: $SettingsPath"
}

# Materialize stable launchers in C:\DSH-QWEN without modifying the original release package.
Copy-Item -LiteralPath $LocalLauncher -Destination "$Root\start-qwen38-128k.ps1" -Force

@'
@echo off
setlocal
set "LLAMA_LOCAL_API_KEY=local"
call "C:\DSH-QWEN\start-dsh.cmd" %*
endlocal
'@ | Set-Content "$Root\start-dsh-qwen.cmd" -Encoding ASCII

Write-Host "===== DUMP CONFIG ====="
$Dump = "$Root\dump-config-v025.txt"
& $DshCmd --profile web --dump-config 2>&1 | Tee-Object -FilePath $Dump
if ($LASTEXITCODE -ne 0) { throw "dsh --dump-config failed: $LASTEXITCODE" }

$DumpRaw = Get-Content $Dump -Raw
if ($DumpRaw -notmatch 'local-v4-control|local-dsh-v4-control') {
  throw "Installed bundle not visible in dump-config. See $Dump and backup $Backup"
}

Write-Host ""
Write-Host "INSTALLATION LAYER PASS"
Write-Host "Qualification project: $QualificationProject"
Write-Host "DSH home:             $DshHome"
Write-Host "Backup:               $Backup"
Write-Host "Dump:                 $Dump"
Write-Host "Qwen launcher:         $Root\start-qwen38-128k.ps1"
Write-Host "DSH launcher:          $Root\start-dsh-qwen.cmd"
Write-Host ""
Write-Host "NEXT:"
Write-Host "1) Start C:\DSH-QWEN\start-qwen38-128k.ps1 in one PowerShell."
Write-Host "2) Run _LOCAL_C_DSH-QWEN\03-verify-live.ps1 in another PowerShell."
Write-Host "3) Then start C:\DSH-QWEN\start-dsh-qwen.cmd C:\DSH-QWEN\qualification-v025"
Write-Host "4) Create a NEW web session with preset qwen-v4 and provider llama-local / qwen3.8-27b."
Write-Host "5) Run /status before touching a real project."
