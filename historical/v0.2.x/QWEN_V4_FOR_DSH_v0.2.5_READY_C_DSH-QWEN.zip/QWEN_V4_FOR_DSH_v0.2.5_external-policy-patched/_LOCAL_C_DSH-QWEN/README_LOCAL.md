# Local overlay for C:\DSH-QWEN

This directory does **not** modify the validated v0.2.5 release files. It adapts deployment to the already-qualified local host.

Local facts used by this overlay:

- DSH root: `C:\DSH-QWEN`
- portable DSH home: `C:\DSH-QWEN\dsh-home`
- DSH runtime: `C:\DSH-QWEN\runtime\dsh`
- custom llama.cpp: `C:\DSH-QWEN\llama-custom_GGML_CUDA_FA_ALL_QUANTS=ON`
- model: `C:\DSH-QWEN\models\Qwen3.8-27B-UD-Q4_K_M.gguf`
- CUDA toolkit runtime: 12.9
- llama CUDA0: Tesla V100-SXM2-16GB
- llama CUDA1: NVIDIA GeForce RTX 3070 Ti
- context: 131072
- layer tensor split: 4,1
- KV: K=q8_0, V=q5_1
- FlashAttention: on
- server reasoning policy: MEDIUM, 6144 budget per reasoning block

Why reasoning stays 6144 here instead of the earlier experimental 8192: the v0.2.5 package explicitly hardened around 6144 plus a request-wide DSH completion cap of 16384 and starvation recovery. The package validator also treats 6144 as the release baseline. Change it only after live DSH qualification/A-B testing.

## Order

1. Keep any old llama-server stopped on port 8080.
2. Run `02-install-v025-qualification.ps1` from PowerShell. It backs up the portable DSH settings/profile, installs the host bundle/preset into the portable DSH, creates a disposable Git qualification project, merges `llama-local` only when safe, and writes stable launchers under `C:\DSH-QWEN`.
3. Start `C:\DSH-QWEN\start-qwen38-128k.ps1` in a dedicated PowerShell.
4. Run `03-verify-live.ps1` from another PowerShell.
5. Start `C:\DSH-QWEN\start-dsh-qwen.cmd C:\DSH-QWEN\qualification-v025`.
6. In DSH Web create a **new** session with workspace `C:\DSH-QWEN\qualification-v025`, preset `qwen-v4`, provider `llama-local`, model `qwen3.8-27b`.
7. Run `/status`. Then do a bounded qualification task before installing the Project Pack into an important repository.

The original release remains available alongside this overlay and its `PACKAGE_MANIFEST.json`/`dist` package is unchanged.
