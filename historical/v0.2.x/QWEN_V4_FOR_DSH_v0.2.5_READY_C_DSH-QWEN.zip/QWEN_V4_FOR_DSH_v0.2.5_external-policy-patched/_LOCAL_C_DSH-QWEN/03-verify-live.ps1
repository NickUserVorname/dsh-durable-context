$ErrorActionPreference = "Stop"

$Root     = "C:\DSH-QWEN"
$DshHome  = "$Root\dsh-home"
$DshCmd   = "$Root\runtime\dsh\node_modules\.bin\dsh.cmd"
$Node     = "$Root\runtime\node"
$DshBin   = "$Root\runtime\dsh\node_modules\.bin"
$QProject = "$Root\qualification-v025"

$env:DSH_HOME = $DshHome
$env:LLAMA_LOCAL_API_KEY = "local"
$env:Path = "$Node;$DshBin;$env:Path"

Write-Host "===== FILE LAYER ====="
$FileRows = foreach ($p in @(
  "$Root\start-qwen38-128k.ps1",
  "$Root\start-dsh-qwen.cmd",
  "$DshHome\settings.yaml",
  "$DshHome\.agent-presets\qwen-v4\agent.cordis.yml",
  "$QProject\.dsh\project\RUNTIME_POLICY.json"
)) {
  [PSCustomObject]@{ Exists = Test-Path -LiteralPath $p; Path = $p }
}
$FileRows | Format-Table -AutoSize

Write-Host "===== PROFILE PACKAGE ====="
if (Test-Path "$DshHome\profiles\web\package.json") {
  Get-Content "$DshHome\profiles\web\package.json" -Raw
}

Write-Host "===== SETTINGS HITS ====="
Select-String "$DshHome\settings.yaml" -Pattern 'llm-pi-ai|llama-local|qwen3.8-27b|131072|maxRetries' -Context 1,2

Write-Host "===== DSH DUMP HITS ====="
$Dump = "$Root\dump-config-v025-verify.txt"
& $DshCmd --profile web --dump-config 2>&1 | Tee-Object -FilePath $Dump | Out-Null
if ($LASTEXITCODE -ne 0) { throw "dsh dump-config failed" }
Select-String $Dump -Pattern 'local-v4-control|local-dsh-v4-control|maxGoalRounds|roleProvider|qwen3.8-27b' -Context 1,3

Write-Host "===== LLAMA HEALTH ====="
try {
  Invoke-RestMethod "http://127.0.0.1:8080/health" -TimeoutSec 5 | Format-List *
}
catch {
  Write-Host "llama-server is not responding on 8080. Start C:\DSH-QWEN\start-qwen38-128k.ps1 first."
  exit 2
}

Write-Host "===== LLAMA MODELS ====="
$Models = Invoke-RestMethod "http://127.0.0.1:8080/v1/models" -TimeoutSec 5
$Models.data | Select-Object id,object | Format-Table -AutoSize
if (-not ($Models.data.id -contains 'qwen3.8-27b')) { throw "qwen3.8-27b alias not exposed by llama-server" }

Write-Host "===== SHORT INFERENCE ====="
$Body = @{
  model = "qwen3.8-27b"
  messages = @(@{ role = "user"; content = "Reply with exactly: DSH_V025_LLAMA_OK" })
  temperature = 0
  max_tokens = 256
  stream = $false
} | ConvertTo-Json -Depth 10
$R = Invoke-RestMethod -Uri "http://127.0.0.1:8080/v1/chat/completions" -Method POST -ContentType "application/json" -Body $Body -TimeoutSec 300
$R.choices[0].message | Format-List *
$R.usage | Format-List *
if ($R.choices[0].message.content -ne 'DSH_V025_LLAMA_OK') { throw "Short inference content check failed" }

Write-Host "===== GPU ====="
nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader

Write-Host "LIVE LLAMA + DSH FILE/CONFIG LAYER PASS"
