Merge the `llm-pi-ai:` section into `%USERPROFILE%\.dsh\settings.yaml`; do not overwrite unrelated settings. Set `LLAMA_LOCAL_API_KEY=local`.
