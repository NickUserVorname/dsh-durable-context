# v0.2.5 implementation status

## Implemented locally

All previously agreed v0.2.1-v0.2.4 protections remain: source revision/task ownership, direct write-set guard, disposable Git worktree, ignored-file visibility, process-shared project lock, forced evidence-covered checkpoints, field-aware working-state projection, requirement superseding/provenance, deterministic FULL_SPEC, token accounting, donor baseline inventory, bounded host goal, RU+EN state-aware intent grammar, mandatory TEST_ANALYST, and reasoning-output-starvation recovery.

v0.2.5 closes the post-v0.2.4 audit:

- global atomic-task usage now includes TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR child sessions;
- fresh roles have independent request/reasoning/output/tool/time/read-result ceilings;
- worker execution preserves a validation reserve rather than consuming all task budget before mandatory validation;
- deterministic qualification is fail-closed: REQUIRED with no configured focused/regression command becomes BLOCKED_QUALIFICATION; only explicit NOT_APPLICABLE+rationale bypasses it;
- long TEST/REVIEW/ACCEPT transactions use TESTING/REVIEWING/ACCEPTING plus operation nonce/owner/revision;
- fresh-role read/grep/glob is limited to approved roots, realpath checked against symlink/junction escape, and cumulatively byte-bounded;
- TEST/REVIEW/ACCEPT evidence is typed and host-validated for referential integrity; this does not claim semantic proof;
- ignored task outputs are refused by the Git publication pipeline instead of being accepted and silently lost;
- strict protected ignored state receives content hashes, while bulk ignored state uses bounded metadata monitoring rather than multi-GB rehashing after every shell command;
- `current_phase` is changed only by explicit human `/phase set <id>`; `/accept` never advances phase;
- same-host definitely-dead process locks can be reclaimed immediately;
- installer honors `DSH_HOME`, falling back to `$HOME/.dsh`;
- active project skills/templates no longer contain obsolete model-tier/orchestration instructions;
- the main entrypoint was split into dedicated host-runtime, execution-usage, fresh-role, role-schema and role-result modules; a validator prevents re-monolithization past the current threshold.

## Honest boundaries

- Native Windows arbitrary shell writes outside the selected workspace remain `DEGRADED_WINDOWS / NOT_PROVEN`.
- Bulk ignored-state monitoring is deliberately not a cryptographic integrity guarantee; strict-protected ignored patterns are content-hashed.
- Typed evidence proves that references are real and structurally valid, not that they semantically prove a finding.
- A full live runtime qualification against the exact installed DSH + llama-server on the target Windows host remains mandatory before trusting an important repository.

## Local qualification target

Release packaging must pass JavaScript syntax, all local regression/adversarial mock tests, package validator, build-path leakage scan, manifest verification, and a complete rerun from a random extracted directory.
