# External runtime policy

`project-template/.dsh/project/RUNTIME_POLICY.json` is the per-project materialized policy for task budgets, validation reserve and fresh-role ceilings.

Precedence at installation:

1. shipped `RUNTIME_POLICY.json` / existing project policy;
2. optional `-PolicyFile <json>` overlay;
3. optional `-Set "dotted.path=value"` overrides.

Runtime loads the project policy for new task planning, worker validation-reserve checks, and fresh-role budgets. Compiled defaults are hard ceilings; an external policy can lower but not raise them.

Examples:

```powershell
.\INSTALL_V0_2_5_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home `
  -Set "task_budget_defaults.max_reasoning_tokens=60000","validation_reserve.max_reasoning_tokens=15000"
```

```cmd
INSTALL_V0_2_5_WINDOWS.cmd --project-root C:\repo --dsh-home C:\DSH-QWEN\dsh-home --set roles.TEST_ANALYST.max_tokens_per_request=4096
```

If the global task budget cannot leave positive worker headroom after the mandatory validation reserve, install-time validation and runtime `/task` fail with `TASK_BUDGET_TOO_SMALL_FOR_MANDATORY_VALIDATION`.
