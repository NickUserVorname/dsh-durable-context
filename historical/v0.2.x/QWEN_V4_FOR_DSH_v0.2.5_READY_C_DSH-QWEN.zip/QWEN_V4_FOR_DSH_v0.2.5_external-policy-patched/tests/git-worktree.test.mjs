import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { createTaskWorktree, unauthorizedPaths, stageAndPatch, applyPatchToDonor, removeTaskWorktree } from '../dsh-bundle-v4-control/lib/git.js'

function git(cwd,...args){ const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'}); if(r.status!==0) throw new Error(r.stderr||r.stdout); return r.stdout }
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-git-'))
git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T')
fs.mkdirSync(path.join(root,'src')); fs.writeFileSync(path.join(root,'src','a.txt'),'a\n'); fs.writeFileSync(path.join(root,'README.md'),'r\n')
git(root,'add','-A'); git(root,'commit','-m','base')
const wt=path.join(root,'.dsh','runtime','worktrees','T1')
const created=createTaskWorktree(root,wt,'T1')
fs.writeFileSync(path.join(wt,'src','a.txt'),'b\n')
assert.deepEqual(unauthorizedPaths(wt,created.baseline_commit,['src/a.txt']),[])
fs.writeFileSync(path.join(wt,'README.md'),'bad\n')
assert.deepEqual(unauthorizedPaths(wt,created.baseline_commit,['src/a.txt']),['README.md'])
fs.writeFileSync(path.join(wt,'README.md'),'r\n')
const patch=stageAndPatch(wt,created.baseline_commit)
assert.match(patch,/src\/a\.txt/)
applyPatchToDonor(root,patch)
assert.equal(fs.readFileSync(path.join(root,'src','a.txt'),'utf8'),'b\n')
removeTaskWorktree(root,wt)
console.log('git-worktree.test.mjs: PASS')
