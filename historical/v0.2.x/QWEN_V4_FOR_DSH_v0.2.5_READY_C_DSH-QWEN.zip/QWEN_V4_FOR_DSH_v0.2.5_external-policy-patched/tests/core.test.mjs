import assert from 'node:assert/strict'
import { clampBudget, DEFAULT_BUDGET, foldUsage, pathAllowed, safeWorktreeTarget } from '../dsh-bundle-v4-control/lib/core.js'
import { _test } from '../dsh-bundle-v4-control/index.js'

assert.equal(clampBudget({max_model_requests: 999}).max_model_requests, 30)
assert.equal(clampBudget({max_model_requests: 4}).max_model_requests, 4)
assert.equal(pathAllowed('src/a.py',['src/**']), true)
assert.equal(pathAllowed('other/a.py',['src/**']), false)

const events = [
 {seq:1,time:1000,type:'step/start',data:{turn:1,step:1}},
 {seq:2,time:1100,type:'assistant/message',data:{usage:{outputTokens:100,reasoningTokens:60}}},
 {seq:3,time:1200,type:'tool/call',data:{}},
 {seq:4,time:1500,type:'step/end',data:{turn:1,step:1}},
]
const u=foldUsage(events,1,1,1500)
assert.deepEqual(u,{model_requests:1,reasoning_tokens:60,visible_output_tokens:40,tool_calls:1,active_execution_ms:500,failed_hypotheses:1})

const shellFail=_test.semanticToolFailure({name:'pwsh'},{isError:false,value:{kind:'foreground',exitCode:1,timedOut:false,aborted:false}})
assert.equal(shellFail.failed,true)
assert.match(shellFail.text,/SHELL_EXIT_1/)
console.log('core.test.mjs: PASS')
