import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { applyRequirementDelta, renderFullSpec, validateRequirementRefs } from '../dsh-bundle-v4-control/lib/ledger.js'
import { emptyWorkingState, mergeWorkingState, checkpointDue } from '../dsh-bundle-v4-control/lib/working-state.js'
import { accountAssistantEvent, accountEpochSteps, tokenLedgerUsage } from '../dsh-bundle-v4-control/lib/token-accounting.js'
import { collectBaselineInventory, compareBaselineInventory } from '../dsh-bundle-v4-control/lib/baseline.js'

// 1) Requirement lifecycle/provenance + deterministic FULL_SPEC.
const src1=[{source_id:'SRC1-01',path_or_label:'v0.15.md',authority:'CANONICAL',precedence:'base'}]
let ledger=applyRequirementDelta({schema_version:3,requirements:[]},{normative_change:true,requirements:[{
 text:'Production route MUST use A',source_label:'v0.15.md',source_ref:'§4 lines 10-20',authority:'CANONICAL',supersedes:[]
}]},{revision:1,sources:src1})
const first=ledger.requirements[0].id
assert.equal(ledger.requirements[0].status,'active')
assert.equal(validateRequirementRefs(ledger,[first])[0].source_ref,'§4 lines 10-20')
const src2=[{source_id:'SRC2-01',path_or_label:'addendum.md',authority:'CORRECTION',precedence:'override'}]
ledger=applyRequirementDelta(ledger,{normative_change:true,requirements:[{
 text:'Production route MUST use B',source_label:'addendum.md',source_ref:'Correction #2',authority:'CORRECTION',supersedes:[first]
}]},{revision:2,sources:src2})
assert.equal(ledger.requirements[0].status,'superseded')
assert.equal(ledger.requirements[0].superseded_by,ledger.requirements[1].id)
assert.throws(()=>validateRequirementRefs(ledger,[first]),/superseded/)
const full1=renderFullSpec(ledger,{sourceRevision:2}), full2=renderFullSpec(ledger,{sourceRevision:2})
assert.equal(full1,full2)
assert.match(full1,/exact provenance: Correction #2/)
assert.throws(()=>applyRequirementDelta({schema_version:3,requirements:[{...ledger.requirements[1],status:'active',active:true,superseded_by:null,superseded_revision:null}]},{normative_change:true,requirements:[
 {text:'C1',source_label:'addendum.md',source_ref:'C1',authority:'CORRECTION',supersedes:[ledger.requirements[1].id]},
 {text:'C2',source_label:'addendum.md',source_ref:'C2',authority:'CORRECTION',supersedes:[ledger.requirements[1].id]}
]},{revision:3,sources:src2}),/more than one new requirement/)

// 2) Explicit checkpoint merge/replace semantics.
let ws=emptyWorkingState('T1')
ws=mergeWorkingState(ws,{mode:'merge',known:['A'],decisions:['D1'],evidence:['E1'],do_not_repeat:['X'],next_action:['N1']},{taskId:'T1',hostOpenAcceptance:['A1']})
ws=mergeWorkingState(ws,{mode:'merge',known:['A','B'],decisions:[],evidence:['E2'],do_not_repeat:[],next_action:['N2']},{taskId:'T1',hostOpenAcceptance:['A2']})
assert.deepEqual(ws.known,['A','B'])
assert.deepEqual(ws.evidence,['E1','E2'])
assert.deepEqual(ws.open_acceptance,['A2'])
assert.deepEqual(ws.next_action,['N2'])
ws=mergeWorkingState(ws,{mode:'replace',known:['Z'],decisions:[],evidence:[],do_not_repeat:[],next_action:[]},{taskId:'T1',hostOpenAcceptance:[]})
assert.deepEqual(ws.known,['Z'])
assert.equal(checkpointDue({execution:{meaningful_since_checkpoint:1,steps_since_checkpoint:1}},{isAutomaticGoalRound:true,maxStepsWithoutCheckpoint:3}),true)
assert.equal(checkpointDue({execution:{meaningful_since_checkpoint:1,steps_since_checkpoint:3}},{isAutomaticGoalRound:false,maxStepsWithoutCheckpoint:3}),true)
assert.equal(checkpointDue({execution:{meaningful_since_checkpoint:0,steps_since_checkpoint:1}},{isAutomaticGoalRound:true,maxStepsWithoutCheckpoint:3}),false)
assert.equal(checkpointDue({execution:{meaningful_since_checkpoint:0,steps_since_checkpoint:3}},{isAutomaticGoalRound:false,maxStepsWithoutCheckpoint:3}),false)

// 3) Separate block token accounting via llama /tokenize seam.
const oldFetch=globalThis.fetch
globalThis.fetch=async (_url,opts)=>{
 const body=JSON.parse(opts.body)
 const n=body.content.includes('think') ? 5 : body.content.includes('answer') ? 2 : 1
 return {ok:true,async json(){return {tokens:Array.from({length:n},(_,i)=>i)}}}
}
const accounted=await accountAssistantEvent({data:{message:{content:[{type:'reasoning',text:'think deeply'},{type:'text',text:'answer'}]},usage:{outputTokens:9}}},{tokenizerEndpoint:'http://local/tokenize'})
assert.equal(accounted.reasoning_tokens,5)
assert.equal(accounted.visible_output_tokens,2)
assert.equal(accounted.mode,'llama-tokenize-message-blocks')
const failedEvents=[
 {seq:10,type:'step/start',data:{turn:2,step:1}},
 {seq:11,type:'assistant/chunk',data:{turn:2,step:1,chunk:{type:'block-start',index:0,blockType:'reasoning'}}},
 {seq:12,type:'assistant/chunk',data:{turn:2,step:1,chunk:{type:'reasoning-delta',index:0,text:'think failed'}}},
 {seq:13,type:'assistant/chunk',data:{turn:2,step:1,chunk:{type:'block-end',index:0,block:{type:'reasoning',text:'think failed'}}}},
 {seq:14,type:'assistant/chunk',data:{turn:2,step:1,chunk:{type:'usage',usage:{outputTokens:7}}}},
 {seq:15,type:'step/end',data:{turn:2,step:1}},
]
const failedAccount=await accountEpochSteps(failedEvents,{sessionId:'S',startSeq:10,tokenizerEndpoint:'http://local/tokenize',existingEntries:{}})
assert.equal(Object.keys(failedAccount.additions).length,1)
const failedEntry=Object.values(failedAccount.additions)[0]
assert.equal(failedEntry.source,'assistant/chunk')
assert.equal(failedEntry.mode,'llama-tokenize-failed-stream-blocks')
const failedUsage=tokenLedgerUsage({execution:{token_accounting:{entries:failedAccount.additions}}},'S',10,failedEvents)
assert.equal(failedUsage.complete,true)
assert.equal(failedUsage.reasoning_tokens,5)
globalThis.fetch=oldFetch

// 4) Deterministic donor surface inventory + delta.
function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-base-'))
git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T')
fs.mkdirSync(path.join(root,'tests'));fs.writeFileSync(path.join(root,'main.py'),'def public_api():\n    return 1\n');fs.writeFileSync(path.join(root,'big_cli.py'),"import argparse\np=argparse.ArgumentParser()\np.add_argument('--quality')\n");fs.writeFileSync(path.join(root,'tests','test_main.py'),'pass\n');git(root,'add','-A');git(root,'commit','-m','base')
const before=collectBaselineInventory(root,path.join(root,'.dsh','project','TOOLCHAIN.json'))
assert.ok(before.entrypoint_candidates.includes('main.py'))
assert.ok(before.cli_candidates.includes('big_cli.py'))
assert.ok(before.aggregate_surfaces.public_symbols.includes('public_api'))
assert.ok(before.aggregate_surfaces.cli_options.includes('--quality'))
fs.rmSync(path.join(root,'big_cli.py'))
const after=collectBaselineInventory(root,path.join(root,'.dsh','project','TOOLCHAIN.json'))
const delta=compareBaselineInventory(before,after)
assert.ok(delta.removed_surface_files.includes('big_cli.py'))
assert.ok(delta.aggregate_delta.cli_options.removed.includes('--quality'))

console.log('hardening-v022.test.mjs: PASS')
