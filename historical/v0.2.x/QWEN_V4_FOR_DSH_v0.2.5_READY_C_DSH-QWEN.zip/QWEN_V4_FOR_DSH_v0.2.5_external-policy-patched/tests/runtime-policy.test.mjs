import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { ensureProject } from '../dsh-bundle-v4-control/lib/state.js'
import { DEFAULT_RUNTIME_POLICY, loadRuntimePolicy, normalizeRuntimePolicy, roleBudgetFor, validationReserveFor, validateBudgetEnvelope } from '../dsh-bundle-v4-control/lib/runtime-policy.js'

// External policy can lower frozen ceilings without recompiling the plugin.
{
  const p=normalizeRuntimePolicy({
    task_budget_defaults:{max_reasoning_tokens:60000},
    validation_reserve:{max_reasoning_tokens:15000},
    roles:{TEST_ANALYST:{max_tokens_per_request:4096,max_input_chars:24000}}
  })
  assert.equal(p.task_budget_defaults.max_reasoning_tokens,60000)
  assert.equal(p.validation_reserve.max_reasoning_tokens,15000)
  assert.equal(p.roles.TEST_ANALYST.max_tokens_per_request,4096)
  assert.equal(p.roles.TEST_ANALYST.max_input_chars,24000)
}

// Policy cannot silently raise the compiled safety ceiling.
{
  const p=normalizeRuntimePolicy({
    task_budget_defaults:{max_reasoning_tokens:999999},
    validation_reserve:{max_reasoning_tokens:999999},
    roles:{TEST_ANALYST:{max_tokens_per_request:999999}}
  })
  assert.equal(p.task_budget_defaults.max_reasoning_tokens,DEFAULT_RUNTIME_POLICY.task_budget_defaults.max_reasoning_tokens)
  assert.equal(p.validation_reserve.max_reasoning_tokens,DEFAULT_RUNTIME_POLICY.validation_reserve.max_reasoning_tokens)
  assert.equal(p.roles.TEST_ANALYST.max_tokens_per_request,DEFAULT_RUNTIME_POLICY.roles.TEST_ANALYST.max_tokens_per_request)
}

// Per-project RUNTIME_POLICY.json is live-loaded and role/reserve lookups use it.
{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-policy-'))
  fs.mkdirSync(path.join(root,'.git'))
  const paths=ensureProject(root)
  fs.writeFileSync(paths.runtimePolicy,JSON.stringify({
    task_budget_defaults:{max_model_requests:20,max_reasoning_tokens:50000,max_visible_output_tokens:30000,max_tool_calls:80,max_active_execution_minutes:60,max_failed_hypotheses:2},
    validation_reserve:{max_model_requests:6,max_reasoning_tokens:12000,max_visible_output_tokens:9000,max_tool_calls:16,max_active_execution_minutes:20},
    roles:{TEST_ANALYST:{max_tokens_per_request:4096,max_input_chars:20000,max_read_result_bytes:16000}}
  },null,2))
  const runtime={root,paths}
  const p=loadRuntimePolicy(runtime)
  assert.equal(p.task_budget_defaults.max_model_requests,20)
  assert.equal(validationReserveFor(runtime).max_reasoning_tokens,12000)
  assert.equal(roleBudgetFor(runtime,'TEST_ANALYST').max_tokens_per_request,4096)
  assert.equal(roleBudgetFor(runtime,'TEST_ANALYST').max_input_chars,20000)
}

// Tiny task budgets fail immediately instead of leaving zero worker headroom.
{
  assert.throws(()=>validateBudgetEnvelope(
    {max_model_requests:8,max_reasoning_tokens:20000,max_visible_output_tokens:13000,max_tool_calls:20,max_active_execution_minutes:25},
    {max_model_requests:8,max_reasoning_tokens:20000,max_visible_output_tokens:13000,max_tool_calls:20,max_active_execution_minutes:25}
  ),/TASK_BUDGET_TOO_SMALL_FOR_MANDATORY_VALIDATION/)
  assert.equal(validateBudgetEnvelope(
    {max_model_requests:9,max_reasoning_tokens:20001,max_visible_output_tokens:13001,max_tool_calls:21,max_active_execution_minutes:26},
    {max_model_requests:8,max_reasoning_tokens:20000,max_visible_output_tokens:13000,max_tool_calls:20,max_active_execution_minutes:25}
  ),true)
}


// Typos/unknown policy fields fail closed instead of being silently ignored.
{
  assert.throws(()=>normalizeRuntimePolicy({roles:{TEST_ANALYST:{max_tokenz_per_request:1234}}}),/RUNTIME_POLICY_UNKNOWN_FIELD/)
  assert.throws(()=>normalizeRuntimePolicy({roles:{MYSTERY_ROLE:{max_tokens_per_request:1234}}}),/RUNTIME_POLICY_UNKNOWN_FIELD/)
}

console.log('runtime-policy.test.mjs: PASS')
