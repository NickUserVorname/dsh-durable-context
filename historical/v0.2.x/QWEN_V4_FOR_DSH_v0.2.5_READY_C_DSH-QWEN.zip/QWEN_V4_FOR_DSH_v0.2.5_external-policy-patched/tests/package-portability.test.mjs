import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const banned=[/\/mnt\/data\//i,/v02\d+build/i,/\/home\/oai\//i,/[A-Za-z]:\\Users\\(?!<)/i]
const textExt=new Set(['.js','.mjs','.json','.md','.yml','.yaml','.ps1','.py','.csv','.txt'])
const bad=[]
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else if(textExt.has(path.extname(e.name).toLowerCase())){const t=fs.readFileSync(p,'utf8'); for(const re of banned) if(re.test(t)) bad.push(`${path.relative(root,p)} => ${re}`)}}}
walk(root)
assert.deepEqual(bad,[])
console.log('package-portability.test.mjs: PASS')
