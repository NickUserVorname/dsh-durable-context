import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { workflowIntent } from '../dsh-bundle-v4-control/lib/intent-router.js'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { ensureProject, initialState, saveState } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){ const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'}); if(r.status!==0) throw new Error(r.stderr||r.stdout); return r.stdout }
function initRepo(prefix='qv4-v024-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T'); fs.writeFileSync(path.join(root,'a.txt'),'a\n'); git(root,'add','-A'); git(root,'commit','-m','base'); return root
}

const reviewState='TEST_REQUIRED'
const reviewYes=[
  'проверь','просто проверь','а теперь проверь','ну, проверь код','проверь реализацию','проверь исполнение',
  'проверь изменения','проверь результат','проверь что получилось','сделай ревью','проведи ревью','ревьюни это',
  'давай проверим','посмотри реализацию','глянь изменения','оцени результат',
  'review','review code','review the code','check code','check implementation','check changes','check result',
  'inspect implementation','start review','run review','okay, review code please',
]
for (const text of reviewYes) assert.equal(workflowIntent(text,{taskState:reviewState})?.command,'review',`should review-route: ${text}`)

const chatNo=[
  'можешь проверить код?','можешь проверить код','не проверяй код','почему ты проверил код?','если проверишь код, что будет?',
  'что будет если проверить код','"проверь код"','review code?','could you review code','do not review code','why did you review code?',
]
for (const text of chatNo) assert.equal(workflowIntent(text,{taskState:reviewState}),null,`should stay chat: ${text}`)

// Contextual review phrases are allowed only at review-capable states.
for (const text of ['проверь','проверь код','посмотри код','review code','check implementation']) {
  assert.equal(workflowIntent(text,{taskState:'READY'}),null,`must not jump READY -> review: ${text}`)
}
assert.equal(workflowIntent('проверь код',{taskState:'REVIEW_REQUIRED'})?.command,'review')

// Work continuation is state-aware.
for (const st of ['READY','TEST_FAILED','REVIEW_FAILED','ACCEPTANCE_FAILED','BUDGET_PAUSED']) {
  assert.equal(workflowIntent('продолжай',{taskState:st})?.command,'work',`continue should work from ${st}`)
}
assert.equal(workflowIntent('продолжай',{taskState:'TEST_REQUIRED'}),null)

// Planning is intentionally conservative; explicit slash remains available in other states.
assert.equal(workflowIntent('перейди к планированию',{taskState:'NO_TASK'})?.command,'task')
assert.equal(workflowIntent('start planning',{taskState:'ACCEPTED'})?.command,'task')
assert.equal(workflowIntent('перейди к планированию',{taskState:'TEST_REQUIRED'}),null)

// Explicit payload may legitimately contain negative requirements.
assert.deepEqual(workflowIntent('создай задачу: не удалять старый CLI',{taskState:'NO_TASK'}),{command:'task',rawInput:'не удалять старый CLI',confidence:'explicit-payload'})
assert.deepEqual(workflowIntent('run triage: do not treat assistant text as normative',{taskState:'IN_PROGRESS'}),{command:'triage',rawInput:'do not treat assistant text as normative',confidence:'explicit-payload'})

// Safe status and acceptance routing.
assert.equal(workflowIntent('покажи статус',{taskState:'IN_PROGRESS'})?.command,'status')
assert.equal(workflowIntent('show status',{taskState:'NO_TASK'})?.command,'status')
assert.equal(workflowIntent('проведи приёмку',{taskState:'ACCEPTANCE_REQUIRED'})?.command,'accept')
assert.equal(workflowIntent('run acceptance',{taskState:'REVIEW_REQUIRED'}),null)

// Host integration: state-aware command-plane dispatch rejects the main model step.
{
  const root=initRepo('qv4-v024-router-'); const paths=ensureProject(root)
  const state=initialState(); state.task_state='TEST_REQUIRED'; saveState(paths,state)
  const hooks=[]; const executed=[]
  const ctx={logger:{warn(){}},agents:{get(){}},on(n,f){if(n==='agent/pre-step')hooks.push(f)},tools:{guard(){},register(){}},commands:{register(){},async execute(_a,line){executed.push(line);return {commandId:'c',result:{kind:'success',text:'ok'}}}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}}}
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const msg={id:'m',role:'user',content:[{type:'text',text:'ну, проверь код'}],source:{kind:'user'}}
  const d=await hooks[0]({agent,messages:[msg],turn:1,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[msg]}))
  assert.equal(d.kind,'reject'); assert.deepEqual(executed,['/review'])
}

console.log('hardening-v024.test.mjs: PASS')
