import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { ensureProject, initialState, saveState, saveTask, loadState, loadTask } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-cp-stop-'));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.writeFileSync(path.join(root,'a.txt'),'a\n');git(root,'add','-A');git(root,'commit','-m','base')
const paths=ensureProject(root);const state=initialState();state.source_revision=1;state.active_task_id='T1';state.task_state='IN_PROGRESS';state.worker_session_id='S';saveState(paths,state)
const task={schema_version:3,id:'T1',source_revision:1,objective:'x',write_set:['a.txt'],acceptance:['x'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{failed_hypotheses:[],worktree:root,baseline_commit:'x',usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:'S',epoch_start_seq:0,steps_since_checkpoint:1,meaningful_since_checkpoint:1,checkpoint_required:true,checkpoint_required_reason:'automatic_goal_round_2',token_accounting:{entries:{},latest_mode:'uninitialized'}}};saveTask(paths,task)
const hooks=new Map(),guards=[],tools=new Map();let blocked=null
const agent={id:'A',session:{id:'S',header:{cwd:root},events:[],seq:0},cancel(){}}
const ctx={logger:{warn(){}},agents:{get(id){return id==='S'?agent:undefined}},on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(){}},goals:{get(){return {id:'g',revision:1,phase:'active',activation:'armed',roundsStarted:2,maxGoalRounds:6}},block(_a,_r,p){blocked=p},complete(){},clear(){},create(){throw new Error('n/a')}},subagents:{async start(){throw new Error('n/a')}}}
apply(ctx,{tokenizerEndpoint:''})
const stop=(hooks.get('agent/turn-stopping')??[])[0]
await stop({agent})
assert.equal(loadState(paths).task_state,'BUDGET_PAUSED')
const saved=loadTask(paths,'T1')
assert.equal(saved.execution.budget_pause_reason,'checkpoint_barrier_unresolved')
assert.equal(blocked.code,'checkpoint-required')
console.log('checkpoint-force-pause.mock.test.mjs: PASS')
