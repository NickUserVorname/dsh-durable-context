from pathlib import Path
import hashlib, json, tarfile, yaml, re
root=Path(__file__).resolve().parents[1]
required=[
 'dist/local-dsh-v4-control-0.2.5.tgz','dsh-bundle-v4-control/package.json','dsh-bundle-v4-control/cordis.patch.yml',
 'dsh-bundle-v4-control/lib/intent-router.js','dsh-bundle-v4-control/lib/test-gate.js','dsh-bundle-v4-control/lib/role-control.js','dsh-bundle-v4-control/lib/runtime-policy.js',
 'dsh-bundle-v4-control/lib/execution-usage.js','dsh-bundle-v4-control/lib/fresh-role.js','dsh-bundle-v4-control/lib/role-results.js',
 'dsh-bundle-v4-control/lib/role-schemas.js','dsh-bundle-v4-control/lib/host-runtime.js','dsh-bundle-v4-control/lib/evidence.js','dsh-bundle-v4-control/lib/operations.js','dsh-bundle-v4-control/lib/commands.js',
 'dsh-preset-qwen-v4/agent.cordis.yml','dsh-settings/llama-local.settings.example.yaml','llama-server/start-qwen38-windows.ps1',
 'project-template/.dsh/project/state.json','project-template/.dsh/project/SOURCE_POLICY.md','project-template/.dsh/project/ACTIVE_REQUIREMENTS.json',
 'project-template/.dsh/project/INFERENCE_POLICY.md','project-template/.dsh/project/IGNORED_POLICY.md','project-template/.dsh/project/RUNTIME_POLICY.json',
 'ADDENDUM_MODEL_GPU_REASONING_TUNING.md','FINAL_SPEC_V0_2_5.md','HARDENING_V0_2_5.md','INSTALL_V0_2_5_WINDOWS.ps1','INSTALL_V0_2_5_WINDOWS.cmd','docs/EXTERNAL_RUNTIME_POLICY.md',
 'tests/hardening-v025.test.mjs','tests/runtime-policy.test.mjs','tests/package-portability.test.mjs','tests/RUNTIME_ADVERSARIAL_SUITE.md','PACKAGE_MANIFEST.json'
]
for r in required: assert (root/r).exists(), f'missing {r}'
assert not (root/'project-template/.dsh/project/MODEL_ROUTING.md').exists(), 'legacy MODEL_ROUTING.md must not be active'
for p in root.rglob('*.json'):
    if p.name == 'PACKAGE_MANIFEST.json': continue
    json.loads(p.read_text(encoding='utf-8'))
class Loader(yaml.SafeLoader): pass
Loader.add_constructor('tag:yaml.org,2002:js', lambda loader,node: loader.construct_scalar(node))
for p in list(root.rglob('*.yml'))+list(root.rglob('*.yaml')): yaml.load(p.read_text(encoding='utf-8'),Loader=Loader)
with tarfile.open(root/'dist/local-dsh-v4-control-0.2.5.tgz','r:gz') as t:
    names=set(t.getnames())
    for n in [
      'package/package.json','package/index.js','package/cordis.patch.yml','package/lib/core.js','package/lib/state.js','package/lib/git.js',
      'package/lib/ledger.js','package/lib/working-state.js','package/lib/token-accounting.js','package/lib/baseline.js','package/lib/intent-router.js',
      'package/lib/test-gate.js','package/lib/role-control.js','package/lib/runtime-policy.js','package/lib/execution-usage.js','package/lib/fresh-role.js','package/lib/role-results.js',
      'package/lib/role-schemas.js','package/lib/host-runtime.js','package/lib/evidence.js','package/lib/operations.js','package/lib/commands.js'
    ]: assert n in names, f'tgz missing {n}'
    pkg=json.loads(t.extractfile('package/package.json').read()); assert pkg['version']=='0.2.5'
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest['version']=='0.2.5'; assert manifest['file_count']==len(manifest['files'])
for item in manifest['files']:
    p=root/item['path']; assert p.exists(), f'manifest missing file {item["path"]}'
    data=p.read_bytes(); assert len(data)==item['bytes'], f'manifest size mismatch {item["path"]}'
    assert hashlib.sha256(data).hexdigest()==item['sha256'], f'manifest hash mismatch {item["path"]}'
# Current docs and installer must not refer to older active release artifacts.
for rel in ['README_FIRST.md','INSTALL_AND_RUN_WINDOWS.md','FINAL_SPEC_V0_2_5.md','HARDENING_V0_2_5.md','docs/IMPLEMENTATION_STATUS.md']:
    txt=(root/rel).read_text(encoding='utf-8')
    assert 'local-dsh-v4-control-0.2.4.tgz' not in txt, f'stale tgz ref in {rel}'
launcher=(root/'llama-server/start-qwen38-windows.ps1').read_text(encoding='utf-8')
assert '[int]$ReasoningBudget = 6144' in launcher
installer=(root/'INSTALL_V0_2_5_WINDOWS.ps1').read_text(encoding='utf-8')
assert '$env:DSH_HOME' in installer and '$ResolvedDshHome' in installer, 'installer must honor DSH_HOME'
assert 'ExistingProjectPolicy = "Stop"' in installer, 'installer must fail closed on existing .dsh by default'
assert 'MergeMissing' in installer and 'Copy-MissingTree' in installer, 'installer must use explicit non-overwrite merge mode'
assert 'PolicyFile' in installer and '[string[]]$Set' in installer, 'installer must accept external runtime policy and CLI overrides'
assert 'Copy-Item (Join-Path $ProjectTemplate "*") $ProjectDst -Recurse -Force' not in installer, 'installer must not force-overwrite project .dsh'
# Active model-visible donor fossils are release failures. Historical migration docs are excluded on purpose.
active=[]
for base in [root/'project-template/.dsh/skills', root/'project-template/.dsh/project']:
    active += [p for p in base.rglob('*') if p.is_file() and p.suffix.lower() in {'.md','.json','.yml','.yaml'}]
forbidden=[r'model_class\s*:\s*cheap',r'route to Pro',r'Mark each task `cheap`',r'scripts/agent_task\.py',r'task_graph\.json',r'claims\.json']
for p in active:
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat in forbidden: assert not re.search(pat,txt,re.I), f'active donor fossil in {p.relative_to(root)}: {pat}'
# Build-machine path leakage is a release failure.
text_suffixes={'.js','.mjs','.json','.md','.yml','.yaml','.ps1','.py','.csv','.txt'}
banned=[re.compile('/mnt' + '/data/',re.I),re.compile(r'v02\d+build',re.I),re.compile('/home' + '/oai/',re.I),re.compile(r'[A-Za-z]:\\Users\\(?!<)',re.I)]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in text_suffixes: continue
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for rx in banned: assert not rx.search(txt), f'build-machine path leakage in {p.relative_to(root)}: {rx.pattern}'
# Monolithic entrypoint regression guard: new orchestration belongs in modules.
index_lines=len((root/'dsh-bundle-v4-control/index.js').read_text(encoding='utf-8').splitlines())
assert index_lines < 900, f'index.js re-monolithized: {index_lines} lines'
print('validate_package.py: PASS')
