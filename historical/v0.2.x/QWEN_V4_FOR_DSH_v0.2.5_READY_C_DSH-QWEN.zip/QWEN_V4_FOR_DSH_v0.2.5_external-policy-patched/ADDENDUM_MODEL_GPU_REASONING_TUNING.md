# ADDENDUM — Model / GPU / Context / Reasoning / Autonomy Tuning

## Frozen baseline

- Model: `Qwen3.8-27B Q4_K_M` (the ~17.1 decimal GB / ~15.9 GiB GGUF class), one physical local brain.
- Backend: `llama.cpp / llama-server`.
- GPU placement: `--split-mode layer`, start `--tensor-split 3,1` (V100:3070 Ti).
- Context capacity: 131072 tokens. Capacity is not a target prompt size; Project Pack/task packets should keep normal prompts far smaller.
- KV: K=`q5_0`, V=`q4_1` as a memory/quality starting point.
- Parallel slots: 1.
- Reasoning: MEDIUM default; llama sampler budget 6144 **per reasoning block**; DSH hard total completion cap 16384/request; XHIGH manual-only; raw reasoning preservation OFF.
- DSH continuation: host goal + goal-round-driver, max 6 automatic rounds. Qwen never receives model-facing `tool-goal`.
- Turn: <=12 steps and <=32 tool calls.
- Task-wide: <=30 model requests, <=80K reasoning tokens, <=40K visible output, <=120 tools, <=90 active execution minutes, <=2 failed hypotheses.
- Provider retries: 0.
- Next phase: never automatic.

## Why Qwen3.8-27B Q4_K_M

The agent is the only main local brain, so the design prefers a high-quality Q4 over Q3 memory savings. Qwen3.8-27B is a dense 27B hybrid Gated-DeltaNet/full-attention model with long native context and explicit low/medium/xhigh reasoning control, suitable for repository/tool work. Q4_K_M is the production default; Q3 is an emergency memory/speed profile, not the default. UD-Q4_K_XL is a later quality A/B if the extra VRAM cost is acceptable.

## Why 3:1 layer split

The Q4 file alone nearly fills a 16 GiB V100, so V100 cannot safely hold all weights plus runtime/KV/state. V100 has the stronger HBM bandwidth and therefore gets the larger weight share; the 3070 Ti carries the remainder and its layer-local state. Layer split avoids forcing both unequal PCIe GPUs to synchronize inside every tensor operation. `3:1` is a starting proportion, not sacred.

Tune split one axis at a time:
- V100 OOM, RTX has reserve: 3:1 -> 2.5:1 -> 2:1.
- RTX OOM, V100 has reserve: 3:1 -> 3.5:1 -> 4:1.
- Both fit: compare decode/prefill and accepted-task time at a realistically occupied context, not empty-context tokens/s.

## Why 128K

Qwen supports a larger native window, but 128K is a practical high-context capacity for repo work without immediately paying the VRAM/prefill/noise cost of the full native window. If actual sessions rarely exceed ~40K, reduce to 64–96K. If 128K OOMs, first reduce context (128K -> 96K -> 64K), then adjust split/KV. Raise beyond 128K only after stable measurement.

## Why MEDIUM rather than LOW/XHIGH

MEDIUM is the default balance. LOW is for small, well-normalized packets and can use a smaller 4–6K **per-block sampler budget**; if LOW creates mistakes/retries, return to MEDIUM. XHIGH is never automatic: use only as a host/user-approved bounded escalation on a genuinely hard problem. Do not interpret any per-block sampler value as a request-wide guarantee; the same 16K request envelope and 80K task-wide ceiling remain unless the host explicitly changes policy.

## Reasoning preservation: what is actually deleted

`--no-reasoning-preserve` does NOT distill hidden reasoning and does not erase DSH session logs. It prevents the full old raw reasoning history from being replayed through the model template as preserved reasoning context. During the current inference, thinking still exists and is paid for. If a useful conclusion lived only in hidden reasoning and was never externalized, it can be lost.

Therefore the durable replacement is explicit state. The main Qwen has `task_checkpoint`, which persists:
- known facts,
- decisions,
- evidence,
- failed hypotheses,
- do-not-repeat items,
- open acceptance items,
- next discriminating action.

Raw thinking is disposable; explicit Project Pack state/evidence/repo/test output is durable. If traces show repeated re-analysis despite correct checkpoints, A/B `preserve=true` within one active task. Compare accepted-task time, prompt/reasoning tokens, repeated hypotheses and tool errors. Do not enable preservation just because it feels smarter.

## DSH autonomy boundaries

There are four independent limit layers:
1. request: llama reasoning sampler <=6144 **per reasoning block** (a new reasoning block may re-arm it), while total output is hard-capped by DSH at <=16384;
2. turn: <=12 model/tool steps, <=32 tools;
3. goal: <=6 automatic same-session rounds;
4. task: <=30 requests, <=80K reasoning, <=40K visible output, <=120 tools, <=90 active execution minutes, <=2 failed hypotheses.

Task budgets accumulate across review-fail/rework epochs; re-running `/work` does not reset them. `max_active_execution_minutes` counts active model/tool execution, not human idle time. A task packet may REDUCE defaults; Qwen/planner cannot increase them. Increase ceilings only through host/user policy.

If goal round 6 is reached repeatedly, first split the task packet. Raise 6 -> 8 only when traces show an actually atomic task making steady progress. Avoid >8–10 without a concrete reason.

## Tuning order

Change ONE axis at a time:
1. GPU split;
2. context/KV;
3. reasoning effort/budget;
4. preserve/no-preserve;
5. MTP/speculation later;
6. model quant last.

Do not change quant + context + split + reasoning + preservation simultaneously and then attribute the result to one cause.

## v0.2.5 — exact reasoning-memory behavior in code

There is deliberately **no JavaScript that reads hidden chain-of-thought and tries to decide which thoughts are smart enough to keep**. The implementation separates three things:

1. `llama-server --reasoning-format deepseek --no-reasoning-preserve` keeps reasoning as a distinct response field/content block and avoids replaying the full old raw reasoning history back into later prompts.
2. DSH still has durable `reasoning` blocks in its append-only session history. `no-reasoning-preserve` is a model-context policy, not secure erasure of session logs.
3. QWEN-V4 durable memory is `.dsh/project/WORKING_STATE.json`. The model externalizes `known`, `decisions`, `evidence`, `do_not_repeat`, and `next_action` through `task_checkpoint`; the host injects authoritative `failed_hypotheses` and `open_acceptance`.

v0.2.2+ hardens the third layer so it is no longer only a prompt suggestion:

- `task_checkpoint` requires an explicit `mode: merge | replace`;
- normal `merge` deduplicates additive `known/decisions/evidence/do_not_repeat`; `next_action` changes only when explicitly supplied; `open_acceptance` is not model-owned and is regenerated from the active task packet;
- the host injects a bounded snapshot of current `WORKING_STATE.json` into **every automatic goal round**;
- every non-checkpoint tool result receives a host evidence id (`EV-xxxxx`); a dirty checkpoint must cover all pending ids and cannot be all-empty;
- automatic rehydration is field-aware rather than raw `slice(0,N)`: `failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`, and pending evidence ids are preserved, while large `known/decisions/evidence` arrays are bounded with omitted counts and a pointer to the full file;
- if any meaningful non-checkpoint tool/evidence occurred since the last checkpoint, `agent/turn-stopping` raises `checkpoint_required=true` and steers a checkpoint-only step in the **same turn**, before the agent becomes idle and before goal-round-driver can schedule the next automatic round;
- while that barrier is active, `ctx.tools.guard()` denies **every tool except `task_checkpoint`**;
- a long round also triggers the barrier after `checkpointEverySteps` model steps (default 3) when meaningful evidence is still uncheckpointed;
- successful checkpoint resets the cadence counters and clears the barrier;
- if Qwen reaches the checkpoint-gated stop boundary again without a successful checkpoint, host pauses autonomous work as `BUDGET_PAUSED` (`checkpoint_barrier_unresolved`) instead of letting the next automatic goal round consume tokens without externalizing state. Automatic-round pre-step checking remains a fail-closed recovery fence.

Therefore continuation no longer depends on Qwen merely remembering the instruction to checkpoint. The host cannot guarantee that Qwen's distilled statement is philosophically perfect, but it now guarantees both **coverage of every pending host evidence id** and **non-empty substantive externalization** before a dirty continuation barrier clears. Raw hidden reasoning itself is not parsed or semantically mined by our JS.

### Reasoning-vs-visible token accounting

v0.2.2+ also stops relying only on a provider aggregate when possible. DSH stores assistant output as typed `reasoning`, `text`, and `tool-call` blocks. Before the next request, the host backfills **per-step** accounting and sends the reasoning text and visible text/tool-call projection separately to the local llama.cpp `/tokenize` endpoint. Successful steps use the committed `assistant/message`; failed requests that have no assistant message are reconstructed from durable `assistant/chunk` reasoning/text/tool-call/usage events so their generated tokens are not silently lost. The resulting counts are stored in task execution accounting and used for the 80K reasoning / 40K visible task budgets.

Accounting modes are visible in `/status`:

- `provider-separated` — provider supplied separate reasoning usage;
- `llama-tokenize-blocks` — reasoning and visible content were separately tokenized by the local model tokenizer;
- `conservative-fallback` — tokenizer/provider separation was unavailable, so total output is charged to both budgets rather than undercounting.

`llama-tokenize-*` is tokenizer-exact for the retained reasoning/visible **content strings under the local tokenizer**; it is not a claim that OpenAI-compatible provider transport exposes a native `reasoning_tokens` generation counter. The fallback remains fail-safe.


## v0.2.5 — why 6144 is per block, not per request

The earlier wording `8192 reasoning tokens/request` was incorrect for current llama.cpp sampler semantics. The reasoning sampler budgets a **reasoning block**. If the model emits another reasoning start tag later in the same response, that block may receive a fresh budget window.

Therefore the production baseline is now described accurately:

```text
llama reasoning sampler      6144 / reasoning block
DSH total completion         16384 / request
starvation action reserve    target >=1024 visible/action tokens
action-only rescue           reasoning OFF, <=4096 total
cumulative task reasoning    <=80000
```

Why 6144: two full reasoning blocks would consume roughly 12288 tokens, leaving roughly 4096 of the 16384 completion envelope for a required tool call/structured/visible action. This is a conservative starting point, not a mathematical guarantee that Qwen will emit exactly two blocks or that transport overhead is zero.

The host therefore also detects **reasoning-output starvation** from separated reasoning/visible accounting. If a completed main-worker step has no tool call, >=10K reasoning and <1024 visible/action tokens, it steers one action-only rescue step and forces exactly the next request to `reasoningEffort=off`, `maxTokens<=4096`. Repeated starvation pauses the task. This is the request-wide safety layer; `--reasoning-budget` alone is not.

Tuning guidance:

- ordinary coding/triage/review: MEDIUM + 6144/block is the new baseline;
- very small normalized implementation packet: LOW, usually 4096–6144/block;
- if MEDIUM frequently starves action output: first inspect multi-block traces; try 6144 -> 5120 or 4096 before raising total completion;
- if the model stops reasoning too early and errors/retries increase: restore 6144 or MEDIUM before raising task-wide budgets;
- XHIGH remains manual-only. Do not combine XHIGH with an unbounded output envelope;
- never “fix” repeated starvation by simply raising 16384 without trace evidence: that increases blast radius and can merely give another reasoning block more room.

## v0.2.5 — roles without a second resident model/context

The system distinguishes **architectural roles** from DSH transport. `/work` is a persistent WORKER role on the main DSH session. SOURCE_CURATOR, TASK_PLANNER, TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR are mandatory/host-owned workflow roles transported as fresh bounded `spawn` invocations.

All use the same physical Qwen and the same `llama-server --parallel 1` slot **sequentially**. There is no permanently resident 16K tester KV context and no second llama-server. A fresh TEST_ANALYST gets only selected state: task packet/acceptance, diff, deterministic test output, relevant evidence and files reachable by read-only tools. Its effective initial prompt projection is capped by the TEST_ANALYST role ceiling at 48K characters (the global `testRoleInputMaxChars` setting cannot raise that ceiling), then read/grep/glob results are limited to 32 KiB cumulatively. This is a bounded-context policy, not a promise of an exact 16K-token KV allocation. Per-role output is capped at 8192 and all TEST/REVIEW/ACCEPT usage also counts against the global atomic-task budget.

This is intentionally `shared durable state, not shared raw transcript`: the tester/reviewer does not inherit the worker's 70–120K transcript or hidden reasoning, which preserves independent checking and avoids paying for irrelevant history.

## v0.2.5 — natural-language workflow intent

Explicit slash commands remain authoritative. For convenience, a small **host-owned high-precision** router maps exact command-like phrases such as `перейди к планированию`, `начинай реализацию`, `проверь всё`, `проведи приёмку` to the existing command plane. The host executes the command and rejects the original main-model step; Qwen does not decide whether a mandatory planner/reviewer/tester role is needed.

Questions, negations, hypotheticals and unsupported phrases remain ordinary chat. This router should be expanded only with adversarial examples proving low false-positive risk; it is not meant to become a broad semantic LLM classifier.

## Tuning the new test role

Default TEST_ANALYST is mandatory after `task_done`, before reviewer. It runs sequentially on the same model.

- If it adds useful missing-edge tests/findings at acceptable cost: keep it mandatory.
- If most tasks are trivial and test analysis is redundant, do **not** let Qwen skip it. Instead add a host policy later that deterministically classifies explicitly low-risk task classes and records why the gate was bypassed. No such bypass is enabled in v0.2.5.
- If test role input is too large: reduce selected diff/evidence or `testRoleInputMaxChars`; do not fork the full worker transcript.
- If test findings are shallow: increase selected evidence first; only then consider output cap 8192 -> 12288. It remains read-only.
- Do not enable `--parallel 2` merely to overlap tester with worker on the current V100+3070Ti memory budget.
