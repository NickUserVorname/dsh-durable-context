# local-dsh-v4-control 0.2.5

Host-side QWEN-V4 control plane for DeepSeek Harness.

It owns source revision/task state, bounded goals, global atomic-task budgets, validation reserve/per-role budgets, forced evidence-covered checkpoints, task worktrees/write-set enforcement, long-operation leases, typed evidence validation, fresh-role read boundaries, deterministic qualification, mandatory TEST/REVIEW/ACCEPT stages, reasoning-output-starvation recovery, human-only phase transitions and deterministic RU+EN workflow intent routing.

The model does not receive goal lifecycle authority or generic agent-spawning authority. Fresh roles are host-owned bounded sessions on the same physical Qwen. Native Windows outside-workspace shell containment remains explicitly degraded/not proven.
