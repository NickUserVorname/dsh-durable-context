param(
  [Parameter(Mandatory=$true)][string]$ProjectRoot,
  [string]$DshCommand = "dsh",
  [string]$DshHome,
  [ValidateSet("Stop","MergeMissing")][string]$ExistingProjectPolicy = "Stop",
  [string]$PolicyFile,
  [string[]]$Set = @(),
  [switch]$SkipPluginInstall
)
$ErrorActionPreference = "Stop"

function Resolve-FullPath([string]$PathValue) {
  if (-not $PathValue) { return $null }
  return [System.IO.Path]::GetFullPath($PathValue)
}

function Merge-Object($Base, $Overlay) {
  if ($null -eq $Overlay) { return $Base }
  foreach ($prop in $Overlay.PSObject.Properties) {
    $name = $prop.Name
    $value = $prop.Value
    $existing = $Base.PSObject.Properties[$name]
    if ($existing -and $existing.Value -is [pscustomobject] -and $value -is [pscustomobject]) {
      Merge-Object $existing.Value $value | Out-Null
    } else {
      if ($existing) { $Base.$name = $value }
      else { $Base | Add-Member -NotePropertyName $name -NotePropertyValue $value }
    }
  }
  return $Base
}

function Assert-KnownOverlay($Base, $Overlay, [string]$Prefix = 'runtime_policy') {
  foreach ($prop in $Overlay.PSObject.Properties) {
    $name = $prop.Name
    $baseProp = $Base.PSObject.Properties[$name]
    if (-not $baseProp) { throw "Unknown runtime policy field: $Prefix.$name" }
    if ($prop.Value -is [pscustomobject]) {
      if (-not ($baseProp.Value -is [pscustomobject])) { throw "Runtime policy type mismatch: $Prefix.$name" }
      Assert-KnownOverlay $baseProp.Value $prop.Value "$Prefix.$name"
    }
  }
}

function Convert-Scalar([string]$Raw) {
  $trimmed = $Raw.Trim()
  if ($trimmed -match '^-?\d+$') { return [int64]$trimmed }
  if ($trimmed -match '^-?\d+\.\d+$') { return [double]$trimmed }
  if ($trimmed -ieq 'true') { return $true }
  if ($trimmed -ieq 'false') { return $false }
  if ($trimmed -ieq 'null') { return $null }
  if (($trimmed.StartsWith('"') -and $trimmed.EndsWith('"')) -or ($trimmed.StartsWith("'") -and $trimmed.EndsWith("'"))) {
    return $trimmed.Substring(1, $trimmed.Length - 2)
  }
  return $Raw
}

function Set-ObjectPath($RootObject, [string]$PathSpec, $Value) {
  $parts = $PathSpec.Split('.')
  if ($parts.Count -lt 1) { throw "Invalid -Set path: $PathSpec" }
  $cursor = $RootObject
  for ($i = 0; $i -lt $parts.Count - 1; $i++) {
    $name = $parts[$i]
    $prop = $cursor.PSObject.Properties[$name]
    if (-not $prop) { throw "Unknown runtime policy path: $PathSpec" }
    if (-not ($prop.Value -is [pscustomobject])) { throw "Cannot descend into non-object policy path: $PathSpec" }
    $cursor = $prop.Value
  }
  $leaf = $parts[-1]
  if (-not $cursor.PSObject.Properties[$leaf]) { throw "Unknown runtime policy path: $PathSpec" }
  $cursor.$leaf = $Value
}

function Assert-PositivePolicyObject($Object, [string]$Prefix) {
  foreach ($prop in $Object.PSObject.Properties) {
    if ($prop.Value -is [pscustomobject]) { Assert-PositivePolicyObject $prop.Value "$Prefix.$($prop.Name)"; continue }
    if ($prop.Name -match '^max_' -and $prop.Value -isnot [string]) {
      $n = [double]$prop.Value
      if ($n -le 0) { throw "Policy value must be positive: $Prefix.$($prop.Name)=$($prop.Value)" }
    }
  }
}

function Assert-ValidationEnvelope($Policy) {
  $task = $Policy.task_budget_defaults
  $reserve = $Policy.validation_reserve
  foreach ($name in @('max_model_requests','max_reasoning_tokens','max_visible_output_tokens','max_tool_calls','max_active_execution_minutes')) {
    $total = [double]$task.$name
    $held = [double]$reserve.$name
    if ($total -lt ($held + 1)) {
      throw "TASK_BUDGET_TOO_SMALL_FOR_MANDATORY_VALIDATION: $name=$total must be > validation_reserve=$held"
    }
  }
}

function Copy-MissingTree([string]$Source, [string]$Destination) {
  Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    $dst = Join-Path $Destination $_.Name
    if ($_.PSIsContainer) {
      if (-not (Test-Path -LiteralPath $dst)) { New-Item -ItemType Directory -Path $dst | Out-Null }
      Copy-MissingTree $_.FullName $dst
    } elseif (-not (Test-Path -LiteralPath $dst)) {
      Copy-Item -LiteralPath $_.FullName -Destination $dst
    }
  }
}

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-FullPath $ProjectRoot
$Plugin = Join-Path $Here "dist\local-dsh-v4-control-0.2.5.tgz"
$PresetSrc = Join-Path $Here "dsh-preset-qwen-v4"
$ResolvedDshHome = if ($DshHome -and $DshHome.Trim()) { Resolve-FullPath $DshHome } elseif ($env:DSH_HOME -and $env:DSH_HOME.Trim()) { Resolve-FullPath $env:DSH_HOME } else { Resolve-FullPath (Join-Path $HOME ".dsh") }
$PresetDst = Join-Path $ResolvedDshHome ".agent-presets\qwen-v4"
$ProjectTemplate = Join-Path $Here "project-template\.dsh"
$ProjectDst = Join-Path $ProjectRoot ".dsh"
$PolicyTemplate = Join-Path $ProjectTemplate "project\RUNTIME_POLICY.json"
$PolicyDst = Join-Path $ProjectDst "project\RUNTIME_POLICY.json"

if (!(Test-Path (Join-Path $ProjectRoot ".git"))) { throw "ProjectRoot must be a Git repository root: $ProjectRoot" }
if (!(Test-Path $Plugin)) { throw "Missing plugin package: $Plugin" }
if (!(Test-Path $PolicyTemplate)) { throw "Missing runtime policy template: $PolicyTemplate" }

$ProjectExists = Test-Path -LiteralPath $ProjectDst
if ($ProjectExists -and $ExistingProjectPolicy -eq 'Stop') {
  throw "Existing .dsh detected at $ProjectDst. Refusing to overwrite. Re-run with -ExistingProjectPolicy MergeMissing after reviewing migration, or install into a fresh project."
}

if (!$SkipPluginInstall) {
  Write-Host "Installing host bundle into DSH web profile..."
  & $DshCommand plugin --profile web add $Plugin
  if ($LASTEXITCODE -ne 0) { throw "DSH plugin install failed ($LASTEXITCODE)" }
}

New-Item -ItemType Directory -Force -Path $PresetDst | Out-Null
Copy-Item (Join-Path $PresetSrc "*") $PresetDst -Recurse -Force
Write-Host "Preset installed: $PresetDst"

if (-not $ProjectExists) {
  Copy-Item -LiteralPath $ProjectTemplate -Destination $ProjectDst -Recurse
  Write-Host "Project Pack installed: $ProjectDst"
} else {
  Copy-MissingTree $ProjectTemplate $ProjectDst
  Write-Host "Project Pack merge-missing completed without overwriting existing files: $ProjectDst"
}

$AgentsSrc = Join-Path $Here "project-template\AGENTS.md"
$AgentsDst = Join-Path $ProjectRoot "AGENTS.md"
if ((Test-Path -LiteralPath $AgentsSrc) -and -not (Test-Path -LiteralPath $AgentsDst)) {
  Copy-Item -LiteralPath $AgentsSrc -Destination $AgentsDst
  Write-Host "AGENTS.md installed: $AgentsDst"
} elseif (Test-Path -LiteralPath $AgentsDst) {
  Write-Host "AGENTS.md already exists; left unchanged: $AgentsDst"
}

# Runtime policy is externalized. Start from the installed/default policy, overlay a file, then apply explicit CLI -Set overrides.
$Policy = if (Test-Path -LiteralPath $PolicyDst) {
  Get-Content -LiteralPath $PolicyDst -Raw | ConvertFrom-Json
} else {
  Get-Content -LiteralPath $PolicyTemplate -Raw | ConvertFrom-Json
}

if ($PolicyFile) {
  $PolicyFile = Resolve-FullPath $PolicyFile
  if (!(Test-Path -LiteralPath $PolicyFile)) { throw "PolicyFile not found: $PolicyFile" }
  $Overlay = Get-Content -LiteralPath $PolicyFile -Raw | ConvertFrom-Json
  Assert-KnownOverlay $Policy $Overlay
  Merge-Object $Policy $Overlay | Out-Null
}

$Assignments = @()
foreach ($chunk in $Set) {
  if ($null -eq $chunk) { continue }
  $Assignments += @($chunk -split ';' | Where-Object { $_.Trim() })
}
foreach ($assignment in $Assignments) {
  $eq = $assignment.IndexOf('=')
  if ($eq -lt 1) { throw "Invalid -Set '$assignment'. Expected dotted.path=value" }
  $key = $assignment.Substring(0, $eq).Trim()
  $raw = $assignment.Substring($eq + 1)
  Set-ObjectPath $Policy $key (Convert-Scalar $raw)
}

Assert-PositivePolicyObject $Policy 'runtime_policy'
Assert-ValidationEnvelope $Policy
$Policy.schema_version = 'qwen-v4-runtime-policy-0.2.5'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $PolicyDst) | Out-Null
$Policy | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $PolicyDst -Encoding UTF8
Write-Host "Runtime policy written: $PolicyDst"

Write-Host ""
Write-Host "NEXT:"
Write-Host "1) Merge dsh-settings\llama-local.settings.example.yaml into $ResolvedDshHome\settings.yaml"
Write-Host "2) `$env:LLAMA_LOCAL_API_KEY='local'"
Write-Host "3) Start llama-server with llama-server\start-qwen38-windows.ps1"
Write-Host "4) Restart DSH web, create a NEW session at $ProjectRoot with preset qwen-v4 and provider llama-local / model qwen3.8-27b"
Write-Host "5) Run /status"
