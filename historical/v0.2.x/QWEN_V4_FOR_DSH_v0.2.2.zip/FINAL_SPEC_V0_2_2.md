# QWEN-V4-FOR-DSH — Frozen v0.2 architecture + v0.2.2 hardening

## 1. Target runtime

- Runtime: DeepSeek Harness (DSH), current developer-preview architecture.
- Main model: Qwen3.8-27B Q4_K_M served by llama-server.
- One physical Qwen model; role separation is by fresh invocations/contexts, not permanently resident multi-agent conversations.
- Old OpenCode runtime, OpenCode model routing and permanent eight-agent topology are removed.

## 2. Model policy

Default production profile:

- reasoning effort: `MEDIUM`;
- reasoning budget: 8192 tokens/request;
- max completion: 16384 tokens/request;
- raw thinking preservation: OFF;
- XHIGH: manual host/user override only, not exposed as an automatic escalation;
- provider retries: zero for the local llama route.

Project memory is explicit durable state/evidence, not raw hidden reasoning.

## 3. Host-owned task continuation

DSH host owns:

- goal service;
- goal-round-driver;
- project state;
- slash commands;
- task budgets and guards.

`/work` creates one goal for the active atomic packet with `maxGoalRounds = 6` and arms it.
The same session may continue automatically while the task remains `IN_PROGRESS`. Before a dirty turn with uncheckpointed meaningful tool/evidence is allowed to become idle, host `agent/turn-stopping` steers a checkpoint-only step in that same turn; only after `task_checkpoint` succeeds may the turn close and goal-round-driver schedule the next round. If the model refuses the checkpoint, autonomous work pauses instead of spending another round.
Qwen is **not** given model-facing `tool-goal` and cannot grant itself more rounds.

DSH goal state is an execution-continuation mechanism only. It is never authoritative Project Pack task state.

## 4. Disabled autonomous machinery

The Qwen preset does not expose:

- Ralph;
- generic workflow loops;
- generic fork/spawn tools;
- swarm/team machinery;
- autonomous next-phase transition;
- model-facing goal lifecycle control.

Host commands may use the host subagent registry directly for bounded read-only one-shot work.

## 5. Anti-runaway per turn

- max steps per turn: 12;
- max tool calls per turn: 32;
- exact failed `tool + canonical args` replay after one failure: DENY;
- repeated attempt to hammer an already denied replay: CANCEL current turn.

This is a hard guard, not an advisory reminder.

## 6. Task-wide circuit breaker

Host defaults:

```yaml
task_budget:
  max_model_requests: 30
  max_reasoning_tokens: 80000
  max_visible_output_tokens: 40000
  max_tool_calls: 120
  max_active_execution_minutes: 90
  max_failed_hypotheses: 2
```

`max_active_execution_minutes` counts active model/tool execution only, never human idle time.
An atomic task packet may reduce these values. It cannot increase them above host policy.
Only host/user policy may increase the ceilings.

When provider/runtime reports `reasoningTokens` separately, it is authoritative and accumulated separately.
For the local llama/pi-ai route, where reasoning is normally folded into aggregate output usage, host accounting separates durable DSH `reasoning` blocks from visible `text/tool-call` blocks and tokenizes each projection through the local llama.cpp `/tokenize` endpoint. Accounting is per model step and includes failed requests that have `assistant/chunk` output/usage but no committed `assistant/message`. If block separation/tokenization cannot be completed, the step fails safe by charging aggregate generated output against both reasoning and visible-output ceilings.

The second evidence-backed failed hypothesis immediately pauses/escalates the task.
Other numeric maxima are inclusive; exceeding them transitions to `BUDGET_PAUSED`.

## 7. Authoritative task state machine

States:

- `NO_TASK`
- `READY`
- `IN_PROGRESS`
- `REVIEW_REQUIRED`
- `REVIEW_FAILED`
- `ACCEPTANCE_REQUIRED`
- `ACCEPTANCE_FAILED`
- `ACCEPTED`
- `BUDGET_PAUSED`
- `SCOPE_EXPANSION_REQUIRED`
- `SCOPE_VIOLATION`
- `BLOCKED_EXTERNAL`
- `BLOCKED_SPEC`
- `BLOCKED_QUALIFICATION`
- `STALE`

DSH goal lifecycle never replaces this state machine.
`ACCEPTED` and `STALE` are terminal for the packet.
No next phase begins automatically.

## 8. Source authority and `source_revision`

Preserved source classes:

- `CANONICAL_SPEC`
- `NORMATIVE_CORRECTION`
- `SUPPLEMENTARY_CLEAN_SPEC`
- `DIRTY_REQUIREMENT_DRAFT`
- `DIRTY_IDEA`
- `CONVERSATION_TRANSCRIPT`
- `AUDIT_REVIEW`
- `IMPLEMENTATION_LOG`
- `CURRENT_STATE_REPORT`
- `REPO_EVIDENCE`
- `UNKNOWN`

User text inside a conversation transcript can be normative. Previous assistant text is not normative unless the user explicitly adopts it.

Every normative/conflict-state change increments `source_revision`.
Any non-accepted active packet built at an older revision becomes `STALE`.
A stale packet may not mutate files.
A correction arriving from another session blocks/cancels the actual active worker, not merely the correction session.

`ACTIVE_REQUIREMENTS.json` is a provenance ledger. Generated prose views do not replace provenance.

## 9. Atomic packet contract

An executable packet includes at least:

- id;
- exact `source_revision`;
- objective;
- requirement/source refs;
- preserve list;
- replace/remove/add lists;
- forbidden substitutions;
- `write_set`;
- explicit acceptance criteria;
- optional budget reductions.

The planner also records machine-readable `BASELINE.json` and `PRESERVE_CONTRACT.json` before mutation.

`shadow`, `sidecar`, `stub`, proxy metrics, or green focused tests cannot satisfy a requirement for canonical production integration or a different user-visible outcome.

## 10. Mutation containment

### Direct DSH editor

Before every direct `write/edit`:

1. active packet exists and task is `IN_PROGRESS`;
2. packet revision equals current project revision;
3. task budget is not exhausted;
4. path resolves inside the disposable task worktree;
5. path matches packet `write_set`.

Failure is a hard pre-execution DENY.

### Shell

Shell calls during `/work` must set an explicit `workdir` inside the disposable task worktree.
After each shell call the host checks:

- donor root stayed clean;
- all Git-observed worktree changes are inside `write_set`.

Unauthorized changes become `SCOPE_VIOLATION`, block the goal and cancel the worker.

Absolute external executable/read paths are allowed (e.g. a project venv Python); the guard must not reproduce the earlier PowerShell failure by forbidding a valid interpreter path.

### Windows truthfulness

Native Windows DSH sandbox enforcement cannot currently prove that arbitrary shell code cannot write outside the disposable workspace. Therefore status must expose:

- `DIRECT_WRITE_GUARD = HARD`
- `SHELL_WRITE_GUARD = DEGRADED_WINDOWS`
- `SHELL_OUTSIDE_WORKSPACE = NOT_PROVEN`

Git diff is not presented as protection for arbitrary paths outside the worktree.
For absolute shell write isolation, move shell execution into a stronger WSL/Linux/container sandbox later; this is not a v0.2 launch prerequisite.

## 11. Commands

- `/status`: deterministic, zero model inference.
- `/triage`: command handler launches a bounded fresh read-only source-curator invocation, validates structured output, then host mutates project state.
- `/task`: bounded fresh read-only planner invocation, then host validates/stamps exact revision and writes packet/baseline/preserve contract.
- `/work`: deterministic host transition into `IN_PROGRESS`, creates/reuses disposable worktree and host goal <=6 rounds.
- `/review`: fresh read-only independent reviewer; no implementer hidden reasoning.
- `/accept`: fresh narrow read-only outcome auditor; publish only after PASS and final TOCTOU revision/write-set/donor checks.

`/review` failure returns to rework without destroying the task worktree.
`/accept` PASS publishes approved worktree changes and stops. It never starts the next phase.

## 12. Selected skills

- source-triage
- spec-navigator
- implementation-planner
- task-packet
- debugger
- regression-checker
- state-recovery
- production-integrity
- acceptance-auditor

Skills are procedural knowledge. Hard invariants remain host code/state.

## 13. Deferred, non-launch-blocking work

- SearXNG provider for zero-cost web search;
- stronger shell isolation on native Windows;
- benchmark/resource lock;
- semantic no-progress detector;
- MTP and exact GPU split optimization;
- preserve-thinking A/B after the safe baseline is stable.

## 14. Required qualification before real project work

The harness must pass the adversarial suite in `tests/RUNTIME_ADVERSARIAL_SUITE.md`, including stale revisions, repeated failed calls, outside-write-set edits, shell diff violations, bounded goals, budget pausing, fresh read-only review and zero-inference `/status`.

## Project identity and cross-session authority

The authoritative project identity is the validated Git toplevel derived from the DSH session's durable `session.cwd`. The host keeps a runtime map keyed by that Git root.

- sessions whose `session.cwd` resolves to the same Git root share one Project Pack, `source_revision`, active packet and active worker authority;
- sessions attached to different Git roots must never share Project Pack state;
- process cwd is never project authority;
- a cross-session normative correction must invalidate/cancel the real active worker for that same project.


---

## v0.2.2 mandatory hardening delta

The frozen architecture above is unchanged. `HARDENING_V0_2_2.md` is normative for implementation details added after the v0.2 audit. It includes all v0.2.1 hardening plus: active-worker ownership on every model-facing task-control tool; ignored-file-aware shell/donor checks; process-shared project locking; evidence-covered non-empty forced checkpoints; field-aware WORKING_STATE projection; and host-authoritative `open_acceptance`.
