# QWEN-V4 Project Instructions

Project authority lives in `.dsh/project/`. Use `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status`.
During `/work`, source-code mutation must occur only inside the disposable task worktree shown by `/status` and task packet. Never mutate `.dsh/project` from model tools. Preserve donor functionality unless a current normative requirement explicitly supersedes it. Shadow/sidecar/stub work does not satisfy a requirement for canonical production integration. `ACCEPTED` stops; next phase is never automatic.

During automatic continuation, obey the host checkpoint barrier: if required, call `task_checkpoint(mode="merge", ...)` before any other tool. Do not reconstruct discarded raw reasoning; continue from injected durable state and evidence.
