# Inference policy (legacy filename retained for compatibility)

There is one physical local brain: Qwen3.8-27B Q4_K_M through llama.cpp.

- default reasoning: MEDIUM;
- LOW: only small, well-normalized packets;
- XHIGH: host/user manual escalation only;
- reasoning budget/request: 8192 default;
- raw hidden reasoning preservation: OFF by default;
- durable memory: explicit task checkpoint/project evidence;
- reviewer and acceptance use fresh read-only spawn contexts of the same physical model;
- no Pro/Flash routing and no model-controlled goal lifecycle.

See repository-level `ADDENDUM_MODEL_GPU_REASONING_TUNING.md` in the distribution.
