# llama-server profile

1. Run `llama-server.exe --list-devices` and copy the exact V100 / RTX 3070 Ti device identifiers.
2. Start `start-qwen38-windows.ps1` with those identifiers and your Q4_K_M GGUF.
3. Default: layer split 3:1, ctx 128K, KV q5_0/q4_1, one slot, MEDIUM reasoning, 8192 reasoning tokens/request, raw reasoning history not preserved.
4. See `ADDENDUM_MODEL_GPU_REASONING_TUNING.md` before tuning.
