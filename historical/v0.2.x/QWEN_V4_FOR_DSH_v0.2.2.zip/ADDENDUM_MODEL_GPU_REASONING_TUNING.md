# ADDENDUM — Model / GPU / Context / Reasoning / Autonomy Tuning

## Frozen baseline

- Model: `Qwen3.8-27B Q4_K_M` (the ~17.1 decimal GB / ~15.9 GiB GGUF class), one physical local brain.
- Backend: `llama.cpp / llama-server`.
- GPU placement: `--split-mode layer`, start `--tensor-split 3,1` (V100:3070 Ti).
- Context capacity: 131072 tokens. Capacity is not a target prompt size; Project Pack/task packets should keep normal prompts far smaller.
- KV: K=`q5_0`, V=`q4_1` as a memory/quality starting point.
- Parallel slots: 1.
- Reasoning: MEDIUM default, 8192 reasoning tokens/request, 16384 total completion cap, XHIGH manual-only, raw reasoning preservation OFF.
- DSH continuation: host goal + goal-round-driver, max 6 automatic rounds. Qwen never receives model-facing `tool-goal`.
- Turn: <=12 steps and <=32 tool calls.
- Task-wide: <=30 model requests, <=80K reasoning tokens, <=40K visible output, <=120 tools, <=90 active execution minutes, <=2 failed hypotheses.
- Provider retries: 0.
- Next phase: never automatic.

## Why Qwen3.8-27B Q4_K_M

The agent is the only main local brain, so the design prefers a high-quality Q4 over Q3 memory savings. Qwen3.8-27B is a dense 27B hybrid Gated-DeltaNet/full-attention model with long native context and explicit low/medium/xhigh reasoning control, suitable for repository/tool work. Q4_K_M is the production default; Q3 is an emergency memory/speed profile, not the default. UD-Q4_K_XL is a later quality A/B if the extra VRAM cost is acceptable.

## Why 3:1 layer split

The Q4 file alone nearly fills a 16 GiB V100, so V100 cannot safely hold all weights plus runtime/KV/state. V100 has the stronger HBM bandwidth and therefore gets the larger weight share; the 3070 Ti carries the remainder and its layer-local state. Layer split avoids forcing both unequal PCIe GPUs to synchronize inside every tensor operation. `3:1` is a starting proportion, not sacred.

Tune split one axis at a time:
- V100 OOM, RTX has reserve: 3:1 -> 2.5:1 -> 2:1.
- RTX OOM, V100 has reserve: 3:1 -> 3.5:1 -> 4:1.
- Both fit: compare decode/prefill and accepted-task time at a realistically occupied context, not empty-context tokens/s.

## Why 128K

Qwen supports a larger native window, but 128K is a practical high-context capacity for repo work without immediately paying the VRAM/prefill/noise cost of the full native window. If actual sessions rarely exceed ~40K, reduce to 64–96K. If 128K OOMs, first reduce context (128K -> 96K -> 64K), then adjust split/KV. Raise beyond 128K only after stable measurement.

## Why MEDIUM rather than LOW/XHIGH

MEDIUM is the default balance. LOW is for small, well-normalized packets and can be 4–6K reasoning tokens; if LOW creates mistakes/retries, return to MEDIUM. XHIGH is never automatic: use only as a host/user-approved bounded escalation on a genuinely hard problem, typically 12–16K reasoning tokens, while the same task-wide 80K ceiling remains.

## Reasoning preservation: what is actually deleted

`--no-reasoning-preserve` does NOT distill hidden reasoning. It prevents old raw reasoning traces from being retained as long-lived chat history. During the current inference, thinking still exists and is paid for. If a useful conclusion lived only in hidden reasoning and was never externalized, it can be lost.

Therefore the durable replacement is explicit state. The main Qwen has `task_checkpoint`, which persists:
- known facts,
- decisions,
- evidence,
- failed hypotheses,
- do-not-repeat items,
- open acceptance items,
- next discriminating action.

Raw thinking is disposable; explicit Project Pack state/evidence/repo/test output is durable. If traces show repeated re-analysis despite correct checkpoints, A/B `preserve=true` within one active task. Compare accepted-task time, prompt/reasoning tokens, repeated hypotheses and tool errors. Do not enable preservation just because it feels smarter.

## DSH autonomy boundaries

There are four independent limits:
1. request: reasoning <=8192, total output <=16384;
2. turn: <=12 model/tool steps, <=32 tools;
3. goal: <=6 automatic same-session rounds;
4. task: <=30 requests, <=80K reasoning, <=40K visible output, <=120 tools, <=90 active execution minutes, <=2 failed hypotheses.

Task budgets accumulate across review-fail/rework epochs; re-running `/work` does not reset them. `max_active_execution_minutes` counts active model/tool execution, not human idle time. A task packet may REDUCE defaults; Qwen/planner cannot increase them. Increase ceilings only through host/user policy.

If goal round 6 is reached repeatedly, first split the task packet. Raise 6 -> 8 only when traces show an actually atomic task making steady progress. Avoid >8–10 without a concrete reason.

## Tuning order

Change ONE axis at a time:
1. GPU split;
2. context/KV;
3. reasoning effort/budget;
4. preserve/no-preserve;
5. MTP/speculation later;
6. model quant last.

Do not change quant + context + split + reasoning + preservation simultaneously and then attribute the result to one cause.

## v0.2.2 — exact reasoning-memory behavior in code

There is deliberately **no JavaScript that reads hidden chain-of-thought and tries to decide which thoughts are smart enough to keep**. The implementation separates three things:

1. `llama-server --reasoning-format deepseek --no-reasoning-preserve` keeps reasoning as a distinct response field/content block and avoids replaying the full old raw reasoning history back into later prompts.
2. DSH still has durable `reasoning` blocks in its append-only session history. `no-reasoning-preserve` is a model-context policy, not secure erasure of session logs.
3. QWEN-V4 durable memory is `.dsh/project/WORKING_STATE.json`. The model externalizes `known`, `decisions`, `evidence`, `do_not_repeat`, and `next_action` through `task_checkpoint`; the host injects authoritative `failed_hypotheses` and `open_acceptance`.

v0.2.2 hardens the third layer so it is no longer only a prompt suggestion:

- `task_checkpoint` requires an explicit `mode: merge | replace`;
- normal `merge` deduplicates additive `known/decisions/evidence/do_not_repeat`; `next_action` changes only when explicitly supplied; `open_acceptance` is not model-owned and is regenerated from the active task packet;
- the host injects a bounded snapshot of current `WORKING_STATE.json` into **every automatic goal round**;
- every non-checkpoint tool result receives a host evidence id (`EV-xxxxx`); a dirty checkpoint must cover all pending ids and cannot be all-empty;
- automatic rehydration is field-aware rather than raw `slice(0,N)`: `failed_hypotheses`, `do_not_repeat`, `open_acceptance`, `next_action`, and pending evidence ids are preserved, while large `known/decisions/evidence` arrays are bounded with omitted counts and a pointer to the full file;
- if any meaningful non-checkpoint tool/evidence occurred since the last checkpoint, `agent/turn-stopping` raises `checkpoint_required=true` and steers a checkpoint-only step in the **same turn**, before the agent becomes idle and before goal-round-driver can schedule the next automatic round;
- while that barrier is active, `ctx.tools.guard()` denies **every tool except `task_checkpoint`**;
- a long round also triggers the barrier after `checkpointEverySteps` model steps (default 3) when meaningful evidence is still uncheckpointed;
- successful checkpoint resets the cadence counters and clears the barrier;
- if Qwen reaches the checkpoint-gated stop boundary again without a successful checkpoint, host pauses autonomous work as `BUDGET_PAUSED` (`checkpoint_barrier_unresolved`) instead of letting the next automatic goal round consume tokens without externalizing state. Automatic-round pre-step checking remains a fail-closed recovery fence.

Therefore continuation no longer depends on Qwen merely remembering the instruction to checkpoint. The host cannot guarantee that Qwen's distilled statement is philosophically perfect, but it now guarantees both **coverage of every pending host evidence id** and **non-empty substantive externalization** before a dirty continuation barrier clears. Raw hidden reasoning itself is not parsed or semantically mined by our JS.

### Reasoning-vs-visible token accounting

v0.2.2 also stops relying only on a provider aggregate when possible. DSH stores assistant output as typed `reasoning`, `text`, and `tool-call` blocks. Before the next request, the host backfills **per-step** accounting and sends the reasoning text and visible text/tool-call projection separately to the local llama.cpp `/tokenize` endpoint. Successful steps use the committed `assistant/message`; failed requests that have no assistant message are reconstructed from durable `assistant/chunk` reasoning/text/tool-call/usage events so their generated tokens are not silently lost. The resulting counts are stored in task execution accounting and used for the 80K reasoning / 40K visible task budgets.

Accounting modes are visible in `/status`:

- `provider-separated` — provider supplied separate reasoning usage;
- `llama-tokenize-blocks` — reasoning and visible content were separately tokenized by the local model tokenizer;
- `conservative-fallback` — tokenizer/provider separation was unavailable, so total output is charged to both budgets rather than undercounting.

`llama-tokenize-*` is tokenizer-exact for the retained reasoning/visible **content strings under the local tokenizer**; it is not a claim that OpenAI-compatible provider transport exposes a native `reasoning_tokens` generation counter. The fallback remains fail-safe.
