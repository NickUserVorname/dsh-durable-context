qwen-v4 session preset. Copy this directory to `%USERPROFILE%\.dsh\.agent-presets\qwen-v4`.
