# QWEN-V4-FOR-DSH v0.2.2 — ownership, shell-boundary, concurrency and checkpoint hardening

v0.2.2 does **not** change the frozen v0.2 architecture. It closes the concrete gaps found after the v0.2.1 review.

## H1 — all model-facing task control tools are active-worker-owned

The same ownership predicate is now used by mutation/checkpoint and by:

- `task_failed_hypothesis`;
- `task_done`;
- `task_blocked`;
- `task_scope_expansion`.

A tool call is rejected unless the task is `IN_PROGRESS`, the packet revision is current, and both project/task worker ownership resolve to the calling DSH session. Another `qwen-v4` session on the same Git root cannot finish, block, scope-expand or mutate the failed-hypothesis state of the active worker's task.

## H2 — ignored files are part of the shell boundary

`changedPaths()` now combines:

- tracked diff from task baseline;
- nonignored untracked files;
- changes to Git-ignored files compared with the worktree's ignored-file baseline.

Therefore a generated/ignored `.env`, database or config in the disposable worktree is still checked against `write_set`.

The donor fingerprint also includes ignored donor files. For performance, tracked donor state is represented by `HEAD + current binary diff` instead of hashing every tracked file; nonignored untracked files are content-hashed; ignored files are fingerprinted by path/metadata with content hashes for small files. This closes the ordinary ignored-file mutation hole without reintroducing full tracked-repo hashing on every shell boundary.

Native Windows outside-workspace process containment remains honestly `DEGRADED_WINDOWS / NOT_PROVEN`.

## H3 — process-shared project lock

`withRuntimeLock()` now has two layers:

1. in-process Promise FIFO;
2. process-shared `.dsh/runtime/project.lock` acquired by atomic directory creation.

The lock records pid/nonce/timestamp, waits with bounded timeout, and conservatively reclaims stale locks only when the owner process is dead. This prevents two independent DSH Node processes from logically updating the same Git-root state concurrently. Atomic JSON replacement remains the file-integrity layer; the process lock provides logical transaction serialization.

State-mutating `agent/pre-step`, `agent/turn-stopping`, `session/event`, `tools/result`, slash-command and model-facing task-control paths now use the same runtime lock boundary.

## H4 — checkpoint must cover evidence and cannot be formally empty

Every completed non-checkpoint tool result gets a host evidence id such as `EV-00017`, recorded in `task.execution.pending_evidence`.

A forced checkpoint must provide `covered_evidence_ids` covering **all** pending host ids. If pending evidence exists, the checkpoint must also externalize at least one substantive item in `known`, `decisions`, `evidence`, `do_not_repeat` or `next_action`.

Thus this no longer clears the barrier:

```json
{"mode":"merge","covered_evidence_ids":["EV-00017"],"known":[],"decisions":[],"evidence":[],"do_not_repeat":[],"next_action":[]}
```

The model is not asked to expose hidden CoT. It must externalize durable conclusions/evidence derived from the work it just performed.

## H5 — field-aware WORKING_STATE projection; no raw JSON slice

The host no longer does `JSON.stringify(...).slice(0, 12000)`.

The injected snapshot is field-aware:

- `failed_hypotheses` — preserved;
- `do_not_repeat` — preserved;
- `open_acceptance` — preserved;
- `next_action` — preserved;
- pending evidence ids — preserved;
- `decisions`, `evidence`, `known` — recent bounded subsets with explicit omitted counts and a path to the full authoritative JSON.

A huge `known` list therefore cannot push all later critical fields out of the automatic-round snapshot.

## H6 — `open_acceptance` is host-authoritative

`task_checkpoint` no longer accepts `open_acceptance` as a model-owned field. The host derives it from the active packet's acceptance contract whenever WORKING_STATE is written.

The model may update `next_action`; in merge mode omission preserves the prior value, while explicitly supplying an empty array intentionally clears it.

`failed_hypotheses` remains host-authoritative as before.

## H7 — requirement/source hardening retained from v0.2.1

- active/superseded requirement lifecycle;
- exact provenance;
- `superseded_by` / `superseded_revision`;
- active `requirement_refs` validation;
- deterministic `FULL_SPEC.md` rendering.

## H8 — reasoning accounting and donor baseline hardening retained from v0.2.1

- per-step reasoning/text accounting including failed streamed requests;
- llama `/tokenize` separation when provider usage does not expose reasoning separately;
- deterministic donor surface inventory and review delta.

## Qualification status

Local unit/mock/process/Git tests cover the new invariants, including a true two-Node-process lock contention test. The full runtime adversarial suite still must be executed against the actual installed DSH build on the target Windows host before calling the control plane production-qualified.
