# v0.2.2 implementation status

## Implemented
- DSH installable out-of-tree bundle (`local-dsh-v4-control@0.2.2`).
- Host commands: `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status`.
- Host-owned DSH goal with explicit max 6 rounds; model-facing `tool-goal` is not present in the qwen-v4 preset.
- Turn limits: 12 steps, 32 tool calls; exact failed tool replay denial; repeated denied replay cancellation.
- Task-wide cumulative budgets across rework epochs: 30 model requests, 80K reasoning, 40K visible output, 120 tools, 90 active execution minutes, 2 failed hypotheses.
- MEDIUM reasoning deployment default, server reasoning budget 8192/request, max completion 16384, raw reasoning preservation OFF.
- Durable `task_checkpoint` working state instead of pretending `no-preserve` automatically extracts useful reasoning.
- Cross-session project authority keyed by Git root from durable `session.cwd`.
- Normative `/triage` change increments source revision and stales/cancels active old packet.
- Direct `write/edit` hard path guard against stale packet, donor-root writes, reserved `.dsh/.git`, and paths outside write_set.
- Shell must use foreground execution with explicit workdir inside disposable task worktree; post-shell write-set/donor/project-authority verification.
- Reviewer and acceptance run as fresh read-only spawn subagents with structured output.
- Acceptance rechecks source revision/write-set/donor TOCTOU and only then applies the accepted patch to donor root.
- Provider retry example sets DSH route retries to 0.
- Source conflicts block `/task` until re-triaged as resolved.
- Requirement ledger lifecycle hardening: active/superseded links, exact provenance, validated packet requirement refs, deterministic `FULL_SPEC.md`.
- Forced checkpoint hardening: merge/replace semantics, host-injected WORKING_STATE plus a checkpoint-only same-turn barrier before automatic continuation, and autonomous pause if the barrier is ignored.
- Reasoning/visible token accounting from separate DSH content blocks using llama.cpp `/tokenize`, with conservative fail-safe fallback.
- Deterministic donor baseline inventory/delta including entrypoint/CLI/API/config/test/package candidates, static public symbols, CLI options/subcommands and output-artifact signals.
- Active-worker ownership is enforced for `task_failed_hypothesis`, `task_done`, `task_blocked` and `task_scope_expansion`, not only for mutations/checkpoints.
- Git-ignored worktree changes participate in write-set validation; ignored donor files participate in donor-change detection.
- Project-state writes are serialized across separate Node/DSH processes by `.dsh/runtime/project.lock` in addition to the in-process FIFO lock.
- Forced checkpoints carry host `EV-xxxxx` coverage ids and cannot clear a dirty barrier with an all-empty payload.
- WORKING_STATE automatic-round projection is field-aware; critical late fields cannot be pushed out by a large `known` array.
- `open_acceptance` is host-derived from the active task packet and cannot be erased by model checkpoint payloads.
- Donor fingerprint hot path no longer hashes every tracked file; it uses HEAD+binary-diff for tracked state and selective fingerprints for untracked/ignored state.


## Honest limitation
Native Windows outside-workspace shell isolation is not proven as HARD. Status deliberately reports `SHELL_WRITE_GUARD: DEGRADED_WINDOWS` and `SHELL_OUTSIDE_WORKSPACE: NOT_PROVEN`. The disposable worktree, DSH sandbox policy and post-diff checks substantially reduce risk, but an absolute guarantee requires a stronger OS/container/WSL boundary.

## Validation done in this build environment
- `node --check` on bundle source.
- core policy/usage test PASS.
- exact failed-tool replay mock PASS (including non-zero PowerShell-style shell result semantics).
- real temporary Git worktree/write-set/patch publish test PASS, including ignored-file detection.
- two independent Node-process project-lock contention test PASS.
- cross-session model-facing task-control ownership test PASS.
- empty-checkpoint rejection and field-aware projection regression tests PASS.
- package structure/JSON/YAML/PowerShell static validation PASS.
- `npm pack` package generation PASS.

## Not claimed
This environment does not contain a live installed DSH runtime connected to the user's Windows GPUs. Therefore the bundle is locally validated and installable, but the first real DSH runtime smoke on the user's machine remains required before trusting it on an important repository.
