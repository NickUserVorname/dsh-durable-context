# local-dsh-v4-control 0.2.2

Host-side QWEN-V4 control plane for DeepSeek Harness. It registers `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status`, task control tools, source-revision/write-set enforcement, bounded goals, task budgets and disposable Git worktree publication.

The model does **not** receive `tool-goal`. DSH goal state and goal-round-driver remain host-side. Native Windows shell containment outside the selected workspace is reported as degraded/not proven rather than mislabelled HARD.


v0.2.2 adds requirement supersession/provenance, forced WORKING_STATE checkpoint barriers, llama-tokenized reasoning/visible accounting, and deterministic donor baseline inventory.
