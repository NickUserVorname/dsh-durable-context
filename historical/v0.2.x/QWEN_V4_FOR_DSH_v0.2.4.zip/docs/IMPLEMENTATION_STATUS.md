# v0.2.4 implementation status

## Implemented

Everything listed as implemented in v0.2.2 remains, including source revision/task ownership/write-set/worktree/process-lock/ignored-files/checkpoint/requirement-ledger/token-accounting/baseline protections.

v0.2.4 additionally implements:

- high-precision **host intent routing** from exact command-like user phrases into the registered slash-command plane; ambiguous/questions/negations stay ordinary chat; routed input is audit-recorded and the original main-model step is rejected;
- architectural role separation with one physical Qwen: persistent main WORKER on the main session; fresh host-owned SOURCE_CURATOR, TASK_PLANNER, TEST_ANALYST, REVIEWER and ACCEPTANCE_AUDITOR using selected durable state rather than inherited raw transcript;
- `task_done -> TEST_REQUIRED`; `/review` performs configured focused/regression commands, then mandatory read-only TEST_ANALYST, then independent REVIEWER only after TEST_ANALYST PASS;
- TEST_ANALYST/REVIEWER/ACCEPTANCE failure creates authoritative rework input and preserves the same task worktree for `/work`;
- role provider/model explicitly pinned to `llama-local/qwen3.8-27b`; TEST_ANALYST prompt/output are bounded;
- corrected reasoning guarantee: launcher default `--reasoning-budget 6144` is **per reasoning block**, while DSH `maxTokens <= 16384` is the request-wide completion limit;
- request-wide reasoning-output-starvation detector; one host-steered action-only rescue with exactly the next request forced to `reasoningEffort=off`, `maxTokens<=4096`; repeated starvation becomes `BUDGET_PAUSED`;
- all previous task-wide reasoning/visible/tool/time budgets remain cumulative across rework epochs.

## Honest limitations

- Native Windows outside-workspace shell isolation remains `DEGRADED_WINDOWS / NOT_PROVEN`.
- The high-precision intent router intentionally covers only command-like phrases. It is not a general semantic classifier; unsupported/ambiguous wording is ordinary chat.
- The TEST_ANALYST is an additional sequential inference, so it costs latency/tokens even though it does not require another resident model/context.
- `--reasoning-budget` is not treated as a request-wide hard reasoning ceiling; current llama.cpp may re-arm it on a new reasoning block. The host starvation detector + 16384 total completion cap are the request-wide protection.
- A full live adversarial qualification against the exact installed DSH build on the target Windows host remains required before trusting an important repository.

## Validation in this build environment

- JavaScript syntax checks PASS.
- existing v0.2/v0.2.1/v0.2.2 core/Git/ownership/checkpoint/process-lock regression tests PASS;
- v0.2.4 intent-router zero-main-model-step test PASS;
- mandatory TEST_ANALYST -> REVIEWER ordering PASS;
- TEST_ANALYST FAIL -> TEST_FAILED + same-worktree rework PASS;
- reasoning-starvation -> next request `reasoningEffort=off`, maxTokens=4096 PASS;
- package JSON/YAML/tarball/manifest validation PASS after final packing.
