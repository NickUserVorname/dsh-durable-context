# QWEN-V4-FOR-DSH — Frozen v0.2 architecture + v0.2.4 hardening

## 1. Target runtime

- Runtime: DeepSeek Harness (DSH), current developer-preview architecture.
- Main model: Qwen3.8-27B Q4_K_M served by llama-server.
- One physical Qwen model; role separation is by fresh invocations/contexts, not permanently resident multi-agent conversations.
- Old OpenCode runtime, OpenCode model routing and permanent eight-agent topology are removed.

## 2. Model policy

Default production profile:

- reasoning effort: `MEDIUM`;
- llama reasoning sampler budget: 6144 tokens per reasoning block (not a request-wide cap);
- max completion: 16384 tokens/request;
- raw thinking preservation: OFF;
- XHIGH: manual host/user override only, not exposed as an automatic escalation;
- provider retries: zero for the local llama route.

Project memory is explicit durable state/evidence, not raw hidden reasoning.

## 3. Host-owned task continuation

DSH host owns:

- goal service;
- goal-round-driver;
- project state;
- slash commands;
- task budgets and guards.

`/work` creates one goal for the active atomic packet with `maxGoalRounds = 6` and arms it.
The same session may continue automatically while the task remains `IN_PROGRESS`. Before a dirty turn with uncheckpointed meaningful tool/evidence is allowed to become idle, host `agent/turn-stopping` steers a checkpoint-only step in that same turn; only after `task_checkpoint` succeeds may the turn close and goal-round-driver schedule the next round. If the model refuses the checkpoint, autonomous work pauses instead of spending another round.
Qwen is **not** given model-facing `tool-goal` and cannot grant itself more rounds.

DSH goal state is an execution-continuation mechanism only. It is never authoritative Project Pack task state.

## 4. Disabled autonomous machinery

The Qwen preset does not expose:

- Ralph;
- generic workflow loops;
- generic fork/spawn tools;
- swarm/team machinery;
- autonomous next-phase transition;
- model-facing goal lifecycle control.

Host commands may use the host subagent registry directly for bounded read-only one-shot roles. These are host-owned workflow roles, not model-controlled delegation.

## 5. Anti-runaway per turn

- max steps per turn: 12;
- max tool calls per turn: 32;
- exact failed `tool + canonical args` replay after one failure: DENY;
- repeated attempt to hammer an already denied replay: CANCEL current turn.

This is a hard guard, not an advisory reminder.

## 6. Task-wide circuit breaker

Host defaults:

```yaml
task_budget:
  max_model_requests: 30
  max_reasoning_tokens: 80000
  max_visible_output_tokens: 40000
  max_tool_calls: 120
  max_active_execution_minutes: 90
  max_failed_hypotheses: 2
```

`max_active_execution_minutes` counts active model/tool execution only, never human idle time.
An atomic task packet may reduce these values. It cannot increase them above host policy.
Only host/user policy may increase the ceilings.

When provider/runtime reports `reasoningTokens` separately, it is authoritative and accumulated separately.
For the local llama/pi-ai route, where reasoning is normally folded into aggregate output usage, host accounting separates durable DSH `reasoning` blocks from visible `text/tool-call` blocks and tokenizes each projection through the local llama.cpp `/tokenize` endpoint. Accounting is per model step and includes failed requests that have `assistant/chunk` output/usage but no committed `assistant/message`. If block separation/tokenization cannot be completed, the step fails safe by charging aggregate generated output against both reasoning and visible-output ceilings.

The second evidence-backed failed hypothesis immediately pauses/escalates the task.
Other numeric maxima are inclusive; exceeding them transitions to `BUDGET_PAUSED`.

## 7. Authoritative task state machine

States:

- `NO_TASK`
- `READY`
- `IN_PROGRESS`
- `TEST_REQUIRED`
- `TEST_FAILED`
- `REVIEW_REQUIRED`
- `REVIEW_FAILED`
- `ACCEPTANCE_REQUIRED`
- `ACCEPTANCE_FAILED`
- `ACCEPTED`
- `BUDGET_PAUSED`
- `SCOPE_EXPANSION_REQUIRED`
- `SCOPE_VIOLATION`
- `BLOCKED_EXTERNAL`
- `BLOCKED_SPEC`
- `BLOCKED_QUALIFICATION`
- `STALE`

DSH goal lifecycle never replaces this state machine.
`ACCEPTED` and `STALE` are terminal for the packet.
No next phase begins automatically.

## 8. Source authority and `source_revision`

Preserved source classes:

- `CANONICAL_SPEC`
- `NORMATIVE_CORRECTION`
- `SUPPLEMENTARY_CLEAN_SPEC`
- `DIRTY_REQUIREMENT_DRAFT`
- `DIRTY_IDEA`
- `CONVERSATION_TRANSCRIPT`
- `AUDIT_REVIEW`
- `IMPLEMENTATION_LOG`
- `CURRENT_STATE_REPORT`
- `REPO_EVIDENCE`
- `UNKNOWN`

User text inside a conversation transcript can be normative. Previous assistant text is not normative unless the user explicitly adopts it.

Every normative/conflict-state change increments `source_revision`.
Any non-accepted active packet built at an older revision becomes `STALE`.
A stale packet may not mutate files.
A correction arriving from another session blocks/cancels the actual active worker, not merely the correction session.

`ACTIVE_REQUIREMENTS.json` is a provenance ledger. Generated prose views do not replace provenance.

## 9. Atomic packet contract

An executable packet includes at least:

- id;
- exact `source_revision`;
- objective;
- requirement/source refs;
- preserve list;
- replace/remove/add lists;
- forbidden substitutions;
- `write_set`;
- explicit acceptance criteria;
- optional budget reductions.

The planner also records machine-readable `BASELINE.json` and `PRESERVE_CONTRACT.json` before mutation.

`shadow`, `sidecar`, `stub`, proxy metrics, or green focused tests cannot satisfy a requirement for canonical production integration or a different user-visible outcome.

## 10. Mutation containment

### Direct DSH editor

Before every direct `write/edit`:

1. active packet exists and task is `IN_PROGRESS`;
2. packet revision equals current project revision;
3. task budget is not exhausted;
4. path resolves inside the disposable task worktree;
5. path matches packet `write_set`.

Failure is a hard pre-execution DENY.

### Shell

Shell calls during `/work` must set an explicit `workdir` inside the disposable task worktree.
After each shell call the host checks:

- donor root stayed clean;
- all Git-observed worktree changes are inside `write_set`.

Unauthorized changes become `SCOPE_VIOLATION`, block the goal and cancel the worker.

Absolute external executable/read paths are allowed (e.g. a project venv Python); the guard must not reproduce the earlier PowerShell failure by forbidding a valid interpreter path.

### Windows truthfulness

Native Windows DSH sandbox enforcement cannot currently prove that arbitrary shell code cannot write outside the disposable workspace. Therefore status must expose:

- `DIRECT_WRITE_GUARD = HARD`
- `SHELL_WRITE_GUARD = DEGRADED_WINDOWS`
- `SHELL_OUTSIDE_WORKSPACE = NOT_PROVEN`

Git diff is not presented as protection for arbitrary paths outside the worktree.
For absolute shell write isolation, move shell execution into a stronger WSL/Linux/container sandbox later; this is not a v0.2 launch prerequisite.

## 11. Commands

- `/status`: deterministic, zero model inference.
- `/triage`: command handler launches a bounded fresh read-only source-curator invocation, validates structured output, then host mutates project state.
- `/task`: bounded fresh read-only planner invocation, then host validates/stamps exact revision and writes packet/baseline/preserve contract.
- `/work`: deterministic host transition into `IN_PROGRESS`, creates/reuses disposable worktree and host goal <=6 rounds.
- `/review`: fresh read-only independent reviewer; no implementer hidden reasoning.
- `/accept`: fresh narrow read-only outcome auditor; publish only after PASS and final TOCTOU revision/write-set/donor checks.

`/review` failure returns to rework without destroying the task worktree.
`/accept` PASS publishes approved worktree changes and stops. It never starts the next phase.

## 12. Selected skills

- source-triage
- spec-navigator
- implementation-planner
- task-packet
- debugger
- regression-checker
- state-recovery
- production-integrity
- acceptance-auditor

Skills are procedural knowledge. Hard invariants remain host code/state.

## 13. Deferred, non-launch-blocking work

- SearXNG provider for zero-cost web search;
- stronger shell isolation on native Windows;
- benchmark/resource lock;
- semantic no-progress detector;
- MTP and exact GPU split optimization;
- preserve-thinking A/B after the safe baseline is stable.

## 14. Required qualification before real project work

The harness must pass the adversarial suite in `tests/RUNTIME_ADVERSARIAL_SUITE.md`, including stale revisions, repeated failed calls, outside-write-set edits, shell diff violations, bounded goals, budget pausing, fresh read-only review and zero-inference `/status`.

## Project identity and cross-session authority

The authoritative project identity is the validated Git toplevel derived from the DSH session's durable `session.cwd`. The host keeps a runtime map keyed by that Git root.

- sessions whose `session.cwd` resolves to the same Git root share one Project Pack, `source_revision`, active packet and active worker authority;
- sessions attached to different Git roots must never share Project Pack state;
- process cwd is never project authority;
- a cross-session normative correction must invalidate/cancel the real active worker for that same project.


---

## v0.2.2 mandatory hardening delta

The frozen architecture above is unchanged. `HARDENING_V0_2_2.md` is normative for implementation details added after the v0.2 audit. It includes all v0.2.1 hardening plus: active-worker ownership on every model-facing task-control tool; ignored-file-aware shell/donor checks; process-shared project locking; evidence-covered non-empty forced checkpoints; field-aware WORKING_STATE projection; and host-authoritative `open_acceptance`.


## 19. v0.2.4 host intent routing

Slash commands remain the deterministic workflow API. In addition, a small high-precision host router runs before the main model step. Exact command-like human phrases may map to `/triage`, `/task`, `/work`, `/review`, `/accept` or `/status`. The host executes the registered command directly and rejects the original model step, so routing does not consume a main-Qwen inference.

The router MUST fail open to ordinary chat for questions, negations, hypotheticals, quoted/discussed commands, overlong input, or unsupported wording. It is deliberately not a broad LLM semantic classifier. Each routed message is audit-recorded with original text, routed command and command result.

## 20. Roles and transport

There is still one physical Qwen and one llama-server slot. Architectural roles are host-owned workflow stages; their transport may differ:

- WORKER — persistent main DSH session, same transcript/worktree and bounded goal continuation;
- SOURCE_CURATOR — fresh bounded read-only spawn for `/triage`;
- TASK_PLANNER — fresh bounded read-only spawn for `/task`;
- TEST_ANALYST — mandatory fresh bounded read-only spawn after implementation;
- REVIEWER — mandatory fresh bounded read-only spawn after test gate PASS;
- ACCEPTANCE_AUDITOR — mandatory fresh bounded read-only spawn after review PASS.

Fresh roles share selected durable Project Pack state, task packet, diff/evidence and WORKING_STATE as needed. They do **not** inherit the worker's raw transcript/hidden reasoning. Generic model-facing subagent/fork tools remain absent.

## 21. Mandatory test gate and rework loop

`task_done` no longer means review-ready. It transitions `IN_PROGRESS -> TEST_REQUIRED`.

The first stage of `/review` when state is `TEST_REQUIRED` is:

1. run host-configured `focused_tests` and `regression_tests` from `TOOLCHAIN.json` in the task worktree;
2. re-check write-set and donor integrity;
3. persist deterministic test results;
4. if deterministic commands fail, synthesize a TEST_ANALYST failure without calling reviewer;
5. otherwise run fresh TEST_ANALYST with selected bounded context and read-only tools;
6. TEST_ANALYST FAIL -> `TEST_FAILED`, write authoritative REWORK packet, preserve same worktree;
7. `/work` resumes the same task/worktree with mandatory rework findings;
8. TEST_ANALYST PASS -> `REVIEW_REQUIRED`, then the same `/review` command proceeds to the independent REVIEWER.

Reviewer/acceptance failure similarly creates authoritative rework input. A worker cannot skip TEST_ANALYST, REVIEWER or ACCEPTANCE_AUDITOR by claiming success in prose.

## 22. Request-wide reasoning-output-starvation hardening

Current llama.cpp reasoning-budget semantics are treated as **per reasoning block**. A new reasoning start tag may receive a fresh sampler budget in the same response. Therefore `6144` is not described as a hard request-wide reasoning maximum.

The protections are layered:

- llama sampler: 6144 per reasoning block by default;
- DSH request: total completion `maxTokens <= 16384`;
- host task: cumulative reasoning <=80K and visible output <=40K;
- host starvation detector: if a completed main-worker step has no tool call, counted reasoning >=10000 and visible/action output <1024, the host records starvation and steers an action-only rescue in the same turn;
- exactly the next request is forced through `agent/request` to `reasoningEffort=off`, `maxTokens<=4096`;
- the rescue cannot increase task ceilings and still counts against cumulative task budgets;
- more than the configured recovery count (default 2) transitions the task to `BUDGET_PAUSED` rather than burning further autonomous rounds.

This mechanism protects required tool/schema/action space without attempting to inspect or semantically mine hidden CoT.

## 23. Frozen boundary after v0.2.4

This hardening does not reopen the core architecture. Deferred items remain optional later work: SearXNG, stronger Windows/WSL/container outside-workspace isolation, benchmark-lock optimization, and empirical GPU/context tuning. Before important repository use, the runtime adversarial suite must be executed against the exact installed DSH build.

## v0.2.4 intent routing policy

Natural-language workflow routing is a host convenience layer, not orchestration authority delegated to a model. The router uses deterministic RU+EN lexical grammar plus current Project Pack task state. It never invokes a classifier model.

Routing is conservative:
- imperative command families may route only when the current state permits the requested transition;
- questions, negations, hypotheticals, quoted discussion, and unsupported language remain ordinary chat;
- `/triage`, `/task`, `/work`, `/review`, `/accept`, and `/status` remain the authoritative explicit interface.

The parser is compositional (fillers + verb family + object family), so common forms such as `ну, проверь код`, `проверь что получилось`, `review code`, and `check implementation` do not require one regex per sentence. Contextual forms such as `посмотри код` route only in review-capable states.
