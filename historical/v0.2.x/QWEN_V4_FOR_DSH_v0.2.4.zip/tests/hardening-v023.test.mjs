import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'
import { workflowIntent } from '../dsh-bundle-v4-control/lib/intent-router.js'
import { collectBaselineInventory } from '../dsh-bundle-v4-control/lib/baseline.js'
import { createTaskWorktree, gitHead } from '../dsh-bundle-v4-control/lib/git.js'
import { ensureProject, initialState, loadState, loadTask, saveState, saveTask } from '../dsh-bundle-v4-control/lib/state.js'
import { tokenEntryKey } from '../dsh-bundle-v4-control/lib/token-accounting.js'

function git(cwd,...args){ const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'}); if(r.status!==0) throw new Error(r.stderr||r.stdout); return r.stdout }
function initRepo(prefix='qv4-v023-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T');
  fs.mkdirSync(path.join(root,'src')); fs.writeFileSync(path.join(root,'src','a.js'),'export const a = 1\n');
  git(root,'add','-A'); git(root,'commit','-m','base'); return root
}

// 1) High-precision deterministic intent routing. Discussion/questions/negation must NOT route.
assert.equal(workflowIntent('перейди к планированию')?.command,'task')
assert.equal(workflowIntent('начинай реализацию')?.command,'work')
assert.equal(workflowIntent('проверь всё')?.command,'review')
assert.equal(workflowIntent('проведи приёмку')?.command,'accept')
assert.equal(workflowIntent('почему ты перешёл к планированию?'), null)
assert.equal(workflowIntent('не переходи к планированию'), null)
assert.equal(workflowIntent('если перейдём к планированию, что будет?'), null)

// 2) Intent router invokes command plane and rejects original model step: zero main-Qwen request.
{
  const root=initRepo('qv4-intent-')
  const hooks=[]; const executed=[]
  const ctx={logger:{warn(){}},agents:{get(){}},on(n,f){if(n==='agent/pre-step')hooks.push(f)},tools:{guard(){},register(){}},commands:{register(){},async execute(_a,line){executed.push(line);return {commandId:'c',result:{kind:'success',text:'ok'}}}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}}}
  apply(ctx,{tokenizerEndpoint:''})
  const router=hooks[0]
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const msg={id:'m',role:'user',content:[{type:'text',text:'перейди к планированию'}],source:{kind:'user'}}
  const d=await router({agent,messages:[msg],turn:1,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[msg]}))
  assert.equal(d.kind,'reject'); assert.deepEqual(executed,['/task'])
}

// 3) Mandatory TEST_ANALYST runs before reviewer; PASS advances to acceptance, FAIL becomes reworkable TEST_FAILED.
{
  const root=initRepo('qv4-testrole-'); const paths=ensureProject(root)
  const wt=path.join(root,'.dsh','runtime','worktrees','T1'); const created=createTaskWorktree(root,wt,'T1')
  const baseline=collectBaselineInventory(root,paths.toolchain); fs.writeFileSync(path.join(paths.taskPackets,'T1.BASELINE_INVENTORY.json'),JSON.stringify(baseline,null,2))
  fs.writeFileSync(path.join(paths.taskPackets,'T1.PRESERVE_CONTRACT.json'),JSON.stringify({task_id:'T1'},null,2))
  const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='TEST_REQUIRED'; saveState(paths,state)
  const task={schema_version:4,id:'T1',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.js'],acceptance:['a'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{...created,failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:null,epoch_start_seq:null,token_accounting:{entries:{},latest_mode:'none'}}}; saveTask(paths,task)
  const commands=new Map(); const labels=[]
  const ctx={logger:{warn(){}},agents:{get(){}},on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(_provider,req){labels.push(req.label); const structured=req.label==='test-analyst'?{pass:true,summary:'tests good',findings:[],tests_to_add:[]}:{pass:true,summary:'review good',findings:[]}; return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured,output:[]}),async dispose(){}}}}}
  apply(ctx,{tokenizerEndpoint:'',roleProvider:'llama-local',roleModel:'qwen3.8-27b'})
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const r=await commands.get('review').handler({agent,signal:new AbortController().signal})
  assert.equal(r.kind,'success'); assert.deepEqual(labels,['test-analyst','independent-review']); assert.equal(loadState(paths).task_state,'ACCEPTANCE_REQUIRED')
}


// 3b) TEST_ANALYST failure is authoritative rework on the SAME worktree and reviewer is not run.
{
  const root=initRepo('qv4-testfail-'); const paths=ensureProject(root)
  const wt=path.join(root,'.dsh','runtime','worktrees','TF'); const created=createTaskWorktree(root,wt,'TF')
  const baseline=collectBaselineInventory(root,paths.toolchain); fs.writeFileSync(path.join(paths.taskPackets,'TF.BASELINE_INVENTORY.json'),JSON.stringify(baseline,null,2))
  fs.writeFileSync(path.join(paths.taskPackets,'TF.PRESERVE_CONTRACT.json'),JSON.stringify({task_id:'TF'},null,2))
  const state=initialState(); state.source_revision=1; state.active_task_id='TF'; state.task_state='TEST_REQUIRED'; saveState(paths,state)
  const task={schema_version:4,id:'TF',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.js'],acceptance:['a'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{...created,failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:null,epoch_start_seq:null,token_accounting:{entries:{},latest_mode:'none'}}}; saveTask(paths,task)
  const commands=new Map(); const labels=[]
  const ctx={logger:{warn(){}},agents:{get(){}},on(){},tools:{guard(){},register(){}},commands:{register(d){commands.set(d.name,d)}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(_provider,req){labels.push(req.label); const structured={pass:false,summary:'missing edge test',findings:[{id:'T1',message:'add failure-mode test'}],tests_to_add:['test failure path']}; return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured,output:[]}),async dispose(){}}}}}
  apply(ctx,{tokenizerEndpoint:'',roleProvider:'llama-local',roleModel:'qwen3.8-27b'})
  const agent={session:{id:'S',header:{cwd:root},events:[]}}
  const r=await commands.get('review').handler({agent,signal:new AbortController().signal})
  assert.equal(r.kind,'success'); assert.deepEqual(labels,['test-analyst']); const st=loadState(paths); assert.equal(st.task_state,'TEST_FAILED')
  const after=loadTask(paths,'TF'); assert.equal(after.execution.worktree,wt); assert.ok(fs.existsSync(path.join(paths.taskPackets,'TF.REWORK.json')))
}

// 4) Request-wide reasoning starvation: one action-only rescue with reasoning OFF, then bounded pause after repeated starvation.
{
  const root=initRepo('qv4-starve-'); const paths=ensureProject(root)
  const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='IN_PROGRESS'; state.worker_session_id='S'; saveState(paths,state)
  const assistant={id:'a',role:'assistant',content:[{type:'reasoning',text:'r'},{type:'text',text:''}],source:{provider:'llama-local',model:'qwen3.8-27b'}}
  const events=[{seq:0,time:1,type:'step/start',data:{turn:1,step:1}},{seq:1,time:2,type:'assistant/message',data:{turn:1,step:1,message:assistant,usage:{outputTokens:12100}}},{seq:2,time:3,type:'step/end',data:{turn:1,step:1}}]
  const task={schema_version:4,id:'T1',source_revision:1,objective:'x',write_set:['src/a.js'],acceptance:['a'],budget:{max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:120,max_active_execution_minutes:90,max_failed_hypotheses:2},execution:{worker_session_id:'S',failed_hypotheses:[],usage_accumulated:{model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0},epoch_session_id:'S',epoch_start_seq:0,steps_since_checkpoint:0,meaningful_since_checkpoint:0,checkpoint_required:false,pending_evidence:[],token_accounting:{entries:{[tokenEntryKey('S',1,1)]:{reasoning_tokens:12000,visible_output_tokens:100,total_output_tokens:12100,mode:'test'}},latest_mode:'test'}}}; saveTask(paths,task)
  const hooks=new Map(); const goals=new WeakMap(); const steered=[]
  const ctx={logger:{warn(){}},agents:{get(id){return id==='S'?agent:undefined}},on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(){},register(){}},commands:{register(){},execute(){return undefined}},goals:{get(a){return goals.get(a)},block(a,_r,b){const g=goals.get(a);if(g){g.phase='blocked';g.blocker=b}},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}}}
  const agent={session:{id:'S',header:{cwd:root},events},steer(m){steered.push(m)},cancel(){}}
  goals.set(agent,{id:'g',revision:1,phase:'active',activation:'armed',roundsStarted:1,maxGoalRounds:6})
  apply(ctx,{tokenizerEndpoint:'',requestReasoningStarvationThreshold:10000,requestVisibleReserveTokens:1024,starvationRecoveryMaxTokens:4096,maxReasoningStarvationRecoveries:2})
  const stop=(hooks.get('agent/turn-stopping')??[])[0]
  await stop({agent,turn:1})
  assert.equal(steered.length,1); assert.equal(loadTask(paths,'T1').execution.force_action_only_next,true)
  const req=(hooks.get('agent/request')??[])[0]
  const cfg=await req({agent,turn:1,step:2},async()=>({provider:'llama-local',model:'qwen3.8-27b',reasoningEffort:'medium',maxTokens:16384}))
  assert.equal(cfg.reasoningEffort,'off'); assert.equal(cfg.maxTokens,4096)
}

console.log('hardening-v023.test.mjs: PASS')
