# llama-server profile

1. Run `llama-server.exe --list-devices` and copy the exact V100 / RTX 3070 Ti device identifiers.
2. Start `start-qwen38-windows.ps1` with those identifiers and your Q4_K_M GGUF.
3. Default: layer split 3:1, ctx 128K, KV q5_0/q4_1, one slot, MEDIUM reasoning, **6144 tokens per reasoning block**, DSH total completion cap 16384/request, raw reasoning history not preserved back into the model template.
4. Current llama.cpp may re-arm the reasoning sampler on another reasoning block in the same response. Do not describe 6144 as a request-wide hard reasoning maximum; v0.2.4 adds host reasoning-output-starvation recovery.
5. See `ADDENDUM_MODEL_GPU_REASONING_TUNING.md` before tuning.
