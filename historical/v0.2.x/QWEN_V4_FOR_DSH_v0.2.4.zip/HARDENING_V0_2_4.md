# QWEN-V4-FOR-DSH v0.2.4 — host intent, mandatory test role, and request-wide reasoning hardening

v0.2.4 does **not** redesign the v0.2 architecture. It adds three agreed control-plane features after v0.2.2.

## H1 — high-precision host intent router

Problem: registering `/triage`, `/task`, `/work`, `/review`, `/accept`, `/status` does not mean a plain human phrase such as `перейди к планированию` will invoke the corresponding host transition. Leaving this to the main model recreates the old model-owned orchestration failure mode.

Implementation:

- `agent/pre-step` inspects only a single genuine user-source message on step 1;
- `workflowIntent()` matches only a small exact command-like phrase set;
- questions, negations, hypotheticals, quoted discussion, unsupported wording and overlong messages are not routed;
- on match, host calls `ctx.commands.execute(agent, slashCommand, signal)`;
- the original main-model step is rejected, so routing uses zero main-Qwen model requests;
- an audit record stores original text, routed command and command result;
- explicit slash commands remain the deterministic escape hatch.

This is **host intent dispatch**, not “Qwen guesses which command to call”.

## H2 — mandatory TEST_ANALYST role and feedback loop

Architectural roles are host-owned workflow stages, even when DSH transport is a fresh `spawn`.

`task_done` now transitions only to `TEST_REQUIRED`.

When `/review` sees `TEST_REQUIRED`:

1. host runs configured focused/regression commands from `TOOLCHAIN.json` in the disposable task worktree;
2. host persists deterministic results and verifies task scope/donor integrity;
3. if deterministic tests pass, host starts fresh read-only `TEST_ANALYST` using the same physical `llama-local/qwen3.8-27b` sequentially;
4. role input is selected/bounded (`testRoleInputMaxChars=64000` default); output is capped (`testRoleMaxTokens=8192`); no write/shell tools are exposed;
5. TEST_ANALYST FAIL -> `TEST_FAILED`, write `<task>.REWORK.json`, preserve same worktree, stop before reviewer;
6. `/work` on `TEST_FAILED` resumes the same worktree and receives the authoritative rework packet;
7. TEST_ANALYST PASS -> `REVIEW_REQUIRED`, then independent REVIEWER runs;
8. REVIEW/ACCEPTANCE FAIL also produce authoritative rework packets.

There is no persistent second model and no `--parallel 2`. The fresh role uses the one physical Qwen/server slot after the worker request has ended. It shares curated durable state/evidence, not inherited raw transcript/CoT.

## H3 — request-wide reasoning-output-starvation guard

Problem: current llama.cpp `--reasoning-budget` is a **per reasoning-block** sampler budget. If a model emits another reasoning start tag in the same response, the sampler can re-arm. Therefore the previous statement “8192 reasoning tokens per request” was too strong.

v0.2.4 baseline:

- `--reasoning-budget 6144` per reasoning block;
- DSH `maxTokens <= 16384` total completion per request;
- task cumulative reasoning <=80K / visible <=40K remain unchanged.

Main-worker starvation detector:

- after token accounting for a completed step, if there is no tool call;
- reasoning >=10000 tokens;
- visible/action output <1024 tokens;
- host records a starvation recovery and steers an action-only rescue step;
- exactly the next `agent/request` is rewritten to `reasoningEffort=off`, `maxTokens<=4096`;
- after the configured recovery count (default 2), another starvation transitions to `BUDGET_PAUSED` and blocks continuation.

This does not semantically inspect hidden CoT. It uses already-separated token accounting and the presence/absence of required action/tool output.

## H4 — retained v0.2.2 guarantees

All v0.2.2 hardening remains: worker ownership on terminal tools, ignored-file scope coverage, process-shared project lock, substantive evidence-covered checkpoints, field-aware WORKING_STATE projection, host-authoritative open acceptance, requirement supersession/provenance, donor baseline inventory, source revision/write-set/worktree guards and cumulative task budgets.

## Qualification status

Local regression/mock/Git/process tests cover the new router, mandatory test-role ordering/failure path and starvation rescue request. These tests do not replace a live installed-DSH adversarial run. Native Windows outside-workspace shell containment remains `DEGRADED_WINDOWS / NOT_PROVEN`.

## v0.2.4 — Intent grammar and packaging portability

- Natural workflow routing is deterministic and model-free: compositional RU+EN grammar, harmless discourse-filler normalization, explicit question/negation/hypothetical/quotation guards, and project-state-aware dispatch.
- Review commands now cover natural forms such as `проверь`, `проверь код`, `посмотри реализацию`, `review code`, and `check implementation`, but only route when the task state can legally enter review. Ambiguous/disallowed-state phrases remain ordinary chat; slash commands stay authoritative.
- Planning/work/review/accept routes are state-gated. `status` and explicit triage remain available regardless of task state. Explicit payload forms may contain negative requirements without being mistaken for command negation.
- No tiny LLM/classifier is used. Unknown language or ambiguous phrasing fails open to ordinary chat.
- Regression tests use package-relative imports via `import.meta.url`; build-machine absolute paths are prohibited by release validation.
- Release qualification must extract the ZIP to a fresh/random directory and run the complete local test set from that extracted copy.
