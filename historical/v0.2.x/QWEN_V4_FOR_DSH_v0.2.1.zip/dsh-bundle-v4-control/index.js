import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { spawnSync } from 'node:child_process'
import {
  DEFAULT_BUDGET, REWORKABLE_STATES, budgetExceeded, callKey, clampBudget,
  failureText, foldUsage, pathAllowed, safeWorktreeTarget, statusText,
} from './lib/core.js'
import {
  atomicWriteJson, createRuntime, loadState, loadTask, projectPaths, readJson,
  saveState, saveTask, taskFile, withRuntimeLock,
} from './lib/state.js'
import {
  applyPatchToDonor, assertDonorUnchanged, changedPaths, createTaskWorktree,
  donorFingerprint, gitHead, gitRoot, removeTaskWorktree, stageAndPatch,
  unauthorizedPaths,
} from './lib/git.js'
import { applyRequirementDelta, normalizeLedger, renderFullSpec, validateRequirementRefs, writeFullSpec } from './lib/ledger.js'
import { collectBaselineInventory, compareBaselineInventory } from './lib/baseline.js'
import { checkpointDue, emptyWorkingState, mergeWorkingState, renderWorkingStateContext, resetCheckpointCounters } from './lib/working-state.js'
import { accountEpochSteps, tokenLedgerUsage } from './lib/token-accounting.js'

export const name = 'local-dsh-v4-control'
export const inject = ['tools', 'commands', 'goals', 'subagents', 'sessions', 'agents']

const DEFAULTS = Object.freeze({
  maxGoalRounds: 6,
  maxStepsPerTurn: 12,
  maxToolCallsPerTurn: 32,
  maxTokensPerRequest: 16384,
  identicalFailureLimit: 1,
  cancelAfterBlockedAttempts: 2,
  checkpointEverySteps: 3,
  tokenizerEndpoint: 'http://127.0.0.1:8080/tokenize',
  taskBudget: DEFAULT_BUDGET,
})

const runtimeByRoot = new Map()
const turnStates = new WeakMap()
const shellBefore = new WeakMap()

function positiveInt(v, field, fallback) {
  const value = v ?? fallback
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(`${field} must be a positive safe integer`)
  return value
}

function runtimeForAgent(agent) {
  const cwd = agent?.session?.header?.cwd
  if (!cwd) throw new Error('QWEN-V4 requires a DSH session with an explicit workspace cwd')
  const root = gitRoot(cwd)
  let runtime = runtimeByRoot.get(root)
  if (!runtime) {
    runtime = createRuntime(root)
    runtimeByRoot.set(root, runtime)
  }
  return runtime
}

function current(runtime) {
  const state = loadState(runtime.paths)
  const task = state.active_task_id ? loadTask(runtime.paths, state.active_task_id) : null
  return { state, task }
}

function agentId(agent) {
  return String(agent?.session?.id ?? agent?.session?.header?.id ?? agent?.id ?? 'unknown-session')
}

function goalRef(goal) { return { id: goal.id, revision: goal.revision } }

function completeGoal(ctx, agent) {
  try {
    const goal = ctx.goals.get(agent)
    if (goal && goal.phase !== 'complete') ctx.goals.complete(agent, goalRef(goal))
  } catch {}
}

function blockGoal(ctx, agent, code, message) {
  try {
    const goal = ctx.goals.get(agent)
    if (goal?.phase === 'active') ctx.goals.block(agent, goalRef(goal), { code, message })
  } catch {}
}

function removeWorker(runtime, agent) {
  runtime.activeWorkers.delete(agent)
}

function blockAndCancel(ctx, runtime, agent, code, message) {
  blockGoal(ctx, agent, code, message)
  try { agent.cancel({ kind: 'hook', reason: message }, { keepInbox: false }) } catch {}
  removeWorker(runtime, agent)
}

const ZERO_USAGE = Object.freeze({
  model_requests: 0, reasoning_tokens: 0, visible_output_tokens: 0,
  tool_calls: 0, active_execution_ms: 0, failed_hypotheses: 0,
})

function addUsage(a = ZERO_USAGE, b = ZERO_USAGE, failedHypotheses = 0) {
  return {
    model_requests: (a.model_requests ?? 0) + (b.model_requests ?? 0),
    reasoning_tokens: (a.reasoning_tokens ?? 0) + (b.reasoning_tokens ?? 0),
    visible_output_tokens: (a.visible_output_tokens ?? 0) + (b.visible_output_tokens ?? 0),
    tool_calls: (a.tool_calls ?? 0) + (b.tool_calls ?? 0),
    active_execution_ms: (a.active_execution_ms ?? 0) + (b.active_execution_ms ?? 0),
    failed_hypotheses: failedHypotheses,
  }
}

function taskUsage(agent, task) {
  const failed = task?.execution?.failed_hypotheses?.length ?? 0
  const accumulated = task?.execution?.usage_accumulated ?? ZERO_USAGE
  const epochSession = task?.execution?.epoch_session_id
  const start = task?.execution?.epoch_start_seq
  if (!agent || start === null || start === undefined || epochSession !== agentId(agent)) {
    return { ...accumulated, failed_hypotheses: failed }
  }
  const events = agent?.session?.events ?? []
  const current = foldUsage(events, start, 0)
  const blockUsage = tokenLedgerUsage(task, agentId(agent), start, events)
  if (blockUsage.complete) {
    current.reasoning_tokens = blockUsage.reasoning_tokens
    current.visible_output_tokens = blockUsage.visible_output_tokens
    current.token_accounting_mode = blockUsage.modes.length === 1 ? blockUsage.modes[0] : blockUsage.modes.join('+') || 'none'
  } else {
    current.token_accounting_mode = 'conservative-fallback'
  }
  const total = addUsage(accumulated, current, failed)
  total.token_accounting_mode = current.token_accounting_mode ?? task?.execution?.token_accounting?.latest_mode ?? 'unknown'
  return total
}

async function backfillTokenAccounting(runtime, agent, task, tokenizerEndpoint) {
  if (!task?.execution || task.execution.epoch_session_id !== agentId(agent)) return
  const start = task.execution.epoch_start_seq
  if (start === null || start === undefined) return
  task.execution.token_accounting ??= { entries: {}, latest_mode: 'uninitialized' }
  const entries = task.execution.token_accounting.entries
  const accounted = await accountEpochSteps(agent?.session?.events ?? [], {
    sessionId: agentId(agent), startSeq: start, tokenizerEndpoint, existingEntries: entries,
  })
  const additions = accounted.additions ?? {}
  if (Object.keys(additions).length > 0) {
    Object.assign(entries, additions)
    if (accounted.latestMode) task.execution.token_accounting.latest_mode = accounted.latestMode
    saveTask(runtime.paths, task)
  }
}

function snapshotUsage(agent, task, { closeEpoch = false } = {}) {
  if (!task?.execution) task.execution = {}
  const failed = task.execution.failed_hypotheses?.length ?? 0
  const total = taskUsage(agent, task)
  task.execution.last_usage = total
  if (closeEpoch) {
    task.execution.usage_accumulated = { ...total, failed_hypotheses: 0 }
    task.execution.epoch_session_id = null
    task.execution.epoch_start_seq = null
  }
  return { ...total, failed_hypotheses: failed }
}

function beginUsageEpoch(agent, task) {
  task.execution ??= {}
  task.execution.usage_accumulated ??= { ...ZERO_USAGE }
  task.execution.epoch_session_id = agentId(agent)
  task.execution.epoch_start_seq = agent?.session?.events?.length ?? 0
  task.execution.worker_session_id = agentId(agent)
}

function activeBudget(task) {
  return clampBudget(task?.budget ?? {}, DEFAULT_BUDGET)
}

function pauseForBudget(ctx, runtime, agent, state, task, field) {
  state.task_state = 'BUDGET_PAUSED'
  state.worker_session_id = null
  task.execution ??= {}
  task.execution.budget_pause_reason = field
  snapshotUsage(agent, task, { closeEpoch: true })
  saveTask(runtime.paths, task)
  saveState(runtime.paths, state)
  blockAndCancel(ctx, runtime, agent, 'task-budget', `Task budget paused: ${field}`)
}

function turnStateFor(agent, turn) {
  const old = turnStates.get(agent)
  if (old && old.turn === turn) return old
  const fresh = { turn, toolCalls: 0, failures: new Map(), blockedAttempts: new Map() }
  turnStates.set(agent, fresh)
  return fresh
}

function semanticToolFailure(exec, result) {
  if (result?.isError) return { failed: true, text: failureText(result) }
  if ((exec.name === 'pwsh' || exec.name === 'bash') && result?.value && typeof result.value === 'object') {
    const v = result.value
    if (v.kind === 'foreground') {
      if (v.sandbox?.denied) return { failed: true, text: 'SHELL_SANDBOX_DENIED' }
      if (v.timedOut) return { failed: true, text: 'SHELL_TIMEOUT' }
      if (v.aborted) return { failed: true, text: 'SHELL_ABORTED' }
      if (typeof v.exitCode === 'number' && v.exitCode !== 0) return { failed: true, text: `SHELL_EXIT_${v.exitCode}` }
    }
  }
  return { failed: false, text: '' }
}

function mutationAuthority(runtime, agent) {
  const { state, task } = current(runtime)
  if (!task || state.task_state !== 'IN_PROGRESS') return { ok: false, reason: `No IN_PROGRESS task (state=${state.task_state})`, state, task }
  if (task.source_revision !== state.source_revision) return { ok: false, reason: `STALE_PACKET: packet=${task.source_revision}, project=${state.source_revision}`, state, task }
  if (state.worker_session_id && state.worker_session_id !== agentId(agent)) return { ok: false, reason: `Task owned by another session: ${state.worker_session_id}`, state, task }
  if (!task.execution?.worktree || !task.execution?.baseline_commit) return { ok: false, reason: 'Task worktree is not initialized', state, task }
  return { ok: true, state, task }
}

function directWriteReason(runtime, agent, exec) {
  const auth = mutationAuthority(runtime, agent)
  if (!auth.ok) return auth.reason
  const target = exec.arguments?.file_path
  const checked = safeWorktreeTarget(target, auth.task.execution.worktree)
  if (!checked.ok) return `DIRECT_WRITE_DENIED: ${checked.reason}. Use absolute task-worktree paths.`
  if (checked.relative === '.dsh' || checked.relative.startsWith('.dsh/') || checked.relative === '.git' || checked.relative.startsWith('.git/')) return `RESERVED_PATH_DENIED: ${checked.relative}`
  if (!pathAllowed(checked.relative, auth.task.write_set ?? [])) return `OUTSIDE_WRITE_SET: ${checked.relative}`
  return undefined
}

function shellReason(runtime, agent, exec) {
  const auth = mutationAuthority(runtime, agent)
  if (!auth.ok) return auth.reason
  if (exec.arguments?.run_in_background === true) return 'BACKGROUND_SHELL_DISABLED: foreground only during controlled /work'
  const workdir = exec.arguments?.workdir
  if (!workdir) return 'SHELL_WORKDIR_REQUIRED: set absolute workdir inside the disposable task worktree'
  const checked = safeWorktreeTarget(workdir, auth.task.execution.worktree)
  if (!checked.ok) return `SHELL_WORKDIR_DENIED: ${checked.reason}`
  const perm = String(exec.arguments?.sandbox_permissions ?? '')
  if (/danger|full|escalat/i.test(perm)) return 'SHELL_PERMISSION_ESCALATION_DENIED'
  return undefined
}

function recordEvidence(runtime, taskId, kind, value) {
  const dir = runtime.paths.evidence
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, `${taskId}.${kind}.${Date.now()}.json`)
  atomicWriteJson(file, value)
  return file
}

function makeTool(name, description, properties, required, execute) {
  return {
    name,
    description,
    parameters: { type: 'object', additionalProperties: false, properties, required },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    execute,
  }
}

async function runFresh(ctx, parent, invocationSignal, { label, persona, prompt, outputSchema }) {
  const run = await ctx.subagents.start('spawn', {
    label,
    parent,
    signal: invocationSignal,
    prompt: [{ type: 'text', text: prompt }],
    maxDepth: 1,
    toolFilter: { allow: ['read', 'grep', 'glob', 'skill'] },
    persona,
    outputSchema,
  })
  try {
    const result = await run.result
    if (result.stopReason !== 'completed') throw new Error(`${label} subagent stopped with ${result.stopReason}`)
    if (result.structured === undefined) throw new Error(`${label} subagent returned no structured output`)
    return result.structured
  } finally {
    await run.dispose()
  }
}

const TRIAGE_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    normative_change: { type: 'boolean' },
    summary: { type: 'string' },
    classified_sources: { type: 'array', items: { type: 'object', additionalProperties: false, properties: {
      label: { type: 'string' }, class: { type: 'string' }, authority: { type: 'string' }, precedence: { type: 'string' }, notes: { type: 'string' },
    }, required: ['label','class','authority','precedence','notes'] } },
    requirements: { type: 'array', items: { type: 'object', additionalProperties: false, properties: {
      text: { type: 'string' }, source_label: { type: 'string' }, source_ref: { type: 'string' }, authority: { type: 'string' }, supersedes: { type: 'array', items: { type: 'string' } },
    }, required: ['text','source_label','source_ref','authority','supersedes'] } },
    conflicts: { type: 'array', items: { type: 'string' } },
  }, required: ['normative_change','summary','classified_sources','requirements','conflicts'],
}

const TASK_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    objective: { type: 'string' },
    requirement_refs: { type: 'array', items: { type: 'string' } },
    preserve: { type: 'array', items: { type: 'string' } },
    replace: { type: 'array', items: { type: 'string' } },
    remove: { type: 'array', items: { type: 'string' } },
    add: { type: 'array', items: { type: 'string' } },
    forbidden: { type: 'array', items: { type: 'string' } },
    write_set: { type: 'array', items: { type: 'string' } },
    acceptance: { type: 'array', items: { type: 'string' } },
    budget: { type: 'object', additionalProperties: true },
  }, required: ['objective','requirement_refs','preserve','replace','remove','add','forbidden','write_set','acceptance','budget'],
}

const REVIEW_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    pass: { type: 'boolean' }, summary: { type: 'string' },
    findings: { type: 'array', items: { type: 'object', additionalProperties: false, properties: {
      id: { type: 'string' }, severity: { type: 'string' }, message: { type: 'string' }, evidence: { type: 'string' },
    }, required: ['id','severity','message','evidence'] } },
  }, required: ['pass','summary','findings'],
}

const ACCEPT_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    pass: { type: 'boolean' }, summary: { type: 'string' },
    findings: { type: 'array', items: { type: 'string' } },
  }, required: ['pass','summary','findings'],
}

function commandTextError(error) { return { kind: 'error', text: error instanceof Error ? error.message : String(error) } }

function ensureTaskCanWork(state, task, runtime, invocationAgent) {
  if (state.task_state === 'IN_PROGRESS') {
    const live = [...runtime.activeWorkers].filter(Boolean)
    if (live.length > 0) {
      if (live.includes(invocationAgent)) throw new Error('Task is already running in this session')
      throw new Error('Task is already running in another session')
    }
    // Recovery is safe only in the SAME persisted DSH session, otherwise the old
    // session usage cannot be accounted for conservatively.
    const epochSession = task?.execution?.epoch_session_id
    if (epochSession && epochSession !== agentId(invocationAgent)) {
      throw new Error(`Task has an orphaned active epoch owned by ${epochSession}. Resume /work in that DSH session or explicitly recover/replan; cross-session budget reset is forbidden.`)
    }
    return 'resume-epoch'
  }
  if (!REWORKABLE_STATES.has(state.task_state)) throw new Error(`Task cannot enter /work from state ${state.task_state}`)
  return 'new-epoch'
}

function buildGoalObjective(runtime, task) {
  const working = runtime.paths.workingState
  return [
    `Complete atomic task ${task.id}: ${task.objective}`,
    `AUTHORITATIVE PACKET: ${taskFile(runtime.paths, task.id)}`,
    `TASK WORKTREE: ${task.execution.worktree}`,
    `DURABLE WORKING STATE: ${working}`,
    `All source-code read/write/edit paths and shell workdir MUST use the task worktree, never donor-root relative paths.`,
    `Use task_checkpoint(mode="merge", ...) after meaningful new evidence/decision. The host injects WORKING_STATE on every automatic goal round and may HARD-BLOCK all other tools until a required checkpoint succeeds.`,
    `When all acceptance items are evidenced, call task_done.`,
    `For a true external/spec/qualification blocker call task_blocked.`,
    `If another file is required outside write_set call task_scope_expansion; do not write it.`,
    `After an evidence-backed hypothesis fails call task_failed_hypothesis.`,
    `Do not stop with only "next step" or partial shadow work; the host will continue this goal for at most 6 rounds.`,
  ].join('\n')
}

function taskId() {
  const ts = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)
  return `TASK-${ts}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`
}

function sourceId() {
  const ts = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)
  return `SRC-${ts}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`
}

function safeFilename(id) { return id.replace(/[^A-Za-z0-9_.-]/g, '_') }

function automaticGoalRound(messages = []) {
  return messages.find(message => message?.source?.kind === 'goal' && Number(message.source.round) > 0)?.source?.round ?? null
}

function pluginSnapshotMessage(text, section = 'qwen-v4-working-state') {
  const id = crypto.randomUUID()
  return Object.freeze({
    id,
    role: 'user',
    content: Object.freeze([Object.freeze({ type: 'text', text })]),
    source: Object.freeze({ kind: 'plugin', plugin: name, form: 'snapshot', sections: Object.freeze([Object.freeze({ name: section, text })]) }),
  })
}

function markCheckpointProgress(task, { stepIncrement = 0, meaningfulIncrement = 0 } = {}) {
  task.execution ??= {}
  task.execution.steps_since_checkpoint = Number(task.execution.steps_since_checkpoint ?? 0) + stepIncrement
  task.execution.meaningful_since_checkpoint = Number(task.execution.meaningful_since_checkpoint ?? 0) + meaningfulIncrement
}


export function apply(ctx, config = {}) {
  const resolved = {
    maxGoalRounds: positiveInt(config.maxGoalRounds, 'maxGoalRounds', DEFAULTS.maxGoalRounds),
    maxStepsPerTurn: positiveInt(config.maxStepsPerTurn, 'maxStepsPerTurn', DEFAULTS.maxStepsPerTurn),
    maxToolCallsPerTurn: positiveInt(config.maxToolCallsPerTurn, 'maxToolCallsPerTurn', DEFAULTS.maxToolCallsPerTurn),
    maxTokensPerRequest: positiveInt(config.maxTokensPerRequest, 'maxTokensPerRequest', DEFAULTS.maxTokensPerRequest),
    identicalFailureLimit: positiveInt(config.identicalFailureLimit, 'identicalFailureLimit', DEFAULTS.identicalFailureLimit),
    cancelAfterBlockedAttempts: positiveInt(config.cancelAfterBlockedAttempts, 'cancelAfterBlockedAttempts', DEFAULTS.cancelAfterBlockedAttempts),
    checkpointEverySteps: positiveInt(config.checkpointEverySteps, 'checkpointEverySteps', DEFAULTS.checkpointEverySteps),
    tokenizerEndpoint: String(config.tokenizerEndpoint ?? process.env.QWEN_V4_TOKENIZER_ENDPOINT ?? DEFAULTS.tokenizerEndpoint),
  }

  // Main model output cap. Reasoning itself is separately bounded at llama-server.
  ctx.on('agent/request', async (_payload, next) => {
    const base = await next()
    return { ...base, maxTokens: base.maxTokens === undefined ? resolved.maxTokensPerRequest : Math.min(base.maxTokens, resolved.maxTokensPerRequest) }
  })

  // Per-turn/task-wide circuit breaker + deterministic WORKING_STATE rehydration.
  // At an automatic goal round, any assistant step since the last successful checkpoint
  // makes working state dirty and becomes a HARD checkpoint barrier:
  // the model sees the current distilled state, but every tool except task_checkpoint is
  // denied until it externalizes the useful state. The same barrier is also raised when
  // a long in-round sequence exceeds checkpointEverySteps.
  ctx.on('agent/pre-step', async ({ agent, messages = [], turn, step }, next) => {
    const turnState = turnStateFor(agent, turn)
    if (step > resolved.maxStepsPerTurn) {
      try {
        const runtime = runtimeForAgent(agent)
        const { state, task } = current(runtime)
        if (task && state.task_state === 'IN_PROGRESS') pauseForBudget(ctx, runtime, agent, state, task, 'max_steps_per_turn')
      } catch {}
      return { kind: 'reject' }
    }

    let injected = null
    try {
      const runtime = runtimeForAgent(agent)
      const { state, task } = current(runtime)
      if (task && state.task_state === 'IN_PROGRESS' && state.worker_session_id === agentId(agent)) {
        await backfillTokenAccounting(runtime, agent, task, resolved.tokenizerEndpoint)
        const usage = taskUsage(agent, task)
        const exceeded = budgetExceeded(usage, activeBudget(task))
        if (exceeded) {
          pauseForBudget(ctx, runtime, agent, state, task, exceeded)
          return { kind: 'reject' }
        }

        const round = automaticGoalRound(messages)
        const due = checkpointDue(task, {
          isAutomaticGoalRound: round !== null,
          maxStepsWithoutCheckpoint: resolved.checkpointEverySteps,
        })
        if (due && !task.execution?.checkpoint_required) {
          task.execution ??= {}
          task.execution.checkpoint_required = true
          task.execution.checkpoint_required_reason = round !== null
            ? `automatic_goal_round_${round}_after_${task.execution.steps_since_checkpoint ?? 0}_uncheckpointed_step(s)_and_${task.execution.meaningful_since_checkpoint ?? 0}_tool_result(s)`
            : `steps_without_checkpoint_${task.execution.steps_since_checkpoint ?? 0}`
          saveTask(runtime.paths, task)
        }
        if (round !== null || due) {
          const working = readJson(runtime.paths.workingState, emptyWorkingState(task.id))
          injected = pluginSnapshotMessage(renderWorkingStateContext(working, {
            checkpointRequired: Boolean(task.execution?.checkpoint_required),
          }))
        }
      }
    } catch (error) {
      ctx.logger?.warn?.(`v4-control pre-step accounting/checkpoint failed: ${String(error)}`)
    }

    const decision = await next()
    if (!injected || decision.kind !== 'enter') return decision
    return { kind: 'enter', messages: [injected, ...decision.messages] }
  })

  // A forced checkpoint is not advisory. If an automatic continuation was
  // checkpoint-gated and the model ends the turn without successfully writing
  // task_checkpoint, stop autonomous continuation immediately rather than burning
  // more goal rounds on text-only/reasoning-only responses.
  // The same hook also enforces the final host-owned goal-round cap.
  ctx.on('agent/turn-stopping', async ({ agent, turn }) => {
    try {
      const runtime = runtimeForAgent(agent)
      const { state, task } = current(runtime)
      if (!task || state.task_state !== 'IN_PROGRESS' || state.worker_session_id !== agentId(agent)) return
      await backfillTokenAccounting(runtime, agent, task, resolved.tokenizerEndpoint)
      if (task.execution?.checkpoint_required) {
        state.task_state = 'BUDGET_PAUSED'
        state.worker_session_id = null
        task.execution ??= {}
        task.execution.budget_pause_reason = 'checkpoint_barrier_unresolved'
        task.execution.checkpoint_protocol_violation = {
          at: new Date().toISOString(),
          reason: task.execution.checkpoint_required_reason ?? 'host checkpoint barrier',
          action: 'Autonomous continuation paused because the required checkpoint was not emitted before turn stop.',
        }
        snapshotUsage(agent, task, { closeEpoch: true })
        saveTask(runtime.paths, task)
        saveState(runtime.paths, state)
        blockGoal(ctx, agent, 'checkpoint-required', 'Required task_checkpoint was not emitted before turn stop')
        removeWorker(runtime, agent)
        return
      }

      // Most important memory fence: if this turn learned anything through a
      // non-checkpoint tool result and did not externalize it, do NOT let the
      // agent become idle (which would let goal-round-driver schedule the next
      // automatic round). Steer one checkpoint-only step in the SAME turn.
      // The tool guard denies every other tool while checkpoint_required=true.
      if (Number(task.execution?.meaningful_since_checkpoint ?? 0) > 0) {
        task.execution.checkpoint_required = true
        task.execution.checkpoint_required_reason = `pre_goal_continuation_after_turn_${turn}`
        saveTask(runtime.paths, task)
        const working = readJson(runtime.paths.workingState, emptyWorkingState(task.id))
        agent.steer(pluginSnapshotMessage(renderWorkingStateContext(working, { checkpointRequired: true }), 'qwen-v4-checkpoint-barrier'))
        return
      }

      const goal = ctx.goals.get(agent)
      if (goal?.phase === 'active' && goal.roundsStarted >= goal.maxGoalRounds) {
        state.task_state = 'BUDGET_PAUSED'
        state.worker_session_id = null
        task.execution ??= {}
        task.execution.budget_pause_reason = 'max_goal_rounds'
        snapshotUsage(agent, task, { closeEpoch: true })
        saveTask(runtime.paths, task)
        saveState(runtime.paths, state)
        blockGoal(ctx, agent, 'goal-round-cap', `Host goal cap reached: ${goal.roundsStarted}/${goal.maxGoalRounds}`)
        removeWorker(runtime, agent)
      }
    } catch (error) { ctx.logger?.warn?.(`v4-control turn-stop check failed: ${String(error)}`) }
  })

  // Drop stale in-memory worker handles when DSH disposes an agent.
  ctx.on('agent/disposed', ({ agent }) => {
    for (const runtime of runtimeByRoot.values()) runtime.activeWorkers.delete(agent)
  })

  // Persist checkpoint cadence independently of raw hidden reasoning. The assistant
  // message is durable before any tool executes; a successful task_checkpoint in the
  // same step resets this counter afterwards.
  ctx.on('session/event', (session, event) => {
    if (event?.type !== 'assistant/message') return
    const agent = ctx.agents?.get?.(session.id)
    if (!agent || agent.session !== session) return
    try {
      const runtime = runtimeForAgent(agent)
      const { state, task } = current(runtime)
      if (!task || state.task_state !== 'IN_PROGRESS' || state.worker_session_id !== String(session.id)) return
      markCheckpointProgress(task, { stepIncrement: 1 })
      saveTask(runtime.paths, task)
    } catch (error) { ctx.logger?.warn?.(`v4-control checkpoint cadence event failed: ${String(error)}`) }
  })

  // Hard final tool guard: per-turn runaway + task mutation authority.
  ctx.tools.guard((exec) => {
    const agent = exec.agent
    if (!agent) return undefined
    const st = turnStates.get(agent)
    if (st) {
      st.toolCalls += 1
      if (st.toolCalls > resolved.maxToolCallsPerTurn) {
        try {
          const runtime = runtimeForAgent(agent)
          const { state, task } = current(runtime)
          if (task && state.task_state === 'IN_PROGRESS') pauseForBudget(ctx, runtime, agent, state, task, 'max_tool_calls_per_turn')
        } catch {}
        const reason = `anti-runaway: per-turn tool budget exceeded (${st.toolCalls}/${resolved.maxToolCallsPerTurn})`
        try { agent.cancel({ kind: 'hook', reason }, { keepInbox: false }) } catch {}
        return reason
      }
      const key = callKey(exec)
      const failure = st.failures.get(key)
      if (failure && failure.count >= resolved.identicalFailureLimit) {
        const attempts = (st.blockedAttempts.get(key) ?? 0) + 1
        st.blockedAttempts.set(key, attempts)
        const reason = `anti-runaway: exact failed tool replay denied; previous failure=${failure.error}`
        if (attempts >= resolved.cancelAfterBlockedAttempts) {
          try { agent.cancel({ kind: 'hook', reason: `${reason}; repeated denied replay=${attempts}` }, { keepInbox: false }) } catch {}
        }
        return reason
      }
    }

    let runtime
    try { runtime = runtimeForAgent(agent) } catch { return undefined }

    try {
      const { state, task } = current(runtime)
      if (task && state.task_state === 'IN_PROGRESS' && state.worker_session_id === agentId(agent)
        && task.execution?.checkpoint_required && exec.name !== 'task_checkpoint') {
        return `CHECKPOINT_REQUIRED_BEFORE_CONTINUATION: ${task.execution.checkpoint_required_reason ?? 'host policy'}; call task_checkpoint first`
      }
    } catch {}

    if (exec.name === 'write' || exec.name === 'edit') {
      return directWriteReason(runtime, agent, exec)
    }
    if (exec.name === 'pwsh' || exec.name === 'bash') {
      const denial = shellReason(runtime, agent, exec)
      if (denial) return denial
      const auth = mutationAuthority(runtime, agent)
      shellBefore.set(exec, {
        donor: donorFingerprint(runtime.root),
        projectAuthority: donorProjectAuthorityFingerprint(runtime.paths.project),
        baseline: auth.task.execution.baseline_commit,
        writeSet: [...(auth.task.write_set ?? [])],
        worktree: auth.task.execution.worktree,
        taskId: auth.task.id,
      })
    }
    return undefined
  })

  ctx.on('tools/result', (exec, result) => {
    const agent = exec.agent
    if (!agent) return
    const st = turnStates.get(agent)
    if (st) {
      const key = callKey(exec)
      const semantic = semanticToolFailure(exec, result)
      if (semantic.failed) {
        const prev = st.failures.get(key)
        st.failures.set(key, { count: (prev?.count ?? 0) + 1, error: semantic.text })
      } else {
        st.failures.delete(key)
        st.blockedAttempts.delete(key)
      }
    }

    // Every completed non-checkpoint tool result is meaningful evidence for checkpoint cadence,
    // including failures. This counter is host state; raw reasoning is never inspected.
    if (exec.name !== 'task_checkpoint') {
      try {
        const runtime = runtimeForAgent(agent)
        const { state, task } = current(runtime)
        if (task && state.task_state === 'IN_PROGRESS' && state.worker_session_id === agentId(agent)) {
          markCheckpointProgress(task, { meaningfulIncrement: 1 })
          saveTask(runtime.paths, task)
        }
      } catch {}
    }

    if (exec.name !== 'pwsh' && exec.name !== 'bash') return
    const before = shellBefore.get(exec)
    if (!before) return
    shellBefore.delete(exec)
    try {
      const runtime = runtimeForAgent(agent)
      const { state, task } = current(runtime)
      if (!task || task.id !== before.taskId || state.task_state !== 'IN_PROGRESS') return
      const donorNow = donorFingerprint(runtime.root)
      const authorityNow = donorProjectAuthorityFingerprint(runtime.paths.project)
      const bad = unauthorizedPaths(before.worktree, before.baseline, before.writeSet)
      const donorChanged = donorNow.hash !== before.donor.hash
      const authorityChanged = authorityNow !== before.projectAuthority
      if (bad.length > 0 || donorChanged || authorityChanged) {
        state.task_state = 'SCOPE_VIOLATION'
        state.worker_session_id = null
        task.execution.scope_violation = {
          at: new Date().toISOString(),
          unauthorized_worktree_paths: bad,
          donor_changed_during_shell: donorChanged,
          project_authority_changed_during_shell: authorityChanged,
          note: process.platform === 'win32' ? 'Native Windows shell isolation is DEGRADED/NOT_PROVEN outside workspace.' : 'Shell mutation exceeded the admitted task boundary.',
        }
        snapshotUsage(agent, task, { closeEpoch: true })
        saveTask(runtime.paths, task)
        saveState(runtime.paths, state)
        recordEvidence(runtime, task.id, 'scope-violation', task.execution.scope_violation)
        blockAndCancel(ctx, runtime, agent, 'scope-violation', 'Shell mutation violated worktree/write-set/donor boundary')
      }
    } catch (error) {
      ctx.logger?.warn?.(`v4-control shell post-check failed: ${String(error)}`)
    }
  })

  // Model-facing task controls. These do NOT expose DSH goal lifecycle.
  ctx.tools.register(makeTool(
    'task_checkpoint',
    'Persist distilled task memory without preserving raw hidden reasoning. mode=merge is the normal incremental path; mode=replace explicitly rewrites the whole checkpoint. A host checkpoint barrier may require this tool before any other work tool.',
    {
      mode: { type: 'string', enum: ['merge','replace'] },
      known: { type: 'array', items: { type: 'string' } }, decisions: { type: 'array', items: { type: 'string' } },
      evidence: { type: 'array', items: { type: 'string' } }, do_not_repeat: { type: 'array', items: { type: 'string' } },
      open_acceptance: { type: 'array', items: { type: 'string' } }, next_action: { type: 'array', items: { type: 'string' } },
    }, ['mode','known','decisions','evidence','do_not_repeat','open_acceptance','next_action'],
    async (args, exec) => {
      const agent = exec.agent
      if (!agent) throw new Error('task_checkpoint requires an agent')
      const runtime = runtimeForAgent(agent)
      return withRuntimeLock(runtime, async () => {
        const { state, task } = current(runtime)
        if (!task || state.task_state !== 'IN_PROGRESS' || state.worker_session_id !== agentId(agent)) throw new Error('No owned IN_PROGRESS task')
        const previous = readJson(runtime.paths.workingState, emptyWorkingState(task.id))
        const now = new Date().toISOString()
        const value = mergeWorkingState(previous, args, {
          taskId: task.id,
          failedHypotheses: task.execution?.failed_hypotheses ?? [],
          now,
        })
        atomicWriteJson(runtime.paths.workingState, value)
        resetCheckpointCounters(task, { at: now, sessionId: agentId(agent), seq: agent?.session?.seq ?? null })
        delete task.execution.checkpoint_required_reason
        saveTask(runtime.paths, task)
        return { ok: true, task_id: task.id, mode: args.mode, working_state: runtime.paths.workingState, checkpoint_barrier_cleared: true }
      })
    },
  ))

  ctx.tools.register(makeTool(
    'task_failed_hypothesis',
    'Record one evidence-backed failed hypothesis. The second failure pauses autonomous work by policy.',
    { hypothesis: { type: 'string' }, evidence: { type: 'string' } }, ['hypothesis','evidence'],
    async (args, exec) => {
      const agent = exec.agent
      if (!agent) throw new Error('task_failed_hypothesis requires an agent')
      const runtime = runtimeForAgent(agent)
      return withRuntimeLock(runtime, async () => {
        const { state, task } = current(runtime)
        if (!task || state.task_state !== 'IN_PROGRESS') throw new Error('No IN_PROGRESS task')
        task.execution ??= {}; task.execution.failed_hypotheses ??= []
        task.execution.failed_hypotheses.push({ hypothesis: args.hypothesis, evidence: args.evidence, at: new Date().toISOString() })
        const count = task.execution.failed_hypotheses.length
        const max = activeBudget(task).max_failed_hypotheses
        if (count >= max) {
          state.task_state = 'BUDGET_PAUSED'; state.worker_session_id = null
          snapshotUsage(agent, task, { closeEpoch: true }); saveTask(runtime.paths, task); saveState(runtime.paths, state)
          blockGoal(ctx, agent, 'failed-hypotheses', `Failed hypothesis budget reached: ${count}/${max}`)
          removeWorker(runtime, agent)
          return { ok: true, task_state: state.task_state, failed_hypotheses: count, limit: max }
        }
        saveTask(runtime.paths, task)
        return { ok: true, task_state: state.task_state, failed_hypotheses: count, limit: max }
      })
    },
  ))

  ctx.tools.register(makeTool(
    'task_scope_expansion',
    'Request scope expansion instead of writing outside the approved write_set.',
    { requested_paths: { type: 'array', items: { type: 'string' } }, reason: { type: 'string' } }, ['requested_paths','reason'],
    async (args, exec) => terminalTaskTool(ctx, exec, 'SCOPE_EXPANSION_REQUIRED', 'scope-expansion', { requested_paths: args.requested_paths, reason: args.reason }),
  ))

  ctx.tools.register(makeTool(
    'task_blocked',
    'Stop the atomic task only for a concrete external, specification, or qualification blocker.',
    { kind: { type: 'string', enum: ['external','spec','qualification'] }, reason: { type: 'string' }, evidence: { type: 'string' } }, ['kind','reason','evidence'],
    async (args, exec) => {
      const state = args.kind === 'external' ? 'BLOCKED_EXTERNAL' : args.kind === 'spec' ? 'BLOCKED_SPEC' : 'BLOCKED_QUALIFICATION'
      return terminalTaskTool(ctx, exec, state, `blocked-${args.kind}`, { reason: args.reason, evidence: args.evidence })
    },
  ))

  ctx.tools.register(makeTool(
    'task_done',
    'Declare implementation complete only when all non-blocked acceptance items have evidence and the canonical production path is implemented. This advances only to REVIEW_REQUIRED, never to acceptance or the next phase.',
    { summary: { type: 'string' }, evidence: { type: 'array', items: { type: 'string' } } }, ['summary','evidence'],
    async (args, exec) => {
      const agent = exec.agent
      if (!agent) throw new Error('task_done requires an agent')
      const runtime = runtimeForAgent(agent)
      return withRuntimeLock(runtime, async () => {
        const { state, task } = current(runtime)
        if (!task || state.task_state !== 'IN_PROGRESS') throw new Error('No IN_PROGRESS task')
        if (task.source_revision !== state.source_revision) throw new Error('STALE_PACKET')
        const bad = unauthorizedPaths(task.execution.worktree, task.execution.baseline_commit, task.write_set ?? [])
        if (bad.length) throw new Error(`Cannot finish: outside-write-set changes: ${bad.join(', ')}`)
        await backfillTokenAccounting(runtime, agent, task, resolved.tokenizerEndpoint)
        state.task_state = 'REVIEW_REQUIRED'; state.worker_session_id = null
        task.execution.done = { at: new Date().toISOString(), summary: args.summary, evidence: args.evidence }
        snapshotUsage(agent, task, { closeEpoch: true })
        saveTask(runtime.paths, task); saveState(runtime.paths, state)
        completeGoal(ctx, agent); removeWorker(runtime, agent)
        return { ok: true, task_id: task.id, task_state: state.task_state }
      })
    },
  ))

  // Human commands.
  ctx.commands.register({
    name: 'status', description: 'show QWEN-V4 project/task/guard/budget status without model inference', recordInput: false,
    handler: async ({ agent }) => {
      try {
        const runtime = runtimeForAgent(agent)
        const { state, task } = current(runtime)
        const worker = [...runtime.activeWorkers][0]
        const usage = task ? (worker ? taskUsage(worker, task) : task.execution?.last_usage ?? null) : null
        const goalAgent = worker ?? agent
        let goal; try { goal = ctx.goals.get(goalAgent) } catch {}
        return { kind: 'success', text: statusText({ state, packet: task, usage, goal, root: runtime.root }) }
      } catch (error) { return commandTextError(error) }
    },
  })

  ctx.commands.register({
    name: 'triage', description: 'classify dirty requirements/corrections and update source authority/revision', input: { hint: '<paths, pasted correction, transcript, addendum>' },
    handler: async ({ agent, rawInput, signal }) => {
      try {
        if (!rawInput.trim()) return { kind: 'error', text: 'Usage: /triage <source text or paths>' }
        const runtime = runtimeForAgent(agent)
        const structured = await runFresh(ctx, agent, signal, {
          label: 'source-triage',
          persona: 'You are a strict source curator. User text may be normative even inside conversation transcripts. Prior assistant text is non-normative unless explicitly adopted. Never invent a requirement. Every new normative requirement MUST name source_label plus an exact source_ref (section/range/location). If it replaces an active requirement, list that existing REQ id in supersedes. Do not restate unchanged requirements as new requirements. Return only the requested structured object.',
          prompt: `Project root: ${runtime.root}\nProject source policy: ${path.join(runtime.paths.project, 'SOURCE_POLICY.md')}\nCurrent requirement ledger (use active REQ ids in supersedes): ${runtime.paths.requirements}\nCurrent source index: ${runtime.paths.sourceIndex}\nTriage this new material:\n${rawInput}`,
          outputSchema: TRIAGE_SCHEMA,
        })
        return await withRuntimeLock(runtime, async () => {
          const { state, task } = current(runtime)
          const sid = sourceId()
          const oldRevision = state.source_revision
          const newRevision = structured.normative_change ? oldRevision + 1 : oldRevision
          const sourceRecord = { id: sid, received_at: new Date().toISOString(), raw_input: rawInput, result: structured, revision: newRevision }
          atomicWriteJson(path.join(runtime.paths.sourceMaterial, `${safeFilename(sid)}.json`), sourceRecord)
          const index = readJson(runtime.paths.sourceIndex, { schema_version: 3, sources: [] })
          index.schema_version = 3
          index.sources ??= []
          const sourceRecords = structured.classified_sources.map((src, i) => ({
            source_id: `${sid}-${String(i + 1).padStart(2, '0')}`,
            batch_id: sid,
            path_or_label: src.label,
            class: src.class,
            authority: src.authority,
            precedence: src.precedence,
            notes: src.notes,
            revision: newRevision,
            received_at: sourceRecord.received_at,
          }))
          if (sourceRecords.length === 0) throw new Error('Triage must classify at least one source for provenance')
          index.sources.push(...sourceRecords)
          index.revision = newRevision
          index.status = structured.conflicts.length > 0 ? 'conflict' : 'ready'
          atomicWriteJson(runtime.paths.sourceIndex, index)
          const oldLedger = readJson(runtime.paths.requirements, { schema_version: 3, requirements: [] })
          const ledger = applyRequirementDelta(oldLedger, structured, { revision: newRevision, sources: sourceRecords })
          atomicWriteJson(runtime.paths.requirements, ledger)
          writeFullSpec(runtime.paths.fullSpec, ledger, { sourceRevision: newRevision })
          fs.writeFileSync(runtime.paths.conflicts, `# Source conflicts\n\nRevision: ${newRevision}\n\n${structured.conflicts.length ? structured.conflicts.map(x => `- ${x}`).join('\n') : 'None recorded.'}\n`, 'utf8')
          state.source_conflict_count = structured.conflicts.length

          if (structured.normative_change) {
            state.source_revision = newRevision
            if (task && state.task_state !== 'ACCEPTED' && task.source_revision !== newRevision) {
              state.task_state = 'STALE'; state.worker_session_id = null
              task.stale = { at: new Date().toISOString(), old_revision: task.source_revision, current_revision: newRevision, source_id: sid }
              for (const worker of [...runtime.activeWorkers]) {
                snapshotUsage(worker, task, { closeEpoch: true })
                blockAndCancel(ctx, runtime, worker, 'stale-packet', `Normative source revision changed ${oldRevision} -> ${newRevision}`)
              }
              saveTask(runtime.paths, task)
              runtime.activeWorkers.clear()
            }
          }
          saveState(runtime.paths, state)
          return { kind: 'success', text: `Triage complete. source_revision=${state.source_revision}${structured.normative_change ? ` (was ${oldRevision})` : ' (unchanged)'}\n${structured.summary}\nStale active packet: ${state.task_state === 'STALE' ? 'YES' : 'NO'}` }
        })
      } catch (error) { return commandTextError(error) }
    },
  })

  ctx.commands.register({
    name: 'task', description: 'create one atomic packet at the exact current source_revision', input: { hint: '<objective>' },
    handler: async ({ agent, rawInput, signal }) => {
      try {
        const objective = rawInput.trim()
        if (!objective) return { kind: 'error', text: 'Usage: /task <atomic objective>' }
        const runtime = runtimeForAgent(agent)
        const before = current(runtime)
        if ((before.state.source_conflict_count ?? 0) > 0) return { kind: 'error', text: `Cannot create a task while ${before.state.source_conflict_count} material source conflict(s) remain unresolved. Run /triage after resolving precedence.` }
        if (before.state.task_state === 'IN_PROGRESS') return { kind: 'error', text: 'Cannot create a new packet while another task is IN_PROGRESS.' }
        const structured = await runFresh(ctx, agent, signal, {
          label: 'task-planner',
          persona: 'You are an atomic task planner. Preserve donor behavior unless explicitly superseded. Never substitute shadow/sidecar/stub work for required production integration. Build the smallest write_set that can satisfy the objective. Budgets may only be reduced.',
          prompt: `Project root: ${runtime.root}\nCurrent source_revision: ${before.state.source_revision}\nRequirements ledger: ${runtime.paths.requirements}\nProject invariants: ${path.join(runtime.paths.project, 'PROJECT_INVARIANTS.md')}\nCreate one atomic task packet for:\n${objective}`,
          outputSchema: TASK_SCHEMA,
        })
        return await withRuntimeLock(runtime, async () => {
          const { state } = current(runtime)
          if (state.source_revision !== before.state.source_revision) throw new Error('Source revision changed while planner was running; rerun /task')
          if (!Array.isArray(structured.write_set) || structured.write_set.length === 0) throw new Error('Planner returned empty write_set')
          const ledger = readJson(runtime.paths.requirements, { schema_version: 3, requirements: [] })
          const resolvedRequirements = validateRequirementRefs(ledger, structured.requirement_refs)
          const id = taskId()
          const budget = clampBudget(structured.budget ?? {}, DEFAULT_BUDGET)
          const task = {
            schema_version: 3, id, source_revision: state.source_revision, created_at: new Date().toISOString(),
            objective: structured.objective || objective,
            requirement_refs: structured.requirement_refs, requirements_resolved: resolvedRequirements,
            preserve: structured.preserve, replace: structured.replace,
            remove: structured.remove, add: structured.add, forbidden: structured.forbidden,
            write_set: structured.write_set, acceptance: structured.acceptance, budget,
            execution: {
              failed_hypotheses: [], worktree: null, baseline_commit: null,
              usage_accumulated: { ...ZERO_USAGE }, epoch_session_id: null, epoch_start_seq: null, last_usage: null,
              steps_since_checkpoint: 0, meaningful_since_checkpoint: 0, checkpoint_required: false,
              token_accounting: { entries: {}, latest_mode: 'uninitialized' },
            },
          }
          const baselineInventory = collectBaselineInventory(runtime.root, runtime.paths.toolchain)
          const baselineInventoryFile = path.join(runtime.paths.taskPackets, `${id}.BASELINE_INVENTORY.json`)
          const baseline = { schema_version: 3, task_id: id, source_revision: state.source_revision, donor_root: runtime.root,
            donor_head: gitHead(runtime.root), donor_status: safeGitStatus(runtime.root), baseline_inventory: baselineInventoryFile, created_at: new Date().toISOString() }
          const preserve = { schema_version: 3, task_id: id, requirement_refs: task.requirement_refs, preserve: task.preserve, forbidden: task.forbidden, acceptance: task.acceptance, baseline_inventory: baselineInventoryFile }
          saveTask(runtime.paths, task)
          atomicWriteJson(baselineInventoryFile, baselineInventory)
          atomicWriteJson(path.join(runtime.paths.taskPackets, `${id}.BASELINE.json`), baseline)
          atomicWriteJson(path.join(runtime.paths.taskPackets, `${id}.PRESERVE_CONTRACT.json`), preserve)
          const working = emptyWorkingState(id)
          working.open_acceptance = [...task.acceptance]
          atomicWriteJson(runtime.paths.workingState, working)
          state.active_task_id = id; state.task_state = 'READY'; state.worker_session_id = null; state.last_review = null; state.last_acceptance = null
          saveState(runtime.paths, state)
          return { kind: 'success', text: `Created ${id} @ source_revision ${state.source_revision}\nwrite_set: ${task.write_set.join(', ')}\nUse /work.` }
        })
      } catch (error) { return commandTextError(error) }
    },
  })

  ctx.commands.register({
    name: 'work', description: 'start/resume the active atomic packet in a bounded host-owned goal', recordInput: false,
    handler: async ({ agent }) => {
      try {
        const runtime = runtimeForAgent(agent)
        return await withRuntimeLock(runtime, async () => {
          const { state, task } = current(runtime)
          if (!task) throw new Error('No active task. Run /task first.')
          if (task.source_revision !== state.source_revision) { state.task_state = 'STALE'; saveState(runtime.paths, state); throw new Error('STALE_PACKET: rerun /task at current source_revision') }
          const epochMode = ensureTaskCanWork(state, task, runtime, agent)

          task.execution ??= { failed_hypotheses: [] }
          if (!task.execution.worktree || !fs.existsSync(task.execution.worktree)) {
            const wt = path.join(runtime.paths.worktrees, safeFilename(task.id))
            const created = createTaskWorktree(runtime.root, wt, task.id)
            Object.assign(task.execution, created)
          }
          if (epochMode === 'new-epoch') beginUsageEpoch(agent, task)
          else task.execution.worker_session_id = agentId(agent)
          task.execution.started_at ??= new Date().toISOString()
          state.task_state = 'IN_PROGRESS'; state.worker_session_id = agentId(agent)
          saveTask(runtime.paths, task); saveState(runtime.paths, state)
          runtime.activeWorkers.add(agent)

          const existing = ctx.goals.get(agent)
          if (existing && existing.phase !== 'complete') {
            // A stopped goal from an earlier task/recovery must not shadow the new packet.
            try { ctx.goals.clear(agent, goalRef(existing)) } catch {}
          }
          const goal = ctx.goals.create(agent, { objective: buildGoalObjective(runtime, task), maxGoalRounds: resolved.maxGoalRounds })
          return { kind: 'success', text: `WORK STARTED: ${task.id}\nworktree: ${task.execution.worktree}\ngoal rounds: 0/${goal.maxGoalRounds}\nQwen cannot change the goal cap. Use /status to inspect.` }
        })
      } catch (error) { return commandTextError(error) }
    },
  })

  ctx.commands.register({
    name: 'review', description: 'fresh independent requirement/regression/production-integration review', recordInput: false,
    handler: async ({ agent, signal }) => {
      try {
        const runtime = runtimeForAgent(agent)
        const before = current(runtime)
        if (!before.task || before.state.task_state !== 'REVIEW_REQUIRED') return { kind: 'error', text: `Review requires REVIEW_REQUIRED, got ${before.state.task_state}` }
        const task = before.task
        const diffPaths = changedPaths(task.execution.worktree, task.execution.baseline_commit)
        const baselineInventoryFile = path.join(runtime.paths.taskPackets, `${task.id}.BASELINE_INVENTORY.json`)
        const baselineInventory = readJson(baselineInventoryFile, { surface_fingerprints: [] })
        const currentInventory = collectBaselineInventory(task.execution.worktree, runtime.paths.toolchain)
        const baselineDelta = compareBaselineInventory(baselineInventory, currentInventory)
        const baselineDeltaFile = path.join(runtime.paths.evidence, `${task.id}.baseline-surface-delta.json`)
        atomicWriteJson(baselineDeltaFile, baselineDelta)
        const structured = await runFresh(ctx, agent, signal, {
          label: 'independent-review',
          persona: 'You are an independent reviewer. You did not implement this change. Do not trust implementer claims. Tests do not substitute for user outcomes. Shadow/sidecar/stub does not satisfy canonical production integration. Do not modify files.',
          prompt: `Task packet: ${taskFile(runtime.paths, task.id)}\nPreserve contract: ${path.join(runtime.paths.taskPackets, `${task.id}.PRESERVE_CONTRACT.json`)}\nDeterministic baseline inventory: ${baselineInventoryFile}\nBaseline surface delta: ${baselineDeltaFile}\nTask worktree: ${task.execution.worktree}\nChanged paths: ${diffPaths.join(', ') || '(none)'}\nEvidence directory: ${runtime.paths.evidence}\nReview requirement compliance, donor regression, destructive changes, canonical production integration and evidence. Treat removed/changed CLI, entrypoint, API, config, package or test surfaces as regression signals that require explicit normative authority or compatibility evidence.`,
          outputSchema: REVIEW_SCHEMA,
        })
        return await withRuntimeLock(runtime, async () => {
          const { state, task: freshTask } = current(runtime)
          if (!freshTask || freshTask.id !== task.id) throw new Error('Active task changed during review')
          if (freshTask.source_revision !== state.source_revision) { state.task_state = 'STALE'; saveState(runtime.paths, state); throw new Error('Task became STALE during review') }
          const review = { ...structured, task_id: task.id, reviewed_at: new Date().toISOString() }
          atomicWriteJson(path.join(runtime.paths.reviews, `${task.id}.review.json`), review)
          state.last_review = review
          state.task_state = structured.pass ? 'ACCEPTANCE_REQUIRED' : 'REVIEW_FAILED'
          saveState(runtime.paths, state)
          return { kind: 'success', text: `${structured.pass ? 'REVIEW PASS' : 'REVIEW FAIL'}: ${structured.summary}\nstate=${state.task_state}\n${structured.findings.map(f => `- ${f.id}: ${f.message}`).join('\n')}` }
        })
      } catch (error) { return commandTextError(error) }
    },
  })

  ctx.commands.register({
    name: 'accept', description: 'fresh narrow outcome acceptance; publish approved worktree diff on PASS', recordInput: false,
    handler: async ({ agent, signal }) => {
      try {
        const runtime = runtimeForAgent(agent)
        const before = current(runtime)
        if (!before.task || before.state.task_state !== 'ACCEPTANCE_REQUIRED') return { kind: 'error', text: `Accept requires ACCEPTANCE_REQUIRED, got ${before.state.task_state}` }
        const task = before.task
        if (task.source_revision !== before.state.source_revision) throw new Error('STALE_PACKET before acceptance')
        const bad = unauthorizedPaths(task.execution.worktree, task.execution.baseline_commit, task.write_set ?? [])
        if (bad.length) throw new Error(`Outside-write-set changes before acceptance: ${bad.join(', ')}`)
        const donorCheck = assertDonorUnchanged(runtime.root, task.execution.donor_fingerprint)
        if (!donorCheck.ok) throw new Error('Donor root changed since /work baseline; refuse TOCTOU publish and rebase/replan')

        const structured = await runFresh(ctx, agent, signal, {
          label: 'outcome-acceptance',
          persona: 'You are a fresh narrow acceptance auditor. Check whether each user-visible/mandatory outcome is actually satisfied. Proxy metrics, structural validity and green tests are not substitutes for a different required outcome. Do not modify files.',
          prompt: `Task packet: ${taskFile(runtime.paths, task.id)}\nReview: ${path.join(runtime.paths.reviews, `${task.id}.review.json`)}\nTask worktree: ${task.execution.worktree}\nProject requirements: ${runtime.paths.requirements}\nReturn PASS only if every mandatory non-blocked acceptance criterion has direct evidence.`,
          outputSchema: ACCEPT_SCHEMA,
        })

        return await withRuntimeLock(runtime, async () => {
          const { state, task: freshTask } = current(runtime)
          if (!freshTask || freshTask.id !== task.id) throw new Error('Active task changed during acceptance')
          if (freshTask.source_revision !== state.source_revision) { state.task_state = 'STALE'; saveState(runtime.paths, state); throw new Error('Task became STALE during acceptance') }
          const accept = { ...structured, task_id: task.id, accepted_at: new Date().toISOString() }
          atomicWriteJson(path.join(runtime.paths.reviews, `${task.id}.acceptance.json`), accept)
          state.last_acceptance = accept
          if (!structured.pass) {
            state.task_state = 'ACCEPTANCE_FAILED'; saveState(runtime.paths, state)
            return { kind: 'success', text: `ACCEPTANCE FAIL: ${structured.summary}\nstate=ACCEPTANCE_FAILED\nUse /work to rework the SAME task/worktree.` }
          }

          const badFinal = unauthorizedPaths(freshTask.execution.worktree, freshTask.execution.baseline_commit, freshTask.write_set ?? [])
          if (badFinal.length) throw new Error(`TOCTOU outside-write-set change: ${badFinal.join(', ')}`)
          const donorFinal = assertDonorUnchanged(runtime.root, freshTask.execution.donor_fingerprint)
          if (!donorFinal.ok) throw new Error('TOCTOU donor change detected; publish refused')
          const patchText = stageAndPatch(freshTask.execution.worktree, freshTask.execution.baseline_commit)
          const patchFile = path.join(runtime.paths.evidence, `${freshTask.id}.accepted.patch`)
          fs.writeFileSync(patchFile, patchText, 'utf8')
          applyPatchToDonor(runtime.root, patchText)
          freshTask.execution.published_at = new Date().toISOString(); freshTask.execution.accepted_patch = patchFile
          state.task_state = 'ACCEPTED'; state.worker_session_id = null
          saveTask(runtime.paths, freshTask); saveState(runtime.paths, state)
          removeTaskWorktree(runtime.root, freshTask.execution.worktree)
          return { kind: 'success', text: `ACCEPTED and published: ${freshTask.id}\npatch evidence: ${patchFile}\nSTOP. Next phase is NOT automatic.` }
        })
      } catch (error) { return commandTextError(error) }
    },
  })
}

async function terminalTaskTool(ctx, exec, targetState, code, payload) {
  const agent = exec.agent
  if (!agent) throw new Error('task terminal tool requires an agent')
  const runtime = runtimeForAgent(agent)
  return withRuntimeLock(runtime, async () => {
    const { state, task } = current(runtime)
    if (!task || state.task_state !== 'IN_PROGRESS') throw new Error('No IN_PROGRESS task')
    state.task_state = targetState; state.worker_session_id = null
    task.execution ??= {}; task.execution.terminal = { state: targetState, code, payload, at: new Date().toISOString() }
    snapshotUsage(agent, task, { closeEpoch: true }); saveTask(runtime.paths, task); saveState(runtime.paths, state)
    blockGoal(ctx, agent, code, payload.reason ?? targetState)
    removeWorker(runtime, agent)
    return { ok: true, task_id: task.id, task_state: targetState }
  })
}

function donorProjectAuthorityFingerprint(projectDir) {
  const include = ['SOURCE_POLICY.md','SOURCE_INDEX.json','SOURCE_CONFLICTS.md','ACTIVE_REQUIREMENTS.json','CURRENT_PHASE.md','PROJECT_INVARIANTS.md','state.json']
  const parts = []
  for (const name of include) {
    const file = path.join(projectDir, name)
    parts.push([name, fs.existsSync(file) ? crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') : 'MISSING'])
  }
  return crypto.createHash('sha256').update(JSON.stringify(parts)).digest('hex')
}

function safeGitStatus(root) {
  try {
    const r = spawnSync('git', ['-C', root, 'status', '--porcelain=v1', '--untracked-files=all'], { encoding: 'utf8' })
    if (r.error) throw r.error
    return r.stdout ?? ''
  } catch { return '<unavailable>' }
}

export const _test = { semanticToolFailure, directWriteReason, shellReason }
