# Distilled working state — v0.2.1

Raw hidden reasoning is **not** durable project memory. `task_checkpoint` writes only explicit fields:

```yaml
mode: merge | replace
known: []
decisions: []
evidence: []
do_not_repeat: []
open_acceptance: []
next_action: []
```

`merge` is the normal mode: additive evidence/knowledge is deduplicated, while `open_acceptance` and `next_action` represent the current set and replace those fields when supplied. `replace` intentionally rewrites the complete checkpoint.

The host injects the current `WORKING_STATE.json` into every automatic goal round. If meaningful non-checkpoint tool/evidence exists since the last checkpoint, the host raises a **hard checkpoint barrier at turn stop and steers a checkpoint-only step in the same turn before goal-round-driver can schedule another automatic round**. All other tools are denied until `task_checkpoint` succeeds. A long in-round sequence also raises the barrier after the configured step threshold (default 3). Automatic-round pre-step checking remains a fail-closed recovery fence.
