# QWEN-V4-FOR-DSH v0.2.1 — hardening delta

v0.2.1 does not change the frozen v0.2 architecture. It closes four gaps found by the post-build audit.

## H1 — normative requirement ledger

- ledger schema v3: `status=active|superseded`, `active`, `supersedes`, `superseded_by`, `superseded_revision`;
- every new requirement has `source_id`, `source_label`, exact `source_ref`, authority, precedence and introduced revision;
- `/triage` must identify which active requirement ids a correction supersedes;
- unknown/non-active supersede targets are rejected;
- `/task` validates every `requirement_ref` and rejects unknown/superseded refs;
- packet stores `requirements_resolved` as an immutable snapshot;
- `/triage` deterministically regenerates `FULL_SPEC.md` from the ledger. `FULL_SPEC.md` is never an independent authority.

## H2 — mandatory working-state checkpoint barrier

- `task_checkpoint(mode=merge|replace, ...)` has explicit semantics;
- automatic goal rounds always receive a host-injected bounded `WORKING_STATE` snapshot;
- any uncheckpointed meaningful tool/evidence raises a checkpoint-only barrier at `agent/turn-stopping`; host steers the checkpoint in the same turn before the agent can become idle and before goal-round-driver can schedule the next automatic round;
- after 3 model steps with uncheckpointed meaningful evidence the same barrier can trigger inside a long round;
- while required, every model-facing tool except `task_checkpoint` is hard denied;
- if the model reaches turn-stop without satisfying a required checkpoint, autonomous work is paused as `BUDGET_PAUSED` (`checkpoint_barrier_unresolved`) instead of consuming more goal rounds;
- a successful checkpoint clears the barrier and resets cadence counters;
- no raw reasoning is inspected or mined by this policy.

## H3 — separate reasoning / visible accounting

- DSH `reasoning` and visible `text/tool-call` blocks are separated;
- local llama.cpp `/tokenize` counts each projection with the actual model tokenizer;
- accounting is per model step, not merely per committed assistant message: failed requests with only `assistant/chunk` stream/usage are also charged;
- task accounting records the accounting mode and uses block-separated counts when complete;
- if separation fails, accounting falls back conservatively to charging aggregate output to both budgets.

## H4 — deterministic donor baseline inventory

At `/task`, host creates `<TASK>.BASELINE_INVENTORY.json` with deterministic candidate surfaces and fingerprints:

- entrypoints;
- CLI/menu/command files;
- public API/index surfaces;
- configuration candidates;
- tests/specs;
- package/build manifests;
- package scripts;
- declared TOOLCHAIN commands;
- conservative static public-symbol, CLI option/subcommand and output-artifact signals for candidate surfaces.

At `/review`, host inventories the task worktree again and writes `baseline-surface-delta.json`. Reviewer receives both baseline and delta and must treat removed/changed CLI, entrypoint, API, config, package or test surfaces as regression signals unless current normative authority explicitly permits the change.

## Non-claim

Native Windows shell isolation outside the disposable worktree is still `DEGRADED_WINDOWS / NOT_PROVEN`. v0.2.1 does not relabel that as HARD.
