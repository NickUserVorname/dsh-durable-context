from pathlib import Path
import json, tarfile, yaml, sys
root=Path(__file__).resolve().parents[1]
required=[
 'dist/local-dsh-v4-control-0.2.1.tgz','dsh-bundle-v4-control/package.json','dsh-bundle-v4-control/cordis.patch.yml',
 'dsh-preset-qwen-v4/agent.cordis.yml','dsh-settings/llama-local.settings.example.yaml','llama-server/start-qwen38-windows.ps1',
 'project-template/.dsh/project/state.json','project-template/.dsh/project/SOURCE_POLICY.md','project-template/.dsh/project/ACTIVE_REQUIREMENTS.json',
 'ADDENDUM_MODEL_GPU_REASONING_TUNING.md','FINAL_SPEC_V0_2_1.md','HARDENING_V0_2_1.md','INSTALL_V0_2_1_WINDOWS.ps1','tests/hardening-v021.test.mjs','tests/checkpoint-barrier.mock.test.mjs','tests/checkpoint-force-pause.mock.test.mjs','tests/checkpoint-pre-goal.mock.test.mjs'
]
for r in required:
    assert (root/r).exists(), f'missing {r}'
for p in root.rglob('*.json'):
    json.loads(p.read_text(encoding='utf-8'))
class Loader(yaml.SafeLoader): pass
Loader.add_constructor('tag:yaml.org,2002:js', lambda loader,node: loader.construct_scalar(node))
for p in list(root.rglob('*.yml'))+list(root.rglob('*.yaml')):
    yaml.load(p.read_text(encoding='utf-8'),Loader=Loader)
with tarfile.open(root/'dist/local-dsh-v4-control-0.2.1.tgz','r:gz') as t:
    names=set(t.getnames())
    for n in ['package/package.json','package/index.js','package/cordis.patch.yml','package/lib/core.js','package/lib/state.js','package/lib/git.js','package/lib/ledger.js','package/lib/working-state.js','package/lib/token-accounting.js','package/lib/baseline.js']:
        assert n in names, f'tgz missing {n}'
print('validate_package.py: PASS')
