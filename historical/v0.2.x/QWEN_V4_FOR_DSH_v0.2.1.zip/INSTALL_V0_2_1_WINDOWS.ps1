param(
  [Parameter(Mandatory=$true)][string]$ProjectRoot,
  [string]$DshCommand = "dsh",
  [switch]$SkipPluginInstall
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Plugin = Join-Path $Here "dist\local-dsh-v4-control-0.2.1.tgz"
$PresetSrc = Join-Path $Here "dsh-preset-qwen-v4"
$PresetDst = Join-Path $HOME ".dsh\.agent-presets\qwen-v4"
$ProjectTemplate = Join-Path $Here "project-template\.dsh"
$ProjectDst = Join-Path $ProjectRoot ".dsh"

if (!(Test-Path (Join-Path $ProjectRoot ".git"))) {
  throw "ProjectRoot must be a Git repository root: $ProjectRoot"
}
if (!(Test-Path $Plugin)) { throw "Missing plugin package: $Plugin" }

if (!$SkipPluginInstall) {
  Write-Host "Installing host bundle into DSH web profile..."
  & $DshCommand plugin --profile web add $Plugin
  if ($LASTEXITCODE -ne 0) { throw "DSH plugin install failed ($LASTEXITCODE)" }
}

New-Item -ItemType Directory -Force -Path $PresetDst | Out-Null
Copy-Item (Join-Path $PresetSrc "*") $PresetDst -Recurse -Force
Write-Host "Preset installed: $PresetDst"

New-Item -ItemType Directory -Force -Path $ProjectDst | Out-Null
Copy-Item (Join-Path $ProjectTemplate "*") $ProjectDst -Recurse -Force
Write-Host "Project Pack installed: $ProjectDst"

Write-Host ""
Write-Host "NEXT:"
Write-Host "1) Merge dsh-settings\llama-local.settings.example.yaml into $HOME\.dsh\settings.yaml"
Write-Host "2) `$env:LLAMA_LOCAL_API_KEY='local'"
Write-Host "3) Start llama-server with llama-server\start-qwen38-windows.ps1"
Write-Host "4) Restart DSH web, create a NEW session at $ProjectRoot with preset qwen-v4 and provider llama-local / model qwen3.8-27b"
Write-Host "5) Run /status"
