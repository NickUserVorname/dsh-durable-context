# QWEN-V4-FOR-DSH v0.2.1

This is the hardened installable package. DeepSeek Harness is the runtime; OpenCode v4 is only the donor of source/task/acceptance semantics. v0.2.1 closes the four post-audit gaps without changing architecture.

## Install order (Windows)
1. Install/run DeepSeek Harness and llama.cpp separately.
2. Merge `dsh-settings/llama-local.settings.example.yaml` into `%USERPROFILE%\.dsh\settings.yaml` and set `LLAMA_LOCAL_API_KEY=local`.
3. Start Qwen with `llama-server/start-qwen38-windows.ps1` (first run `llama-server.exe --list-devices`).
4. Run `INSTALL_V0_2_1_WINDOWS.ps1 -ProjectRoot C:\path\to\your\git-project` or manually:
   - `dsh plugin --profile web add .\dist\local-dsh-v4-control-0.2.1.tgz`
   - copy `dsh-preset-qwen-v4` to `%USERPROFILE%\.dsh\.agent-presets\qwen-v4`
   - copy `project-template\.dsh` into the project root.
5. Restart DSH web and create a NEW session using workspace = project root, preset `qwen-v4`, provider `llama-local`, model `qwen3.8-27b`.
6. First command: `/status`.

## Normal workflow
`/triage` -> `/task` -> `/work` -> `/review` -> `/accept`. `/work` continues the same task automatically through host goal rounds, up to 6. `ACCEPTED` stops; the next phase never starts automatically.

Read `FINAL_SPEC_V0_2_1.md`, `HARDENING_V0_2_1.md`, `ADDENDUM_MODEL_GPU_REASONING_TUNING.md`, and `docs/IMPLEMENTATION_STATUS.md`.
