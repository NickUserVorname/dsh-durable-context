$ErrorActionPreference = "Stop"
$Root     = "C:\DSH-QWEN"
$DshHome  = "$Root\dsh-home"
$DshCmd   = "$Root\runtime\dsh\node_modules\.bin\dsh.cmd"
$Node     = "$Root\runtime\node"
$DshBin   = "$Root\runtime\dsh\node_modules\.bin"
$QProject = "$Root\qualification-v080"
$Headers  = @{ Authorization = "Bearer local" }

$env:DSH_HOME = $DshHome
$env:LLAMA_LOCAL_API_KEY = "local"
$env:DSH_TELEMETRY_MODE = "DISABLED"
$env:DEEPSEEK_API_KEY = ""
$env:Path = "$Node;$DshBin;$env:Path"

Write-Host "===== FILE LAYER ====="
foreach ($p in @("$Root\start-qwen38-128k.ps1","$Root\start-dsh-qwen.cmd","$DshHome\settings.yaml","$DshHome\.agent-presets\qwen-v4\agent.cordis.yml","$QProject\.dsh\project\RUNTIME_POLICY.json")) {
  if (!(Test-Path -LiteralPath $p)) { throw "Missing required file: $p" }
  Write-Host "OK $p"
}

Write-Host "===== JSON BOM + PARSE ====="
Get-ChildItem "$QProject\.dsh" -Recurse -File -Filter "*.json" | ForEach-Object {
  $b=[System.IO.File]::ReadAllBytes($_.FullName)
  if ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { throw "UTF-8 BOM found in JSON: $($_.FullName)" }
  Get-Content $_.FullName -Raw | ConvertFrom-Json | Out-Null
}

Write-Host "===== DSH DUMP ====="
$Dump = "$Root\dump-config-v080-verify.txt"
& $DshCmd --profile web --dump-config 2>&1 | Tee-Object -FilePath $Dump | Out-Null
if ($LASTEXITCODE -ne 0) { throw "dsh dump-config failed" }
$Raw=Get-Content $Dump -Raw
foreach ($Pattern in @('local-v4-control','provider:\s*llama-local','model:\s*qwen3.8-27b')) { if ($Raw -notmatch $Pattern) { throw "Missing config: $Pattern" } }
foreach ($Id in @('session-title-llm','web-search-deepseek','llm-deepseek','session-telemetry-otel')) { if ($Raw -notmatch "(?s)- id: $([regex]::Escape($Id)).{0,500}?disabled: true") { throw "Not disabled: $Id" } }

Write-Host "===== V0.8.0 INSTALLED ARCHITECTURE + INTEGRATION ====="
$Installed = "$DshHome\profiles\web\node_modules\local-dsh-v4-control"
$ContextCommands = Get-Content "$Installed\lib\context-commands.js" -Raw
$FreshRole = Get-Content "$Installed\lib\fresh-role.js" -Raw
$IndexJs = Get-Content "$Installed\index.js" -Raw
$CommandsJs = Get-Content "$Installed\lib\commands.js" -Raw
$StateJs = Get-Content "$Installed\lib\state.js" -Raw
$TxnJs = Get-Content "$Installed\lib\project-transaction.js" -Raw
$InstalledPkg = Get-Content "$Installed\package.json" -Raw | ConvertFrom-Json
if ($InstalledPkg.version -ne '0.8.0') { throw "Expected local-dsh-v4-control 0.8.0, got $($InstalledPkg.version)" }
if ($ContextCommands -match "input:\s*\{\s*hint:\s*''\s*\}") { throw "/context still has an empty input hint" }
if ($FreshRole -match "toolFilter:\s*\{\s*allow:\s*\['read',\s*'grep',\s*'glob',\s*'structured_output'\]") { throw "structured_output is still incorrectly listed as a global fresh-role tool filter" }
if ($FreshRole -notmatch "toolFilter:\s*\{\s*allow:\s*\['read',\s*'grep',\s*'glob'\]\s*\}") { throw "Expected fresh-role global allow filter not found" }
if ($IndexJs -notmatch "read','grep','glob','structured_output") { throw "Host fresh-role guard does not admit dynamic structured_output" }
if ($CommandsJs -notmatch 'commitProjectTransaction') { throw "Recoverable triage transaction is not wired into /triage" }
if ($CommandsJs -notmatch 'renderSourceIntakeMarkdown') { throw "Durable SOURCE_INTAKE rendering patch not installed" }
if ($StateJs -notmatch 'recoverProjectTransactions') { throw "Project-lock transaction recovery hook not installed" }
if ($TxnJs -notmatch 'PROJECT_TRANSACTION_TARGET_DIVERGED') { throw "Fail-closed transaction divergence guard not installed" }
$UniversalJs = Get-Content "$Installed\lib\universal-commit.js" -Raw
$HygieneJs = Get-Content "$Installed\lib\context-hygiene.js" -Raw
$EvacJs = Get-Content "$Installed\lib\context-evacuation.js" -Raw
$TokenJs = Get-Content "$Installed\lib\token-accounting.js" -Raw
if ($UniversalJs -match 'FINALIZATION PASS|PRIMARY_VISIBLE_CONTENT_FORBIDDEN_BEFORE_STATE_COMMIT') { throw "Legacy universal finalizer/barrier code still active" }
if ($UniversalJs -notmatch 'state_checkpoint is OPTIONAL' -or $UniversalJs -notmatch 'concludeTurn') { throw "v0.8 optional same-turn investigative checkpoint path not installed" }
if ($HygieneJs -notmatch 'REPEATED: ×') { throw "v0.8 lossless tool repetition hygiene not installed" }
if ($EvacJs -notmatch 'COMPACTION_REFUSED' -or $EvacJs -notmatch 'semantic evacuation') { throw "v0.8 fail-closed semantic evacuation not installed" }
if ($TokenJs -notmatch 'Bearer \$\{apiKey\}') { throw "Authenticated local tokenizer accounting patch not installed" }
$RuntimePolicy = Get-Content "$QProject\.dsh\project\RUNTIME_POLICY.json" -Raw | ConvertFrom-Json
if ($RuntimePolicy.schema_version -ne 'qwen-v4-runtime-policy-0.8.0') { throw "Expected v0.8 runtime policy schema" }
if ($RuntimePolicy.roles.SOURCE_CURATOR.max_tool_calls -ne 20 -or $RuntimePolicy.roles.TASK_PLANNER.max_tool_calls -ne 20) { throw "Expected +20% curator/planner tool headroom" }
Write-Host "V0.8.0 installed architecture/integration checks PASS"

Write-Host "===== LLAMA HEALTH ====="
Invoke-RestMethod "http://127.0.0.1:8080/health" -Headers $Headers -TimeoutSec 5 | Format-List *
$Models=Invoke-RestMethod "http://127.0.0.1:8080/v1/models" -Headers $Headers -TimeoutSec 5
if (-not ($Models.data.id -contains 'qwen3.8-27b')) { throw "qwen3.8-27b alias not exposed" }

Write-Host "===== AUTHENTICATED TOKENIZER ====="
$TokBody=@{content='v080-tokenizer-probe';add_special=$false;parse_special=$true} | ConvertTo-Json -Depth 8
$Tok=Invoke-RestMethod -Uri "http://127.0.0.1:8080/tokenize" -Method POST -Headers $Headers -ContentType 'application/json' -Body $TokBody -TimeoutSec 30
if ($null -eq $Tok.tokens -or $Tok.tokens.Count -lt 1) { throw "Authenticated /tokenize probe returned no tokens" }

Write-Host "===== SHORT TOOL-CALL INFERENCE ====="
$Body=@{
  model='qwen3.8-27b'; messages=@(@{role='user';content='Call echo_probe exactly once with value TOOL_OK. Do not answer in plain text.'});
  tools=@(@{type='function';function=@{name='echo_probe';description='probe';parameters=@{type='object';properties=@{value=@{type='string'}};required=@('value');additionalProperties=$false}}});
  temperature=0; max_tokens=512; stream=$false
} | ConvertTo-Json -Depth 30
$R=Invoke-RestMethod -Uri "http://127.0.0.1:8080/v1/chat/completions" -Method POST -Headers $Headers -ContentType 'application/json' -Body $Body -TimeoutSec 300
$Call=$R.choices[0].message.tool_calls[0]
if ($Call.function.name -ne 'echo_probe' -or $Call.function.arguments -notmatch 'TOOL_OK') { throw "Tool-call qualification failed" }
$R.choices[0].message | ConvertTo-Json -Depth 20

Write-Host "===== GPU ====="
nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader
Write-Host "LIVE LLAMA + DSH LOCAL-ONLY CONFIG PASS - v0.8.0"
