# C:\DSH-QWEN v0.8.0 overlay

This overlay targets the already-qualified machine layout:

- custom llama.cpp: `C:\DSH-QWEN\llama-custom_GGML_CUDA_FA_ALL_QUANTS=ON`
- CUDA 12.9
- llama CUDA0 = V100 16GB, CUDA1 = RTX 3070 Ti 8GB
- Qwen3.8-27B Q4_K_M
- context 131072, split 4:1, K=q8_0, V=q5_1, FlashAttention=on, fit=off
- reasoning medium / 6144 per reasoning block
- `--no-reasoning-preserve`
- local API key `local`

Install into a fresh qualification repo with `02-install-v080-qualification.ps1`, then start the model and run `03-verify-live.ps1`.

v0.8 removes the universal answer finalizer, makes investigative state transfer optional and same-turn, adds deterministic `×N` tool-noise hygiene, uses rare semantic evacuation + fail-closed coverage before pruning, authenticates `/tokenize`, and raises productive tool headroom by about 20%. Existing source-authority, transaction, worktree, approval and independent validation guards remain in force. Static qualification does not replace the live session matrix in `tests/RUNTIME_ADVERSARIAL_SUITE.md`.
