Merge the `llm-pi-ai:` section into the active DSH home `settings.yaml`; do not overwrite unrelated settings. On the target portable install this is `C:\DSH-QWEN\dsh-home\settings.yaml`. Set `LLAMA_LOCAL_API_KEY=local`.

`runtime-policy.example.json` is the v0.8 external host-policy template: fresh-role/tool budgets, investigative-state projection limits, and context-pressure/semantic-compaction thresholds. The removed v0.7 universal commit/finalizer knobs are not part of the v0.8 template.
