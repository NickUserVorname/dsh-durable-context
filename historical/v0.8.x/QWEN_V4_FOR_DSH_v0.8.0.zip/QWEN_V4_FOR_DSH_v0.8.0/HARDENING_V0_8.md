# Hardening v0.8.0 — answer-path simplification and safe context evacuation

v0.8.0 is driven by failures observed after the statically-green v0.7.4 package was exercised live. The changes below are problem-driven: each one removes a demonstrated failure mode rather than adding an independent feature.

## 1. Seven-minute ordinary replies: remove the universal finalizer

### Failure

The v0.7 ordinary path forced every model-backed turn through a checkpoint and then a second Qwen finalization inference. A one-off creative request could therefore trigger tool-policy interactions, durable state mutation, a second reasoning pass and completion truncation even though the first model had already solved the request.

### Resolution

Ordinary turns are direct `MAIN → ANSWER`. Durable state is not an answer transport protocol. Investigative turns may carry an optional state checkpoint in the same assistant message as the answer. Successful checkpoint execution uses terminal-turn semantics, avoiding the post-checkpoint finalizer inference.

### Regression

A creative ordinary turn must end without checkpoint/finalizer and must leave `WORKING_STATE` unchanged unless it actually creates transferable investigative state.

## 2. Durable-state pollution: transfer only material investigative state

### Failure

Mandatory checkpointing incentivized MAIN to treat transient details—current request, answer format, `NO_TASK`, one-off denied write attempts, “wait for user”—as durable facts.

### Resolution

Checkpointing becomes optional and is defined by a resume-after-history-loss test: would this fact be needed to continue the same iterative investigation without repeating work? If not, omit it. `constraints` is explicit. Evidence is allowed to remain concrete when diagnostic precision matters.

## 3. Hidden reasoning is not a compaction target

The qualified launcher uses `--no-reasoning-preserve`; prior raw reasoning is not rendered back into future prompts. v0.8 therefore manages only visible conversation/tool surfaces and durable/canonical state.

## 4. Tool spam: deterministic lossless hygiene

### Failure

Repeated identical failed tool exchanges can consume active context without adding information.

### Resolution

The host folds only exact contiguous single-tool exchanges into one exact exchange plus `×N`. Raw session events remain untouched. Different arguments/results, visible assistant prose, or interrupted sequences are not folded. No LLM is involved.

## 5. Full compaction could lose unique constraints/evidence

### Failure

Treating “checkpoint exists through seq N” as proof that all semantics before N survive can delete an old user constraint or concrete assistant/tool evidence that the checkpoint failed to carry.

### Resolution

Investigative checkpointing and prune authority are separated. Incremental checkpoints never advance `prune_safe_through_seq`. `/compress` performs semantic evacuation over the candidate old visible/tool span, compares against surviving canonical `ACTIVE_REQUIREMENTS`/`SOURCE_INDEX` and `WORKING_STATE`, transfers missing live semantics, then performs coverage audit. Audit `source_seq` references must point inside the actual candidate and a `TRANSFERRED` item must point to a non-empty durable target field. Before commit the host rechecks session revision, source revision, canonical-state fingerprint and working-state fingerprint; any TOCTOU change or uncertainty refuses pruning.

This is intentionally closer to tracing GC than free-form summarization: preserve reachable/live semantics, prove representation, then remove the old active representation. The raw archive remains intact. If HARD pressure cannot be relieved by one bounded compactor input, the host may perform up to three sequential audited completed-turn chunks; it never silently expands one compactor past its input ceiling.

## 6. `/triage` false budget exhaustion at exact cap

### Failure

Fresh role pre-step used `tool_calls >= max_tool_calls`. At exactly 16 productive calls SOURCE_CURATOR could not get the final model step needed to emit `structured_output`, causing `ROLE_BUDGET_EXCEEDED` even though the productive budget had not been exceeded.

### Resolution

Productive tool ceilings receive ~20% headroom and exact-cap semantics are corrected. SOURCE/TASK are 20, TEST/REVIEW 15, ACCEPT 8, task global 144. Exact cap still permits a terminal model step; N+1 productive tool is denied by the hard guard. `structured_output` is uncounted.

## 7. Local tokenizer auth and repeated accounting

### Failure

`/tokenize` requests omitted the local API key, producing llama `Invalid API Key` messages and forcing conservative fallback accounting. Repeated scans could also tokenize immutable historical steps again.

### Resolution

Tokenizer requests add Bearer auth from `LLAMA_LOCAL_API_KEY`; token counts and role-step accounting are cached for immutable content/events.

## 8. NO_TASK mutation retries

### Failure

The hard guard correctly blocked both direct and shell mutations, but MAIN could interpret an ordinary “write some text” request as file creation, receive a denial, then retry equivalent mutation through another channel.

### Resolution

MAIN receives a concise `NO_TASK` authority notice before acting: workspace mutation is unavailable and ordinary composition belongs in chat unless explicit project mutation is requested. Once a mutation-policy denial occurs, equivalent mutation channels are denied for the remainder of that turn. The hard guard itself is not weakened.

## 9. Preserved v0.7.4 authority hardening

The redesign does not relax source authority or execution safety. Retained regressions include: no empty `/context` hint; dynamic `structured_output` excluded from global `tools.restrict()` but admitted by host guard; clean+dirty intersection intake; historical compatibility semantics; relationship-only source revision; durable conflict registry with explicit resolution ids; stale concurrent triage rejection; large input staging; failed/stale staging non-authority; crash-recoverable project transactions; fail-closed divergence; task-packet compatibility; worktree and publication boundaries; execution approval; dynamic remaining validation reserve; independent review/acceptance.

## 10. Release boundary

The built ZIP must be extracted into a clean directory and the complete test/validator/syntax suite rerun there. A source-tree PASS alone is not a release. Live DSH 0.1.1-rc.1 + llama.cpp qualification remains a separate acceptance step.
