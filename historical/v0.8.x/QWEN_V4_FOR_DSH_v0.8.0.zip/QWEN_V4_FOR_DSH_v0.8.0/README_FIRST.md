# QWEN-V4-FOR-DSH v0.8.0

DeepSeek Harness remains the host runtime and local Qwen3.8-27B remains the bounded executor. v0.8.0 is an answer-path and context-management redesign driven by v0.7.4 live failures. It keeps the existing workflow/source-authority system, but removes the universal checkpoint/finalizer ritual from ordinary conversation.

Normative design: `FINAL_SPEC_V0_8.md`. Hardening rationale and regressions: `HARDENING_V0_8.md`.

## The v0.8 answer path

Ordinary turns are ordinary again:

```text
USER → MAIN QWEN ↔ tools → ANSWER
```

There is no mandatory `state_checkpoint`, no `response_basis`, and no second FINALIZER inference.

For investigative / iterative problem-solving (troubleshooting, debugging, research/OSINT, tests, experiments, analytical investigation or iterative construction), MAIN may emit a small optional `state_checkpoint` in the same assistant response as the user-facing answer. The checkpoint is only for material transferable working state. Its successful tool execution commits state and concludes the current DSH turn, so there is no follow-up finalizer request.

Transferable state fields are:

- `known`
- `constraints`
- `decisions`
- `evidence`
- `failed_hypotheses`
- `do_not_repeat`
- `open_acceptance`
- `next_action`

`evidence` may deliberately remain concrete: exact diagnostic log lines, relevant command output, values, file/line locations, fingerprints, reproduction conditions, and counterexamples. Do not abstract away information needed to resume diagnosis.

## Two context-maintenance levels

**Level A — always-on lossless hygiene.** Identical contiguous single-tool exchanges are represented to the model as one exact exchange plus `×N`. The append-only raw session remains untouched. This is deterministic deduplication, not semantic summarization.

**Level B — rare semantic evacuation.** `/compress` or real context pressure considers an old completed-turn span, compares it with surviving canonical/project state plus `WORKING_STATE`, transfers any still-live semantics, performs a fail-closed coverage audit, and only then advances `prune_safe_through_seq` and replaces that old span on the active model surface. Uncertain coverage means `COMPACTION_REFUSED`.

Incremental investigative checkpoints do **not** authorize pruning and do not advance `prune_safe_through_seq`.

## v0.8 runtime fixes

- authenticated local `/tokenize` calls using `LLAMA_LOCAL_API_KEY`, with reuse of token-accounting results for immutable steps;
- productive tool headroom raised by about 20%: task 120→144, SOURCE_CURATOR/TASK_PLANNER 16→20, TEST_ANALYST/REVIEWER 12→15, ACCEPTANCE_AUDITOR 6→8;
- exact tool cap permits the terminal model step; N+1 productive tool is denied by the hard guard; protocol tools such as `structured_output` remain uncounted;
- ordinary `NO_TASK` text requests are explicitly described to MAIN as chat-output requests, not implicit workspace mutation authority;
- after an authoritative mutation-policy denial, an equivalent mutation retry through another tool surface is denied in the same turn;
- `state_checkpoint` remains an optional compatibility/specialized primitive; `/work` retains its stricter task-owned checkpoint/evidence rules.

## Preserved workflow/source-authority hardening

v0.8 retains the v0.7.4 source/transaction model: natural-language `/triage`, PRIMARY/supplementary-dirty/historical relationships, intersection-only dirty intake, strict preserve semantics, durable conflict ids, relationship revision invalidation, stale concurrent triage rejection, large-input staging, crash-recoverable multi-file transactions, legacy task-packet compatibility, project worktree isolation, approval policy, independent TEST/REVIEW/ACCEPT roles, and fail-closed publication/acceptance boundaries.

## Install

Generic Windows install:

```powershell
.\INSTALL_V0_8_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home
```

Direct plugin artifact:

```powershell
dsh plugin --profile web add ".\dist\local-dsh-v4-control-0.8.0.tgz"
```

For the qualified target layout:

```powershell
.\_LOCAL_C_DSH-QWEN\02-install-v080-qualification.ps1
```

The default qualification repo is `C:\DSH-QWEN\qualification-v080`.

## First live checks

After llama-server and DSH start in a **new** qwen-v4 session:

```text
/status
/context
/permissions
```

Then qualify all three paths:

```text
ordinary turn
→ answer without mandatory state/finalizer

investigative material turn
→ visible answer + optional state_checkpoint in one assistant response
→ checkpoint concludes turn

/compress
→ semantic evacuation + coverage audit
→ prune only on PASS
```

Use `_LOCAL_C_DSH-QWEN/03-verify-live.ps1` for installed-file/config/tokenizer/model probes and `tests/RUNTIME_ADVERSARIAL_SUITE.md` for behavioral qualification.

## Qualification status rule

Static/mock tests, package validation, archive round-trip checks and adversarial code tests must pass before release. They do not prove DSH 0.1.1-rc.1 live streaming/tool behavior on Windows; the live matrix remains a separate acceptance step.
