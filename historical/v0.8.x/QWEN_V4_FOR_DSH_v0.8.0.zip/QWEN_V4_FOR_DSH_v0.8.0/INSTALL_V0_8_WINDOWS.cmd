@echo off
setlocal EnableExtensions DisableDelayedExpansion

set "SCRIPT=%~dp0INSTALL_V0_8_WINDOWS.ps1"
set "PROJECT_ROOT="
set "DSH_HOME_ARG="
set "DSH_COMMAND=dsh"
set "EXISTING_POLICY=Stop"
set "POLICY_FILE="
set "SET_VALUES="
set "SKIP_PLUGIN="

:parse
if "%~1"=="" goto run
if /I "%~1"=="--project-root" (
  set "PROJECT_ROOT=%~2"
  shift
  shift
  goto parse
)
if /I "%~1"=="--dsh-home" (
  set "DSH_HOME_ARG=%~2"
  shift
  shift
  goto parse
)
if /I "%~1"=="--dsh-command" (
  set "DSH_COMMAND=%~2"
  shift
  shift
  goto parse
)
if /I "%~1"=="--existing-project-policy" (
  set "EXISTING_POLICY=%~2"
  shift
  shift
  goto parse
)
if /I "%~1"=="--policy-file" (
  set "POLICY_FILE=%~2"
  shift
  shift
  goto parse
)
if /I "%~1"=="--set" (
  if defined SET_VALUES (
    set "SET_VALUES=%SET_VALUES%;%~2"
  ) else (
    set "SET_VALUES=%~2"
  )
  shift
  shift
  goto parse
)
if /I "%~1"=="--skip-plugin-install" (
  set "SKIP_PLUGIN=-SkipPluginInstall"
  shift
  goto parse
)
if /I "%~1"=="--help" goto help
if /I "%~1"=="-h" goto help

echo Unknown option: %~1
exit /b 2

:run
if not defined PROJECT_ROOT (
  echo Missing required --project-root
  exit /b 2
)

set "EXTRA_DSH_HOME="
if defined DSH_HOME_ARG set "EXTRA_DSH_HOME=-DshHome ^"%DSH_HOME_ARG%^""
set "EXTRA_POLICY_FILE="
if defined POLICY_FILE set "EXTRA_POLICY_FILE=-PolicyFile ^"%POLICY_FILE%^""
set "EXTRA_SET="
if defined SET_VALUES set "EXTRA_SET=-Set ^"%SET_VALUES%^""

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -ProjectRoot "%PROJECT_ROOT%" -DshCommand "%DSH_COMMAND%" -ExistingProjectPolicy "%EXISTING_POLICY%" %EXTRA_DSH_HOME% %EXTRA_POLICY_FILE% %EXTRA_SET% %SKIP_PLUGIN%
exit /b %ERRORLEVEL%

:help
echo Usage:
echo   INSTALL_V0_8_WINDOWS.cmd --project-root C:\repo [options]
echo.
echo Options:
echo   --dsh-home PATH

echo   --dsh-command PATH_OR_COMMAND

echo   --existing-project-policy Stop^|MergeMissing

echo   --policy-file PATH

echo   --set dotted.path=value       ^(repeatable^)

echo   --skip-plugin-install

echo.
echo Example:
echo   INSTALL_V0_8_WINDOWS.cmd --project-root C:\repo --dsh-home C:\DSH-QWEN\dsh-home --policy-file C:\cfg\qwen-policy.json --set roles.TEST_ANALYST.max_tokens_per_request=4096
exit /b 0
