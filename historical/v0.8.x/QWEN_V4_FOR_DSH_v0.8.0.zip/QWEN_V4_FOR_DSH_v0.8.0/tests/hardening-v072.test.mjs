import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { authorizeCompactionWorkingState, commitUniversalWorkingState } from '../dsh-bundle-v4-control/lib/context-memory.js'
import { planStructuredCompaction } from '../dsh-bundle-v4-control/lib/context-pressure.js'
import { authorizeExecution, decidePendingExecution, executionPolicyStatus, setExecutionMode } from '../dsh-bundle-v4-control/lib/execution-policy.js'
import { createTaskWorktree, unprovenIgnoredPaths } from '../dsh-bundle-v4-control/lib/git.js'
import { workflowIntent } from '../dsh-bundle-v4-control/lib/intent-router.js'
import { workerReserveExhausted, workerReserveExceededPreStep } from '../dsh-bundle-v4-control/lib/role-control.js'
import { DEFAULT_RUNTIME_POLICY, remainingValidationRoles, validationReserveFor } from '../dsh-bundle-v4-control/lib/runtime-policy.js'
import { atomicWriteJson, createRuntime, ensureProject, initialState, loadTask, saveState, saveTask } from '../dsh-bundle-v4-control/lib/state.js'
import { emptyWorkingState } from '../dsh-bundle-v4-control/lib/working-state.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v072-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix)); git(root,'init'); git(root,'config','user.email','t@x'); git(root,'config','user.name','T')
  fs.mkdirSync(path.join(root,'src')); fs.writeFileSync(path.join(root,'src','a.txt'),'a\n'); fs.writeFileSync(path.join(root,'.gitignore'),'.pytest_cache/\n__pycache__/\n')
  git(root,'add','-A'); git(root,'commit','-m','base'); return root
}
function fullBudget(){return {max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:144,max_active_execution_minutes:90,max_failed_hypotheses:2}}
function usage(o={}){return {model_requests:0,reasoning_tokens:0,visible_output_tokens:0,tool_calls:0,active_execution_ms:0,failed_hypotheses:0,...o}}

// 1) Dynamic remaining-validation reserve is the sum of mandatory role maxima.
{
  const runtime={paths:{runtimePolicy:'/definitely/missing'}}
  assert.deepEqual(remainingValidationRoles('IN_PROGRESS'),['TEST_ANALYST','REVIEWER','ACCEPTANCE_AUDITOR'])
  assert.deepEqual(validationReserveFor(runtime,'IN_PROGRESS'),{max_model_requests:11,max_reasoning_tokens:32000,max_visible_output_tokens:13000,max_tool_calls:38,max_active_execution_minutes:25})
  assert.deepEqual(validationReserveFor(runtime,'REVIEW_REQUIRED'),{max_model_requests:7,max_reasoning_tokens:20000,max_visible_output_tokens:8000,max_tool_calls:23,max_active_execution_minutes:15})
  assert.deepEqual(validationReserveFor(runtime,'ACCEPTANCE_REQUIRED'),{max_model_requests:3,max_reasoning_tokens:8000,max_visible_output_tokens:3000,max_tool_calls:8,max_active_execution_minutes:5})
  assert.deepEqual(validationReserveFor(runtime,'ACCEPTED'),{max_model_requests:0,max_reasoning_tokens:0,max_visible_output_tokens:0,max_tool_calls:0,max_active_execution_minutes:0})
  const reserve=validationReserveFor(runtime,'IN_PROGRESS'); const budget=fullBudget(); const threshold=budget.max_model_requests-reserve.max_model_requests
  assert.equal(threshold,19)
  assert.equal(workerReserveExhausted(usage({model_requests:19}),budget,reserve),'validation_reserve_max_model_requests')
  assert.equal(workerReserveExceededPreStep(usage({model_requests:19}),budget,reserve),undefined)
  assert.equal(workerReserveExceededPreStep(usage({model_requests:20}),budget,reserve),'validation_reserve_max_model_requests')
}

// 2) ASK persists exact allow/deny decisions; AUTO bypasses interactive decisions only.
{
  const root=repo('qv4-perm-'); const runtime=createRuntime(root); const task={id:'T'}; const worktree=root
  let exec={name:'pwsh',arguments:{workdir:root,command:'echo hello'},agent:{id:'A',session:{id:'S'}}}
  let d=authorizeExecution(runtime,exec,{task,worktree}); assert.equal(d.allowed,false); assert.match(d.reason,/APPROVAL_REQUIRED/)
  assert.ok(executionPolicyStatus(runtime).pending)
  decidePendingExecution(runtime,'allow',{currentTaskId:'T'})
  exec={name:'pwsh',arguments:{workdir:root,command:'echo hello'},agent:{id:'A',session:{id:'S'}}}
  d=authorizeExecution(runtime,exec,{task,worktree}); assert.equal(d.allowed,true); assert.equal(d.kind,'approved-rule')

  let denied={name:'pwsh',arguments:{workdir:root,command:'echo denied'},agent:{id:'A',session:{id:'S'}}}
  d=authorizeExecution(runtime,denied,{task,worktree}); assert.equal(d.allowed,false)
  decidePendingExecution(runtime,'deny',{currentTaskId:'T'})
  denied={name:'pwsh',arguments:{workdir:root,command:'echo denied'},agent:{id:'A',session:{id:'S'}}}
  d=authorizeExecution(runtime,denied,{task,worktree}); assert.equal(d.allowed,false); assert.match(d.reason,/DENIED_BY_POLICY/)
  setExecutionMode(runtime,'auto')
  denied={name:'pwsh',arguments:{workdir:root,command:'echo denied'},agent:{id:'A',session:{id:'S'}}}
  d=authorizeExecution(runtime,denied,{task,worktree}); assert.equal(d.allowed,true); assert.equal(d.kind,'auto')
}

// 3) Permission-mode commands are slash-only: natural-language command router never changes trust policy.
for(const text of ['auto','включи auto','ask','спрашивай разрешение','approve','deny','permissions']) assert.equal(workflowIntent(text,{taskState:'IN_PROGRESS'}),null,text)

// 4) Integration: ASK blocks a mutation, /approve remembers it; AUTO allows an
//    inside-worktree change outside write_set but it remains nonpublishable.
//    Worktree/donor hard boundary remains enforced.
{
  const root=repo('qv4-perm-int-'); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const state=initialState(); state.source_revision=1; state.active_task_id='T1'; state.task_state='READY'; saveState(paths,state)
  saveTask(paths,{schema_version:6,id:'T1',source_revision:1,objective:'x',requirement_refs:[],write_set:['src/a.txt'],preserve:[],replace:[],remove:[],add:[],forbidden:[],acceptance:['x'],qualification:{mode:'NOT_APPLICABLE',rationale:'fixture'},budget:fullBudget(),execution:{failed_hypotheses:[],worktree:null,baseline_commit:null,usage_accumulated:usage(),epoch_session_id:null,epoch_start_seq:null,last_usage:null,role_usage:{},pending_evidence:[],token_accounting:{entries:{},latest_mode:'none'}}})
  const hooks=new Map(),guards=[],commands=new Map(),tools=new Map(),goals=new WeakMap(); let blockedGoals=0, cancelled=0
  const ctx={logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:100,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)}},
    subagents:{async start(){throw new Error('n/a')}},goals:{get(a){return goals.get(a)},create(a,o){const g={id:'g',revision:1,phase:'active',activation:'armed',roundsStarted:0,maxGoalRounds:o.maxGoalRounds};goals.set(a,g);return g},clear(){},complete(){},block(){blockedGoals++}}}
  apply(ctx,{tokenizerEndpoint:''})
  const agent={id:'A',session:{id:'S',header:{cwd:root},events:[],seq:0},cancel(){cancelled++},steer(){}}
  assert.equal((await commands.get('work').handler({agent})).kind,'success')
  const task=loadTask(paths,'T1'); const wt=task.execution.worktree
  const runGuard=(exec)=>{for(const g of guards){const r=g(exec);if(r!==undefined)return r}return undefined}
  let exec={name:'write',arguments:{file_path:path.join(wt,'src','a.txt')},agent}
  assert.match(runGuard(exec),/EXECUTION_APPROVAL_REQUIRED/)
  assert.equal(blockedGoals,1); assert.equal(cancelled,1)
  assert.equal((await commands.get('approve').handler({agent})).kind,'success')
  exec={name:'write',arguments:{file_path:path.join(wt,'src','a.txt')},agent}; assert.equal(runGuard(exec),undefined)

  assert.equal((await commands.get('auto').handler({agent})).kind,'success')
  const outside=path.join(wt,'tmp','runtime.txt'); fs.mkdirSync(path.dirname(outside),{recursive:true})
  exec={name:'write',arguments:{file_path:outside},agent}; assert.equal(runGuard(exec),undefined); fs.writeFileSync(outside,'runtime\n')
  for(const h of hooks.get('tools/result')??[]) await h(exec,{isError:false,value:{ok:true}})
  let saved=loadTask(paths,'T1'); assert.ok(saved.execution.execution_side_effects.some(x=>x.path==='tmp/runtime.txt'&&x.kind==='unpublishable'))
  await assert.rejects(()=>tools.get('task_done').execute({summary:'x',evidence:[]},{agent}),/unpublishable or unproven side effects/)

  const donorExec={name:'write',arguments:{file_path:path.join(root,'src','a.txt')},agent}; assert.match(runGuard(donorExec),/DIRECT_WRITE_DENIED/)

  const cache=path.join(wt,'.pytest_cache','a'); fs.mkdirSync(path.dirname(cache),{recursive:true})
  exec={name:'write',arguments:{file_path:cache},agent}; assert.equal(runGuard(exec),undefined); fs.writeFileSync(cache,'x')
  for(const h of hooks.get('tools/result')??[]) await h(exec,{isError:false,value:{ok:true}})
  saved=loadTask(paths,'T1'); assert.ok(saved.execution.execution_side_effects.some(x=>x.path==='.pytest_cache/a'&&x.kind==='ephemeral_ignored'))
  assert.deepEqual(unprovenIgnoredPaths(wt,saved.execution.worktree_ignored_baseline??{},saved.execution.execution_side_effects??[]),[])
  fs.writeFileSync(path.join(wt,'.pytest_cache','unproven'),'x')
  assert.deepEqual(unprovenIgnoredPaths(wt,saved.execution.worktree_ignored_baseline??{},saved.execution.execution_side_effects??[]),['.pytest_cache/unproven'])
}

// 5) Incremental investigative state is not prune authority. Only an explicit
//    semantic-evacuation authorization advances the host-owned prune boundary.
{
  const root=repo('qv4-watermark-'); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const events=[]; const surface=[]; let seq=0
  const addTurn=(turn)=>{events.push({seq:++seq,type:'user/message',data:{message:{role:'user'}}});surface.push(seq);events.push({seq:++seq,type:'turn/start',data:{turn}});events.push({seq:++seq,type:'assistant/message',data:{turn,message:{content:[{type:'text',text:`a${turn}`}]}}});surface.push(seq);events.push({seq:++seq,type:'turn/end',data:{turn,reason:{kind:'completed'}}})}
  for(let turn=1;turn<=4;turn++)addTurn(turn)
  const session={id:'S',seq,header:{cwd:root},events,surface:{nodes:surface}}
  let ws=commitUniversalWorkingState(emptyWorkingState(null),{known:['K1']},{session,sourceRevision:0})
  assert.equal(ws.checkpoint_meta.prune_safe_through_seq,null)
  const observed=ws.checkpoint_meta.protocol_committed_through_seq; assert.ok(observed>0)

  // A later investigative delta can update knowledge, but still cannot authorize pruning.
  addTurn(5); session.seq=seq
  ws=commitUniversalWorkingState(ws,{known:['K2']},{session,sourceRevision:0})
  assert.ok(ws.checkpoint_meta.protocol_committed_through_seq>observed)
  assert.equal(ws.checkpoint_meta.prune_safe_through_seq,null)

  // The rare compaction path audits a concrete old boundary and grants prune authority.
  const auditedBoundary=surface[1] // completed turn 1 assistant surface node
  ws=authorizeCompactionWorkingState(ws,{constraints:['README.md must not change']},{pruneSafeThroughSeq:auditedBoundary,sourceRevision:0,session,auditId:'AUDIT-1'})
  assert.equal(ws.checkpoint_meta.prune_safe_through_seq,auditedBoundary)
  atomicWriteJson(paths.workingState,ws)
  const ctx={tokenMeter:{measure(){return {totalTokens:surface.length*100,nodes:surface.map(s=>({seq:s,tokens:100}))}},estimateMessage(){return 80}}}
  const plan=planStructuredCompaction(ctx,{session},{paths},{dryRun:true})
  assert.equal(plan.ok,true); assert.equal(plan.coverage,auditedBoundary); assert.ok(plan.end<=auditedBoundary)

  // Future investigative updates preserve, rather than advance, the audited boundary.
  addTurn(6); session.seq=seq
  const later=commitUniversalWorkingState(ws,{evidence:['new exact log']},{session,sourceRevision:0})
  assert.equal(later.checkpoint_meta.prune_safe_through_seq,auditedBoundary)
}

// 6) Runtime suite case numbers and stable ids are unique.
{
  const text=fs.readFileSync(new URL('./RUNTIME_ADVERSARIAL_SUITE.md',import.meta.url),'utf8')
  const rows=[...text.matchAll(/^## CASE\s+(\d+)\s+\[([^\]]+)\]/gm)].map(m=>({n:Number(m[1]),id:m[2]}))
  assert.ok(rows.length>=40)
  assert.equal(new Set(rows.map(x=>x.n)).size,rows.length)
  assert.equal(new Set(rows.map(x=>x.id)).size,rows.length)
  for(let i=1;i<rows.length;i++) assert.equal(rows[i].n,rows[i-1].n+1)
}

console.log('hardening-v072.test.mjs: PASS')
