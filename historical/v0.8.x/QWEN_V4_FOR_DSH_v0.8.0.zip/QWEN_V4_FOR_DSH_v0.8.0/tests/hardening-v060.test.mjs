import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

import { apply } from '../dsh-bundle-v4-control/index.js'
import {
  DEFAULT_BUDGET, budgetExhausted, budgetExceededPreStep, budgetExceededAfterRun,
} from '../dsh-bundle-v4-control/lib/core.js'
import {
  roleBudgetExhausted, roleBudgetExceededPreStep, roleBudgetExceededAfterRun,
  workerReserveExhausted, workerReserveExceededPreStep,
} from '../dsh-bundle-v4-control/lib/role-control.js'
import { DEFAULT_ROLE_BUDGETS, DEFAULT_VALIDATION_RESERVE } from '../dsh-bundle-v4-control/lib/runtime-policy.js'
import { freshRoleContexts } from '../dsh-bundle-v4-control/lib/fresh-role.js'
import { ensureProject } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd, ...args) {
  const r = spawnSync('git', ['-C', cwd, ...args], { encoding: 'utf8' })
  if (r.status !== 0) throw new Error(r.stderr || r.stdout)
  return r.stdout
}
function repo(prefix='qv4-v060-') {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), prefix))
  git(root, 'init'); git(root, 'config', 'user.email', 't@x'); git(root, 'config', 'user.name', 'T')
  fs.writeFileSync(path.join(root, 'README.md'), 'x\n'); git(root, 'add', '-A'); git(root, 'commit', '-m', 'base')
  return root
}
function pkgRoot() { return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..') }
function usage(overrides={}) {
  return { model_requests:0, reasoning_tokens:0, visible_output_tokens:0, tool_calls:0, active_execution_ms:0, failed_hypotheses:0, ...overrides }
}

// 1) Exact-cap semantics are intentionally different for start, pre-step, and post-run.
{
  assert.equal(budgetExhausted(usage({ model_requests:30 }), DEFAULT_BUDGET), 'max_model_requests')
  assert.equal(budgetExceededPreStep(usage({ model_requests:30 }), DEFAULT_BUDGET), undefined)
  assert.equal(budgetExceededPreStep(usage({ model_requests:31 }), DEFAULT_BUDGET), 'max_model_requests')
  assert.equal(budgetExceededAfterRun(usage({ model_requests:30 }), DEFAULT_BUDGET), undefined)
  assert.equal(budgetExceededAfterRun(usage({ model_requests:31 }), DEFAULT_BUDGET), 'max_model_requests')

  assert.equal(budgetExceededAfterRun(usage({ reasoning_tokens:80000 }), DEFAULT_BUDGET), undefined)
  assert.equal(budgetExceededAfterRun(usage({ reasoning_tokens:80001 }), DEFAULT_BUDGET), 'max_reasoning_tokens')
  assert.equal(budgetExceededAfterRun(usage({ tool_calls:144 }), DEFAULT_BUDGET), undefined)
  assert.equal(budgetExceededAfterRun(usage({ tool_calls:145 }), DEFAULT_BUDGET), 'max_tool_calls')
}

// 2) Fresh-role exact cap: request N is admitted when step/start already counted N; completed N/N is valid.
{
  const b = DEFAULT_ROLE_BUDGETS.TASK_PLANNER
  assert.equal(roleBudgetExhausted(usage({ model_requests:b.max_model_requests }), b), 'max_model_requests')
  assert.equal(roleBudgetExceededPreStep(usage({ model_requests:b.max_model_requests }), b), undefined)
  assert.equal(roleBudgetExceededPreStep(usage({ model_requests:b.max_model_requests + 1 }), b), 'max_model_requests')
  assert.equal(roleBudgetExceededAfterRun(usage({ model_requests:b.max_model_requests }), b), undefined)
  assert.equal(roleBudgetExceededAfterRun(usage({ reasoning_tokens:b.max_reasoning_tokens }), b), undefined)
  assert.equal(roleBudgetExceededAfterRun(usage({ tool_calls:b.max_tool_calls }), b), undefined)
}

// 3) Validation reserve: worker request 22/22 is admitted in pre-step but a new epoch at 22 is exhausted.
{
  const threshold = DEFAULT_BUDGET.max_model_requests - DEFAULT_VALIDATION_RESERVE.max_model_requests
  assert.equal(threshold, 19)
  assert.equal(workerReserveExhausted(usage({ model_requests:threshold }), DEFAULT_BUDGET, DEFAULT_VALIDATION_RESERVE), 'validation_reserve_max_model_requests')
  assert.equal(workerReserveExceededPreStep(usage({ model_requests:threshold }), DEFAULT_BUDGET, DEFAULT_VALIDATION_RESERVE), undefined)
  assert.equal(workerReserveExceededPreStep(usage({ model_requests:threshold + 1 }), DEFAULT_BUDGET, DEFAULT_VALIDATION_RESERVE), 'validation_reserve_max_model_requests')
}

// 4) v0.8 role envelopes (+20% productive-tool headroom).
{
  const expected = {
    SOURCE_CURATOR: [6,16000,20], TASK_PLANNER: [6,20000,20], TEST_ANALYST: [4,12000,15],
    REVIEWER: [4,12000,15], ACCEPTANCE_AUDITOR: [3,8000,8], CONTEXT_COMPACTOR: [4,12000,8],
  }
  for (const [name,[requests,reasoning,tools]] of Object.entries(expected)) {
    const b = DEFAULT_ROLE_BUDGETS[name]
    assert.equal(b.max_model_requests, requests, name)
    assert.equal(b.max_reasoning_tokens, reasoning, name)
    assert.equal(b.max_tool_calls, tools, name)
  }
}

// 5) structured_output is a valid fresh-role terminal tool while mutation tools stay denied.
{
  const guards=[]
  const ctx={
    logger:{warn(){},error(){}}, agents:{get(){}}, on(){},
    tools:{guard(fn){guards.push(fn)},register(){}}, commands:{register(){}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(){throw new Error('not used')}},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'R',header:{cwd:process.cwd(),parentSession:'P'},events:[]},cancel(){}}
  const roleCtx={role:'SOURCE_CURATOR',budget:DEFAULT_ROLE_BUDGETS.SOURCE_CURATOR,read_bytes:0,tool_calls:0,violation:null,projectRoot:process.cwd(),allowedRoots:[process.cwd()]}
  freshRoleContexts.set(agent, roleCtx)
  assert.equal(guards[0]({name:'structured_output',arguments:{},agent}), undefined)
  assert.equal(roleCtx.tool_calls, 0)
  assert.match(guards[0]({name:'write',arguments:{},agent}), /ROLE_TOOL_DENIED/)
  freshRoleContexts.delete(agent)
}

// 6) Local-only bundle layer disables stock external routes and pins the fallback model locally.
{
  const patch=fs.readFileSync(path.join(pkgRoot(),'dsh-bundle-v4-control','cordis.patch.yml'),'utf8')
  assert.match(patch,/id:\s*agent-default-model[\s\S]*provider:\s*llama-local[\s\S]*model:\s*qwen3\.8-27b/)
  for (const id of ['session-title-llm','web-search-deepseek','llm-deepseek','session-telemetry-otel']) {
    assert.match(patch,new RegExp(`id:\\s*${id}[\\s\\S]{0,80}disabled:\\s*true`),id)
  }
}

// 7) Windows installer writes JSON with UTF-8 no BOM rather than PowerShell 5.1 Set-Content -Encoding UTF8.
{
  const installer=fs.readFileSync(path.join(pkgRoot(),'INSTALL_V0_8_WINDOWS.ps1'),'utf8')
  assert.match(installer,/System\.Text\.UTF8Encoding\(\$false\)/)
  assert.match(installer,/Write-Utf8NoBom \$PolicyDst \$PolicyJson/)
  assert.doesNotMatch(installer,/PolicyDst[^\n]*Set-Content[^\n]*Encoding UTF8/i)
  const policy=fs.readFileSync(path.join(pkgRoot(),'project-template','.dsh','project','RUNTIME_POLICY.json'))
  assert.notDeepEqual([...policy.subarray(0,3)],[0xEF,0xBB,0xBF])
}

// 8) A controlled-project internal pre-step/checkpoint failure rejects/cancels instead of silently entering the model.
{
  const root=repo('qv4-v060-failclosed-')
  const paths=ensureProject(root)
  fs.writeFileSync(paths.state, '{ broken json', 'utf8')
  const pre=[]; const guards=[]; let cancelled=0
  const ctx={
    logger:{warn(){},error(){}}, agents:{get(){}}, on(name,fn){if(name==='agent/pre-step')pre.push(fn)},
    tools:{guard(fn){guards.push(fn)},register(){}}, commands:{register(){},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}}, subagents:{async start(){throw new Error('n/a')}},
  }
  apply(ctx,{tokenizerEndpoint:''})
  const agent={session:{id:'S',header:{cwd:root},events:[]},cancel(){cancelled++}}
  const decision=await pre[1]({agent,messages:[],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  assert.equal(decision.kind,'reject')
  assert.ok(cancelled>0)
  assert.match(guards[0]({name:'skill',arguments:{},agent}),/HOST_GUARD_INTERNAL_ERROR:checkpoint-guard/)
}

// 9) Post-tool safety failures are routed into the fail-closed host guard path.
{
  const index=fs.readFileSync(path.join(pkgRoot(),'dsh-bundle-v4-control','index.js'),'utf8')
  assert.match(index,/failClosedTaskGuard\(ctx, runtime, agent, 'tool-result-post-check', error\)/)
  assert.match(index,/failClosedTaskGuard\(ctx, runtime, agent, 'turn-stop-check', error\)/)
  assert.match(index,/failClosedTaskGuard\(ctx, runtime, agent, 'checkpoint-cadence-event', error\)/)
}

console.log('hardening-v060.test.mjs: PASS')
