import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { _evacuationTest } from '../dsh-bundle-v4-control/lib/context-evacuation.js'
import { atomicWriteJson, ensureProject } from '../dsh-bundle-v4-control/lib/state.js'
import { DEFAULT_RUNTIME_POLICY, normalizeRuntimePolicy } from '../dsh-bundle-v4-control/lib/runtime-policy.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v080-adv-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');git(root,'config','core.autocrlf','false');git(root,'config','core.eol','lf');fs.writeFileSync(path.join(root,'README.md'),'x\n');git(root,'add','-A');git(root,'commit','-m','base');return root
}
function sessionFor(root){
  return {id:'S',seq:0,header:{cwd:root},events:[],surface:{nodes:[]},append(type,data,opts={}){
    const seq=++this.seq; const ev={seq,type,data,surfaceOp:opts.surfaceOp??'append',sourceEventSeqs:opts.sourceEventSeqs};this.events.push(ev)
    if(type==='user/message'||type==='assistant/message'||type==='tool/result'){
      if(opts.surfaceOp&&typeof opts.surfaceOp==='object'&&opts.surfaceOp.op==='replace'){
        const a=this.surface.nodes.indexOf(opts.surfaceOp.start),b=this.surface.nodes.indexOf(opts.surfaceOp.end);if(a<0||b<a)throw new Error('bad mock surface replace');this.surface.nodes.splice(a,b-a+1,seq)
      }else this.surface.nodes.push(seq)
    }
    return ev
  }}
}
function user(s,turn,text){s.append('user/message',{role:'user',content:[{type:'text',text}],source:{kind:'user'}},{surfaceOp:'append'});s.events.push({seq:++s.seq,type:'turn/start',data:{turn}})}
function assistant(s,turn,text){s.append('assistant/message',{turn,step:1,message:{role:'assistant',content:[{type:'text',text}]}},{surfaceOp:'append'});s.events.push({seq:++s.seq,type:'turn/end',data:{turn,reason:{kind:'completed'}}})}
function harness(root,onStart,{tokenPerNode=100}={}){
  const hooks=new Map(),tools=new Map(),commands=new Map()
  const ctx={
    logger:{warn(){},error(){}},
    tokenMeter:{measure(session){return {totalTokens:(session.surface.nodes.length)*tokenPerNode,surfaceTokens:(session.surface.nodes.length)*tokenPerNode,nodes:session.surface.nodes.map(seq=>({seq:Number(seq),tokens:tokenPerNode}))}},estimateMessage(m){return Math.max(1,Math.ceil(JSON.stringify(m).length/4))}},
    sessions:{async flush(){}},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},
    tools:{guard(){},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(_mode,opts){const structured=await onStart(opts);return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured}),async dispose(){}}}},
  }
  apply(ctx,{tokenizerEndpoint:'',roleProvider:'llama-local',roleModel:'qwen3.8-27b'});return {ctx,hooks,commands}
}
const safeAudit=(critical_items=[])=>({safe:true,summary:'covered',transfer:{known:[],constraints:[],decisions:[],evidence:[],failed_hypotheses:[],do_not_repeat:[],open_acceptance:[],next_action:[]},coverage:{user_constraints:'COVERED',assistant_findings:'NONE',tool_evidence:'NONE',open_work:'NONE'},critical_items,uncovered:[]})

// 1) Coverage reports cannot cite events outside the actual prune candidate or
// claim a TRANSFERRED item without a concrete non-empty target field.
{
  const candidate={seqs:[1,2,5]}
  let audit=safeAudit([{source_seq:99,kind:'USER_CONSTRAINT',disposition:'ALREADY_SURVIVES',target_field:'constraints',note:'lie'}])
  assert.equal(_evacuationTest.auditConsistency(audit,candidate).ok,false)
  audit=safeAudit([{source_seq:1,kind:'USER_CONSTRAINT',disposition:'TRANSFERRED',target_field:'constraints',note:'claims transfer'}])
  assert.equal(_evacuationTest.auditConsistency(audit,candidate).ok,false)
  audit.transfer.constraints=['README.md must not be modified']
  assert.equal(_evacuationTest.auditConsistency(audit,candidate).ok,true)
}

// 2) Existing canonical ACTIVE_REQUIREMENTS are explicitly in the compactor
// basis. A user constraint may therefore be ALREADY_SURVIVES without being
// redundantly copied into WORKING_STATE.
{
  const root=repo('qv4-v080-adv-canon-');const paths=ensureProject(root);atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  atomicWriteJson(paths.requirements,{schema_version:3,requirements:[{id:'REQ-README',text:'README.md must not be modified',status:'active'}]})
  const s=sessionFor(root);for(let t=1;t<=5;t++){user(s,t,t===1?'README.md must not be modified':`u${t}`);assistant(s,t,`a${t}`)}
  let sawCanonical=false
  const {commands}=harness(root,async opts=>{const prompt=opts.prompt?.[0]?.text??'';sawCanonical=prompt.includes('README.md must not be modified')&&prompt.includes('CURRENT SURVIVING CANONICAL PROJECT STATE');return safeAudit([{source_seq:1,kind:'USER_CONSTRAINT',disposition:'ALREADY_SURVIVES',target_field:'ACTIVE_REQUIREMENTS.REQ-README',note:'canonical requirement'}])})
  const agent={id:'A',session:s,cancel(){},steer(){}};const r=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal})
  assert.equal(r.kind,'success',r.text);assert.equal(sawCanonical,true)
  const ws=JSON.parse(fs.readFileSync(paths.workingState,'utf8'));assert.equal(ws.constraints.includes('README.md must not be modified'),false,'canonical fact need not be duplicated in working state')
}

// 3) TOCTOU: changing canonical requirements while the fresh compactor is
// running invalidates the audit before prune/WORKING_STATE authorization.
{
  const root=repo('qv4-v080-adv-toctou-');const paths=ensureProject(root);atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  atomicWriteJson(paths.requirements,{schema_version:3,requirements:[]})
  const s=sessionFor(root);for(let t=1;t<=5;t++){user(s,t,`u${t}`);assistant(s,t,`a${t}`)}
  const before=[...s.surface.nodes];const workingBefore=fs.readFileSync(paths.workingState,'utf8')
  const {commands}=harness(root,async()=>{atomicWriteJson(paths.requirements,{schema_version:3,requirements:[{id:'REQ-RACE',text:'new concurrent authority'}]});return safeAudit()})
  const agent={id:'A',session:s,cancel(){},steer(){}};const r=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal})
  assert.equal(r.kind,'error');assert.match(r.text,/COMPACTION_STALE_CANONICAL_STATE/);assert.deepEqual(s.surface.nodes,before);assert.equal(fs.readFileSync(paths.workingState,'utf8'),workingBefore)
}

// 4) Old v0.7 finalizer knobs are migration input only and disappear from the
// normalized v0.8 runtime policy.
{
  const p=normalizeRuntimePolicy({universal_commit:{checkpoint_recovery_attempts:1,response_basis_max_chars:8000,finalization_max_tokens:4096,finalization_reasoning_effort:'off'}})
  assert.equal(p.universal_commit,undefined)
}

// 5) Windows shipped-default migration uses explicit objects, not nested arrays.
{
  const installer=fs.readFileSync(new URL('../INSTALL_V0_8_WINDOWS.ps1',import.meta.url),'utf8')
  assert.match(installer,/\[pscustomobject\]@\{ ObjectPath='roles\.SOURCE_CURATOR'/)
  assert.doesNotMatch(installer,/@\('roles\.SOURCE_CURATOR',\s*'max_tool_calls'/)
  assert.match(installer,/Remove-LegacyUniversalCommit \$Policy/)
}


// 6) Chunked compaction is repeatable: a prior structured-compaction marker is
// coalesced with the next audited raw prefix rather than blocking all future
// /compress passes.
{
  const root=repo('qv4-v080-adv-chunks-');const paths=ensureProject(root)
  const policy=structuredClone(DEFAULT_RUNTIME_POLICY);policy.roles.CONTEXT_COMPACTOR={...policy.roles.CONTEXT_COMPACTOR,max_input_chars:30000};atomicWriteJson(paths.runtimePolicy,policy)
  const s=sessionFor(root);for(let t=1;t<=7;t++){user(s,t,`u${t}:`+'u'.repeat(6000));assistant(s,t,`a${t}:`+'a'.repeat(6000))}
  const {commands}=harness(root,async()=>safeAudit())
  const agent={id:'A',session:s,cancel(){},steer(){}};const before=s.surface.nodes.length
  const r1=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal});assert.equal(r1.kind,'success',r1.text);const after1=s.surface.nodes.length;assert.ok(after1<before)
  const r2=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal});assert.equal(r2.kind,'success',r2.text);assert.ok(s.surface.nodes.length<after1,'second audited chunk should compact beyond the existing marker')
}


// 7) HARD pressure can consume multiple bounded audited chunks in one admission
// attempt, with a hard cap of three. This specifically exercises compaction after
// an existing replacement marker; that marker must not block the next candidate.
{
  const root=repo('qv4-v080-adv-hard3-');const paths=ensureProject(root)
  const policy=structuredClone(DEFAULT_RUNTIME_POLICY)
  policy.roles.CONTEXT_COMPACTOR={...policy.roles.CONTEXT_COMPACTOR,max_input_chars:30000}
  policy.context_pressure={...policy.context_pressure,context_window:15500,completion_reserve_tokens:1000,compression_recovery_reserve_tokens:1000,safety_margin_tokens:1000,soft_headroom_tokens:5000,hard_headroom_tokens:2600,hysteresis_tokens:500,min_recent_turns:3,max_recent_tokens:10000}
  atomicWriteJson(paths.runtimePolicy,policy)
  const s=sessionFor(root);for(let t=1;t<=6;t++){user(s,t,`u${t}:`+'u'.repeat(6000));assistant(s,t,`a${t}:`+'a'.repeat(6000))}
  let starts=0
  const {hooks}=harness(root,async()=>{starts++;return safeAudit()}, {tokenPerNode:1000})
  let cancelled=0;const agent={id:'A',session:s,cancel(){cancelled++},steer(){}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  const d=await pre({agent,messages:[{source:{kind:'user'},content:[{type:'text',text:'continue'}]}],turn:7,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[]}))
  assert.equal(d.kind,'enter');assert.equal(cancelled,0);assert.ok(starts>=2&&starts<=3,`expected 2..3 bounded compactor passes, got ${starts}`);const universal=fs.readFileSync(new URL('../dsh-bundle-v4-control/lib/universal-commit.js',import.meta.url),'utf8');assert.match(universal,/pass <= 3/)
}

console.log('adversarial-v080.test.mjs: PASS')
