import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { planLosslessHygiene } from '../dsh-bundle-v4-control/lib/context-hygiene.js'
import { accountAssistantEvent } from '../dsh-bundle-v4-control/lib/token-accounting.js'
import { measureAgentUsage, roleBudgetExceededPreStep, workerReserveExceededPreStep } from '../dsh-bundle-v4-control/lib/role-control.js'
import { freshRoleContexts } from '../dsh-bundle-v4-control/lib/fresh-role.js'
import { DEFAULT_RUNTIME_POLICY } from '../dsh-bundle-v4-control/lib/runtime-policy.js'
import { atomicWriteJson, ensureProject } from '../dsh-bundle-v4-control/lib/state.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(prefix='qv4-v080-'){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),prefix));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');git(root,'config','core.autocrlf','false');git(root,'config','core.eol','lf');fs.writeFileSync(path.join(root,'README.md'),'x\n');git(root,'add','-A');git(root,'commit','-m','base');return root
}
function harness(root,{subagentStructured=null}={}){
  const hooks=new Map(),guards=[],tools=new Map(),commands=new Map()
  const ctx={
    logger:{warn(){},error(){}},
    tokenMeter:{
      measure(session){return {totalTokens:(session.surface?.nodes?.length??0)*100,surfaceTokens:(session.surface?.nodes?.length??0)*100,nodes:Array.from(session.surface?.nodes??[]).map(x=>({seq:Number(typeof x==='number'?x:x.seq),tokens:100}))}},
      estimateMessage(msg){return Math.max(1,Math.ceil(JSON.stringify(msg).length/4))},
    },
    sessions:{async flush(){}},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},
    tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},
    commands:{register(d){commands.set(d.name,d)},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},
    subagents:{async start(){
      if(!subagentStructured)throw new Error('unexpected subagent')
      return {localAgent:undefined,result:Promise.resolve({stopReason:'completed',structured:subagentStructured}),async dispose(){}}
    }},
  }
  apply(ctx,{tokenizerEndpoint:'',roleProvider:'llama-local',roleModel:'qwen3.8-27b'})
  return {ctx,hooks,guards,tools,commands}
}
function sessionFor(root){
  return {id:'S',seq:0,header:{cwd:root},events:[],surface:{nodes:[]},append(type,data,opts={}){
    const seq=++this.seq
    const ev={seq,type,data,surfaceOp:opts.surfaceOp??'append',sourceEventSeqs:opts.sourceEventSeqs}
    this.events.push(ev)
    if(type==='user/message'||type==='assistant/message'||type==='tool/result'){
      if(opts.surfaceOp&&typeof opts.surfaceOp==='object'&&opts.surfaceOp.op==='replace'){
        const a=this.surface.nodes.indexOf(opts.surfaceOp.start), b=this.surface.nodes.indexOf(opts.surfaceOp.end)
        if(a<0||b<a)throw new Error('bad mock surface replace')
        this.surface.nodes.splice(a,b-a+1,seq)
      } else this.surface.nodes.push(seq)
    }
    return ev
  }}
}
function user(session,turn,text){session.append('user/message',{id:`u${turn}`,role:'user',content:[{type:'text',text}],source:{kind:'user'}},{surfaceOp:'append'});session.events.push({seq:++session.seq,type:'turn/start',data:{turn}})}
function assistant(session,turn,step,text){session.append('assistant/message',{turn,step,message:{id:`a${turn}-${step}`,role:'assistant',content:[{type:'text',text}],source:{provider:'llama-local',model:'qwen3.8-27b'}}},{surfaceOp:'append'});session.events.push({seq:++session.seq,type:'turn/end',data:{turn,reason:{kind:'completed'}}})}

// 1) Ordinary top-level turn gets a short optional work-mode rule, but no mandatory
// checkpoint barrier/finalizer. Ending without state_checkpoint is valid.
{
  const root=repo('qv4-v080-ordinary-'); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const {hooks,tools}=harness(root); const session=sessionFor(root); const agent={id:'A',session,cancel(){},steer(){throw new Error('ordinary turn must not be steered into checkpoint/finalizer')}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  const d=await pre({agent,messages:[{source:{kind:'user'},content:[{type:'text',text:'напиши серию'}]}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  const injected=d.messages.map(x=>x.content?.[0]?.text??'').join('\n')
  assert.match(injected,/state_checkpoint is OPTIONAL/)
  assert.doesNotMatch(injected,/FINALIZATION PASS|COMMIT-BEFORE-ANSWER|CHECKPOINT BARRIER/)
  assert.equal((hooks.get('agent/turn-stopping')??[]).length,1,'only task checkpoint cadence hook should remain; no universal turn-stopping barrier')
  assert.ok(tools.has('state_checkpoint'))
  const ws=JSON.parse(fs.readFileSync(paths.workingState,'utf8'));assert.deepEqual(ws.known,[]);assert.deepEqual(ws.evidence,[])
}

// 2) Material investigative delta can coexist with visible assistant text and the
// same state_checkpoint result terminates the turn: no follow-up finalizer request.
{
  const root=repo('qv4-v080-sidecar-'); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const {hooks,tools}=harness(root); const session=sessionFor(root); const agent={id:'A',session,cancel(){},steer(){}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  await pre({agent,messages:[{source:{kind:'user'},content:[{type:'text',text:'проверь почему падает'}]}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  session.append('assistant/message',{turn:1,step:1,message:{role:'assistant',content:[{type:'text',text:'Причина найдена.'},{type:'tool-call',name:'state_checkpoint',arguments:'{}'}]}},{surfaceOp:'append'})
  let concluded=0
  const r=await tools.get('state_checkpoint').execute({
    evidence:['exact log: "unauthorized: Invalid API Key"','fingerprint: /tokenize fails while generation succeeds'],
    decisions:['authenticate local tokenizer helper requests'],
    failed_hypotheses:['external DeepSeek egress'],
    next_action:['rerun live /triage'],
  },{agent,concludeTurn(){concluded++}})
  assert.equal(r.ok,true);assert.equal(r.concludes_turn,true);assert.equal(concluded,1);assert.equal(r.prune_safe_through_seq,null)
  const ws=JSON.parse(fs.readFileSync(paths.workingState,'utf8'))
  assert.ok(ws.evidence.some(x=>x.includes('unauthorized: Invalid API Key')));assert.deepEqual(ws.failed_hypotheses,['external DeepSeek egress']);assert.equal(ws.checkpoint_meta.prune_safe_through_seq,null)
}

// 3) Level-A hygiene is deterministic and only collapses exact contiguous tool exchanges.
{
  const root=repo('qv4-v080-hygiene-'); const s=sessionFor(root)
  for(let step=1;step<=2;step++){
    s.append('assistant/message',{turn:1,step,message:{content:[{type:'tool-call',name:'read',arguments:'{"file_path":"x"}'}]}},{surfaceOp:'append'})
    s.append('tool/result',{turn:1,step,message:{callId:`c${step}`,content:[{type:'text',text:'ENOENT'}],isError:true}},{surfaceOp:'append'})
  }
  const plan=planLosslessHygiene(s);assert.equal(plan.ok,true);assert.equal(plan.count,2);assert.deepEqual(plan.sourceEventSeqs,s.surface.nodes)
  // Different target is not equivalent.
  const s2=sessionFor(root)
  for(const [step,file] of [[1,'x'],[2,'y']]){s2.append('assistant/message',{turn:1,step,message:{content:[{type:'tool-call',name:'read',arguments:JSON.stringify({file_path:file})}]}},{surfaceOp:'append'});s2.append('tool/result',{turn:1,step,message:{callId:`c${step}`,content:[{type:'text',text:'ENOENT'}],isError:true}},{surfaceOp:'append'})}
  assert.equal(planLosslessHygiene(s2).ok,false)
}

// 4) /tokenize uses the local API key and role accounting does not re-tokenize immutable steps.
{
  const oldFetch=globalThis.fetch, oldKey=process.env.LLAMA_LOCAL_API_KEY; let calls=0
  process.env.LLAMA_LOCAL_API_KEY='local'
  globalThis.fetch=async(_url,opts)=>{calls++;assert.equal(opts.headers.authorization,'Bearer local');return {ok:true,async json(){return {tokens:[1,2,3]}}}}
  try{
    const ev={data:{message:{content:[{type:'reasoning',text:'unique-r-080'},{type:'text',text:'unique-v-080'}]},usage:{outputTokens:6}}}
    const a=await accountAssistantEvent(ev,{tokenizerEndpoint:'http://127.0.0.1:8080/tokenize'});assert.equal(a.mode,'llama-tokenize-message-blocks');assert.equal(calls,2)
    const agent={id:'R',session:{id:'RS',events:[{seq:1,type:'step/start',data:{turn:1,step:1}},{seq:2,type:'assistant/message',data:{turn:1,step:1,message:{content:[{type:'reasoning',text:'role-r-080'},{type:'text',text:'role-v-080'}]},usage:{outputTokens:6}}},{seq:3,type:'step/end',data:{turn:1,step:1}}]}}
    await measureAgentUsage(agent,'http://127.0.0.1:8080/tokenize');const after1=calls;await measureAgentUsage(agent,'http://127.0.0.1:8080/tokenize');assert.equal(calls,after1)
  }finally{globalThis.fetch=oldFetch;if(oldKey===undefined)delete process.env.LLAMA_LOCAL_API_KEY;else process.env.LLAMA_LOCAL_API_KEY=oldKey}
}

// 5) +20% productive tool headroom: exact role cap does not block the terminal model
// step/structured_output; N+1 productive tool is denied by the hard host guard.
{
  const root=repo('qv4-v080-role-'); const {guards}=harness(root); const agent={id:'R',session:{id:'RS',header:{cwd:root},events:[]}}
  const budget=DEFAULT_RUNTIME_POLICY.roles.SOURCE_CURATOR;assert.equal(budget.max_tool_calls,20)
  assert.equal(roleBudgetExceededPreStep({model_requests:1,reasoning_tokens:0,visible_output_tokens:0,tool_calls:20,active_execution_ms:0},budget),undefined)
  const roleCtx={role:'SOURCE_CURATOR',budget,read_bytes:0,tool_calls:19,guard_seen:false,violation:null,projectRoot:root,allowedRoots:[root]};freshRoleContexts.set(agent,roleCtx)
  const guard=guards.find(g=>{try{return g({name:'structured_output',arguments:{},agent})===undefined}catch{return false}}) ?? guards[0]
  assert.equal(guard({name:'read',arguments:{file_path:path.join(root,'README.md')},agent}),undefined);assert.equal(roleCtx.tool_calls,20)
  assert.equal(guard({name:'structured_output',arguments:{},agent}),undefined);assert.equal(roleCtx.tool_calls,20)
  assert.match(guard({name:'read',arguments:{file_path:path.join(root,'README.md')},agent}),/ROLE_TOOL_BUDGET_EXCEEDED/)
  freshRoleContexts.delete(agent)
}

// 6) NO_TASK mutation denial is explicit and cross-tool retries in the same turn are blocked.
{
  const root=repo('qv4-v080-mut-'); const {hooks,guards}=harness(root); const session=sessionFor(root); const agent={id:'A',session,cancel(){},steer(){}}
  // Initialize per-turn host state.
  const normalPre=(hooks.get('agent/pre-step')??[])[1];await normalPre({agent,messages:[],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  const run=(exec)=>{for(const g of guards){const r=g(exec);if(r!==undefined)return r}return undefined}
  const first=run({name:'write',arguments:{file_path:path.join(root,'x.txt')},agent});assert.match(first,/MUTATION_AUTHORITY_DENIED/)
  const second=run({name:'pwsh',arguments:{workdir:root,command:'Set-Content x.txt hi'},agent});assert.match(second,/MUTATION_POLICY_ALREADY_DENIED_THIS_TURN/)
}

// 7) Rare semantic evacuation transfers a conversation-only constraint before prune.
{
  const root=repo('qv4-v080-compact-'); const paths=ensureProject(root);atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const audit={safe:true,summary:'all live semantics survive',transfer:{known:[],constraints:['README.md must not be modified'],decisions:[],evidence:[],failed_hypotheses:[],do_not_repeat:[],open_acceptance:[],next_action:[]},coverage:{user_constraints:'COVERED',assistant_findings:'NONE',tool_evidence:'NONE',open_work:'NONE'},critical_items:[{source_seq:1,kind:'USER_CONSTRAINT',disposition:'TRANSFERRED',target_field:'constraints',note:'preserve exact user restriction'}],uncovered:[]}
  const {commands}=harness(root,{subagentStructured:audit});const session=sessionFor(root)
  for(let turn=1;turn<=5;turn++){user(session,turn,turn===1?'README.md must not be modified':`u${turn}`);assistant(session,turn,1,`a${turn}`)}
  const beforeSurface=[...session.surface.nodes];const agent={id:'A',session,cancel(){},steer(){}}
  const r=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal});assert.equal(r.kind,'success',r.text)
  const ws=JSON.parse(fs.readFileSync(paths.workingState,'utf8'));assert.ok(ws.constraints.includes('README.md must not be modified'));assert.ok(Number.isInteger(ws.checkpoint_meta.prune_safe_through_seq));assert.ok(session.surface.nodes.length<beforeSurface.length)
}

// 8) Uncertain coverage fails closed and leaves the active surface/state untouched.
{
  const root=repo('qv4-v080-refuse-'); const paths=ensureProject(root);atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const audit={safe:false,summary:'old user constraint uncertain',transfer:{known:[],constraints:[],decisions:[],evidence:[],failed_hypotheses:[],do_not_repeat:[],open_acceptance:[],next_action:[]},coverage:{user_constraints:'UNCERTAIN',assistant_findings:'NONE',tool_evidence:'NONE',open_work:'NONE'},critical_items:[],uncovered:[{source_seq:1,reason:'constraint has no surviving representation'}]}
  const {commands}=harness(root,{subagentStructured:audit});const session=sessionFor(root)
  for(let turn=1;turn<=5;turn++){user(session,turn,`u${turn}`);assistant(session,turn,1,`a${turn}`)}
  const before=[...session.surface.nodes],stateBefore=fs.readFileSync(paths.workingState,'utf8');const agent={id:'A',session,cancel(){},steer(){}}
  const r=await commands.get('compress').handler({agent,rawInput:'',signal:new AbortController().signal});assert.equal(r.kind,'error');assert.match(r.text,/REFUSED/);assert.deepEqual(session.surface.nodes,before);assert.equal(fs.readFileSync(paths.workingState,'utf8'),stateBefore)
}


// 9) Worker exact productive-tool threshold still admits a terminal model step;
// N+1 is the point at which protected validation reserve is crossed.
{
  const budget={max_model_requests:30,max_reasoning_tokens:80000,max_visible_output_tokens:40000,max_tool_calls:144,max_active_execution_minutes:90}
  const reserve={max_model_requests:11,max_reasoning_tokens:32000,max_visible_output_tokens:13000,max_tool_calls:38,max_active_execution_minutes:25}
  const usage={model_requests:1,reasoning_tokens:0,visible_output_tokens:0,tool_calls:106,active_execution_ms:0}
  assert.equal(workerReserveExceededPreStep(usage,budget,reserve),undefined)
  assert.equal(workerReserveExceededPreStep({...usage,tool_calls:107},budget,reserve),'validation_reserve_max_tool_calls')
}

// 10) HARD pressure performs one rare semantic evacuation attempt automatically.
{
  const root=repo('qv4-v080-auto-compress-'); const paths=ensureProject(root)
  const policy=structuredClone(DEFAULT_RUNTIME_POLICY)
  policy.context_pressure={...policy.context_pressure,context_window:2600,completion_reserve_tokens:300,compression_recovery_reserve_tokens:200,safety_margin_tokens:100,soft_headroom_tokens:900,hard_headroom_tokens:300,hysteresis_tokens:100,min_recent_turns:3,max_recent_tokens:800}
  atomicWriteJson(paths.runtimePolicy,policy)
  const audit={safe:true,summary:'candidate fully covered or transferred',transfer:{known:[],constraints:[],decisions:[],evidence:[],failed_hypotheses:[],do_not_repeat:[],open_acceptance:[],next_action:[]},coverage:{user_constraints:'NONE',assistant_findings:'NONE',tool_evidence:'NONE',open_work:'NONE'},critical_items:[],uncovered:[]}
  const {hooks}=harness(root,{subagentStructured:audit}); const session=sessionFor(root)
  for(let turn=1;turn<=9;turn++){user(session,turn,`old u${turn}`);assistant(session,turn,1,`old a${turn}`)}
  const before=session.surface.nodes.length; let cancelled=0
  const agent={id:'A',session,cancel(){cancelled++},steer(){}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  const d=await pre({agent,messages:[{source:{kind:'user'},content:[{type:'text',text:'continue investigation'}]}],turn:10,step:1,signal:new AbortController().signal},async()=>({kind:'enter',messages:[]}))
  assert.equal(d.kind,'enter');assert.equal(cancelled,0);assert.ok(session.surface.nodes.length<before,'automatic HARD-pressure evacuation should compact old surface before MAIN runs')
  const ws=JSON.parse(fs.readFileSync(paths.workingState,'utf8'));assert.ok(Number.isInteger(ws.checkpoint_meta.prune_safe_through_seq))
}

console.log('hardening-v080.test.mjs: PASS')
