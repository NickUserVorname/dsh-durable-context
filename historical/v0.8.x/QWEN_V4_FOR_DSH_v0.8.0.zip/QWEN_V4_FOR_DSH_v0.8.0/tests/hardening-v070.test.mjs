import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

import { apply } from '../dsh-bundle-v4-control/index.js'
import { authorizeCompactionWorkingState, commitUniversalWorkingState, validateUniversalCheckpoint } from '../dsh-bundle-v4-control/lib/context-memory.js'
import { planStructuredCompaction } from '../dsh-bundle-v4-control/lib/context-pressure.js'
import { ensureProject, atomicWriteJson } from '../dsh-bundle-v4-control/lib/state.js'
import { DEFAULT_RUNTIME_POLICY } from '../dsh-bundle-v4-control/lib/runtime-policy.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
function repo(){const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-v070-'));git(root,'init');git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.writeFileSync(path.join(root,'README.md'),'x\n');git(root,'add','-A');git(root,'commit','-m','base');return root}
function pkgRoot(){return path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')}

// 1) v0.8 checkpoint semantics: no-change is represented by omitting the optional tool.
assert.match(validateUniversalCheckpoint({no_change:true}).reason,/NO_CHANGE_DEPRECATED/)
assert.equal(validateUniversalCheckpoint({known:['x']}).ok,true)
assert.equal(validateUniversalCheckpoint({constraints:['README.md must not change']}).ok,true)
assert.match(validateUniversalCheckpoint({}).reason,/EMPTY/)

// 2) Ordinary top-level turns receive only a short optional work-mode instruction:
//    no commit-before-answer barrier and no finalizer request/hook.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const hooks=new Map(),tools=new Map(),commands=new Map(),guards=[]
  const ctx={logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:1000,nodes:[]}},estimateMessage(){return 100}},sessions:{},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(f){guards.push(f)},register(d){tools.set(d.name,d)}},commands:{register(d){commands.set(d.name,d)},async execute(){return null}},
    goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}},}
  apply(ctx,{tokenizerEndpoint:''})
  const session={id:'S',seq:1,header:{cwd:root},surface:{nodes:[1]},events:[{seq:1,type:'user/message',data:{message:{role:'user'}}}]}
  const agent={id:'A',session,cancel(){},steer(){throw new Error('ordinary turn must not be steered')}}
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  const entered=await pre({agent,messages:[{role:'user',source:{kind:'user'},content:[{type:'text',text:'hello'}]}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  const injected=entered.messages.map(m=>m.content?.[0]?.text??'').join('\n')
  assert.match(injected,/state_checkpoint is OPTIONAL/)
  assert.doesNotMatch(injected,/COMMIT-BEFORE-ANSWER|FINALIZATION PASS/)
  assert.ok(tools.has('state_checkpoint')); assert.ok(commands.has('context')); assert.ok(commands.has('compress'))
  assert.equal((hooks.get('agent/turn-stopping')??[]).length,1,'only task-workflow cadence stop hook remains')
}

// 3) Material state written during the same assistant response can conclude the
//    turn directly; visible text before the tool is valid and prune-safe stays host-owned.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const hooks=new Map(),tools=new Map(); const ctx={logger:{warn(){},error(){}},tokenMeter:{measure(){return {totalTokens:100,nodes:[]}},estimateMessage(){return 1}},sessions:{},agents:{get(){}},
    on(n,f){if(!hooks.has(n))hooks.set(n,[]);hooks.get(n).push(f)},tools:{guard(){},register(d){tools.set(d.name,d)}},commands:{register(){},async execute(){return null}},goals:{get(){return null},block(){},complete(){},clear(){},create(){return null}},subagents:{async start(){throw new Error('n/a')}}}
  apply(ctx,{tokenizerEndpoint:''})
  const session={id:'S',seq:1,header:{cwd:root},surface:{nodes:[1]},events:[{seq:1,type:'user/message',data:{message:{role:'user'}}}]}
  const agent={id:'A',session,cancel(){},steer(){}}; let concluded=0
  const pre=(hooks.get('agent/pre-step')??[]).at(-1)
  await pre({agent,messages:[{source:{kind:'user'},content:[{type:'text',text:'проверь проблему'}]}],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
  session.events.push({seq:2,type:'assistant/message',data:{turn:1,step:1,message:{content:[{type:'text',text:'Причина найдена.'},{type:'tool-call',name:'state_checkpoint'}]}}}); session.surface.nodes.push(2); session.seq=2
  const r=await tools.get('state_checkpoint').execute({evidence:['exact log line'],failed_hypotheses:['A']},{agent,concludeTurn(){concluded++}})
  assert.equal(r.ok,true); assert.equal(concluded,1); assert.equal(r.prune_safe_through_seq,null)
}

// 4) Incremental state alone cannot make old history compactable; an explicit
//    compaction audit authorization must establish the prune-safe boundary.
{
  const root=repo(); const paths=ensureProject(root); atomicWriteJson(paths.runtimePolicy,DEFAULT_RUNTIME_POLICY)
  const events=[]; const surface=[]; let seq=0
  for(let turn=1;turn<=4;turn++){events.push({seq:++seq,type:'user/message',data:{message:{role:'user'}}});surface.push(seq);events.push({seq:++seq,type:'turn/start',data:{turn}});events.push({seq:++seq,type:'assistant/message',data:{turn,message:{content:[{type:'text',text:`a${turn}`}]}}});surface.push(seq);events.push({seq:++seq,type:'turn/end',data:{turn,reason:{kind:'completed'}}})}
  const session={id:'S',seq,header:{cwd:root},events,surface:{nodes:surface}}
  let working=commitUniversalWorkingState(JSON.parse(fs.readFileSync(paths.workingState,'utf8')),{known:['K']},{session,sourceRevision:0})
  atomicWriteJson(paths.workingState,working)
  const ctx={tokenMeter:{measure(){return {totalTokens:800,nodes:surface.map(s=>({seq:s,tokens:100}))}},estimateMessage(){return 80}}}
  assert.equal(planStructuredCompaction(ctx,{session},{paths},{dryRun:true}).ok,false)
  working=authorizeCompactionWorkingState(working,{}, {pruneSafeThroughSeq:surface[1],sourceRevision:0,session,auditId:'A1'})
  atomicWriteJson(paths.workingState,working)
  const plan=planStructuredCompaction(ctx,{session},{paths},{dryRun:true}); assert.equal(plan.ok,true); assert.ok(plan.end<=surface[1])
}

// 5) v0.8 package policy keeps stock free-form compaction disabled and exposes
//    investigative state instead of the obsolete universal finalizer policy.
{
  const preset=fs.readFileSync(path.join(pkgRoot(),'dsh-preset-qwen-v4','agent.cordis.yml'),'utf8')
  assert.doesNotMatch(preset,/@deepseek-ai\/dsh-compaction-basic/); assert.doesNotMatch(preset,/@deepseek-ai\/dsh-command-compact/)
  const policy=JSON.parse(fs.readFileSync(path.join(pkgRoot(),'project-template','.dsh','project','RUNTIME_POLICY.json'),'utf8'))
  assert.equal(policy.schema_version,'qwen-v4-runtime-policy-0.8.0'); assert.equal(policy.context_pressure.context_window,131072); assert.ok(policy.investigative_state); assert.equal(policy.universal_commit,undefined)
}

console.log('hardening-v070.test.mjs: PASS')
