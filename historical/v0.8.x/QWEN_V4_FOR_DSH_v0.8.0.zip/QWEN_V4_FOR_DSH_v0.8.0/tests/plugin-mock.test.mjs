import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { apply } from '../dsh-bundle-v4-control/index.js'

function git(cwd,...args){const r=spawnSync('git',['-C',cwd,...args],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout}
const root=fs.mkdtempSync(path.join(os.tmpdir(),'qv4-plug-')); git(root,'init'); git(root,'config','user.email','t@x');git(root,'config','user.name','T');fs.writeFileSync(path.join(root,'a.txt'),'a\n');git(root,'add','.');git(root,'commit','-m','base')
const hooks=new Map(), guards=[], commands=new Map(), tools=new Map(); let subagentStarts=0
const goalByAgent=new WeakMap()
const ctx={
 logger:{warn(){}},
 on(name,fn){if(!hooks.has(name))hooks.set(name,[]);hooks.get(name).push(fn)},
 tools:{guard(fn){guards.push(fn)},register(def){tools.set(def.name,def)}},
 commands:{register(def){commands.set(def.name,def)}},
 goals:{
  get(a){return goalByAgent.get(a)},
  create(a,o){const g={id:'g1',revision:1,phase:'active',activation:'armed',roundsStarted:0,maxGoalRounds:o.maxGoalRounds,objective:o.objective};goalByAgent.set(a,g);return g},
  complete(a){const g=goalByAgent.get(a); if(g)g.phase='complete'}, block(a,_r,b){const g=goalByAgent.get(a); if(g){g.phase='blocked';g.blocker=b}}, clear(a){goalByAgent.delete(a)}
 },
 subagents:{async start(){subagentStarts++; throw new Error('not expected')}}
}
apply(ctx,{maxGoalRounds:6,maxStepsPerTurn:12,maxToolCallsPerTurn:32})
assert.equal(tools.has('goal'),false)
assert.equal(tools.has('task_checkpoint'),true)
assert.equal(commands.has('status'),true)
const agent={id:'a1',session:{id:'s1',header:{cwd:root},events:[]},cancel(){}}
await hooks.get('agent/pre-step')[1]({agent,messages:[],turn:1,step:1},async()=>({kind:'enter',messages:[]}))
const exec={name:'skill',arguments:{name:'x'},agent}
assert.equal(guards[0](exec),undefined)
await hooks.get('tools/result')[0](exec,{isError:true,error:{message:'boom',info:{code:'X'}}})
assert.match(guards[0](exec),/exact failed tool replay denied/)
// Protocol checkpoint recovery gets exactly one identical replay before the
// generic anti-runaway fingerprint rule takes over.
const cp={name:'state_checkpoint',arguments:{known:['x']},agent}
assert.equal(guards[0](cp),undefined)
await hooks.get('tools/result')[0](cp,{isError:true,error:{message:'STATE_CHECKPOINT_PROTOCOL_SHAPE'}})
assert.equal(guards[0](cp),undefined,'first exact state_checkpoint replay should be allowed')
await hooks.get('tools/result')[0](cp,{isError:true,error:{message:'STATE_CHECKPOINT_PROTOCOL_SHAPE'}})
assert.match(guards[0](cp),/exact failed tool replay denied/)
const st=await commands.get('status').handler({agent,rawInput:'',signal:new AbortController().signal})
assert.equal(st.kind,'success'); assert.equal(subagentStarts,0); assert.match(st.text,/source_revision: 0/)
console.log('plugin-mock.test.mjs: PASS')
