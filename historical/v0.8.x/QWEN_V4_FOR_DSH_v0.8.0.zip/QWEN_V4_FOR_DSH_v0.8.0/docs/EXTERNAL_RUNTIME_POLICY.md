# External runtime policy — v0.8.0

The canonical template is `project-template/.dsh/project/RUNTIME_POLICY.json`. The Windows installer copies/migrates it into the controlled project and then applies optional `-PolicyFile` and `-Set dotted.path=value` overrides.

```powershell
.\INSTALL_V0_8_WINDOWS.ps1 `
  -ProjectRoot C:\repo `
  -DshHome C:\DSH-QWEN\dsh-home `
  -ExistingProjectPolicy MergeMissing
```

v0.8 shipped tool caps are task 144, SOURCE_CURATOR/TASK_PLANNER 20, TEST_ANALYST/REVIEWER 15, ACCEPTANCE_AUDITOR 8, CONTEXT_COMPACTOR 8. The serialized full validation reserve is derived from TEST+REVIEW+ACCEPT; runtime protects only the mandatory validation stages still remaining.

When migrating a v0.7 policy, the installer upgrades only values equal to the exact prior shipped tool defaults (120/16/16/12/12/6). User-customized values are preserved. Missing v0.8 fields are added from the template. After overlays, validation reserve is recomputed and the budget/context envelopes are validated.

`investigative_state.snapshot_max_chars` limits the injected durable working-state snapshot. `context_pressure` controls completion reserve, compression-recovery reserve, safety margin, SOFT/HARD headroom and recent-turn retention. Incremental investigative checkpointing does not grant prune authority; `/compress` must separately pass semantic evacuation and coverage audit.
