# v0.8.0 implementation status

## Implemented in the bundle

- ordinary top-level turns no longer require universal state commit or a finalization inference;
- optional same-assistant-response investigative `state_checkpoint` commits material state and concludes the turn;
- durable state schema 7 includes `constraints` and concrete diagnostic `evidence`;
- incremental state transfer does not advance `prune_safe_through_seq`;
- deterministic exact tool-exchange `×N` context hygiene operates only on active surface representation;
- `/compress` performs rare semantic evacuation against both canonical `ACTIVE_REQUIREMENTS`/`SOURCE_INDEX` and `WORKING_STATE`, validates source-seq/transfer references, rechecks canonical/source/working/session basis before prune, and fails closed on uncertainty;
- local tokenizer helper calls are authenticated and immutable accounting is cached;
- productive tool budgets receive ~20% headroom with exact-cap terminal-step semantics;
- NO_TASK authority is injected before ordinary work and cross-tool mutation retries after denial are blocked;
- HARD pressure may evacuate up to three bounded completed-turn chunks before refusing dispatch, because one compactor input may be insufficient to restore headroom;
- v0.7.4 source-intake, conflict, stale-basis, staging and recoverable transaction protections remain active;
- execution approval, worktree confinement, publication write-set, task checkpoints, independent TEST/REVIEW/ACCEPT and dynamic validation reserve remain active.

## Deliberately not implemented

- no second per-turn FINALIZER;
- no permanent per-turn STATE_CURATOR;
- no hidden-reasoning summarizer;
- no LLM classifier request just to decide whether a turn is investigative;
- no free-form summary as proof that history is prune-safe;
- no deletion of the append-only raw session archive.

## Qualification boundary

Static/mock tests can validate plugin contracts, accounting, guards, state transitions, package identity and mocked DSH surface replacement. They cannot prove the exact installed DSH 0.1.1-rc.1 stream/tool lifecycle or llama server behavior. `_LOCAL_C_DSH-QWEN/03-verify-live.ps1` and `tests/RUNTIME_ADVERSARIAL_SUITE.md` remain required live qualification material.
