# QWEN-V4-FOR-DSH — Final Specification v0.8.0

## 1. Objective

v0.8 keeps DSH as host authority and local Qwen3.8-27B as the bounded executor while separating ordinary conversation, iterative investigative memory, and rare destructive-to-active-context compaction. Source authority, task authority, mutation boundaries, independent validation and raw audit history remain host-controlled.

## 2. Answer-path invariant

Ordinary top-level model turns MUST NOT require a durable state commit and MUST NOT launch a dedicated finalizer. The normal path is:

```text
USER → MAIN QWEN ↔ tools → ANSWER
```

The prior universal `primary → checkpoint → finalizer → answer` protocol is removed.

## 3. Investigative / iterative problem-solving mode

The model receives a short standing definition rather than a separate classification request. Investigative work includes troubleshooting/debugging, research/OSINT, testing, experiments, analytical investigation and iterative construction where intermediate findings matter to future steps.

MAIN MAY call `state_checkpoint` only when the current work establishes material information needed to resume the same problem after the original conversation span is unavailable. If nothing material changed, it MUST omit the checkpoint.

A material checkpoint MAY coexist with ordinary visible answer text in the same assistant message. On successful commit the tool uses DSH terminal-turn semantics (`concludeTurn`) so no second answer-generation inference is required.

Do not transfer the current request merely because it exists, answer formatting, waiting-for-user state, transient orchestration, or one-off protocol/tool failures unless those failures are diagnostic evidence for the investigated problem.

## 4. Durable investigative schema

`WORKING_STATE` schema 7 contains:

```text
known
constraints
decisions
evidence
failed_hypotheses
do_not_repeat
open_acceptance
next_action
```

Evidence fidelity is diagnostic rather than maximally abstract. It may retain exact log excerpts, relevant outputs, values, file/line locations, fingerprints, reproduction conditions and counterexamples. Large raw logs should be represented by the smallest useful exact excerpt plus locator/context rather than copied wholesale.

An incremental `state_checkpoint` records observation/commit metadata but MUST NOT advance `prune_safe_through_seq`.

## 5. Hidden reasoning

The qualified llama launch retains `--no-reasoning-preserve`. Prior `reasoning_content` may remain in the raw session structure but is not rendered into the next model prompt by the qualified template. v0.8 therefore does not add a hidden-reasoning compression mechanism.

## 6. Level-A lossless context hygiene

The host MAY replace an active-surface tail run of exact equivalent contiguous single-tool assistant/result exchanges with one exact representation and `×N` count. Equivalence requires the same normalized tool name/arguments and the same normalized result. No LLM judgment is permitted for this transformation. Non-equivalent events are not folded. The raw append-only session events remain unchanged and are referenced as source events by the replacement marker.

## 7. Level-B semantic evacuation and pruning

Full compaction is admitted only by explicit `/compress` or host pressure policy. A fresh `CONTEXT_COMPACTOR` may inspect an old completed-turn candidate span plus current canonical project state and durable working state. Its task is semantic evacuation, not free-form summary: identify live information in the candidate that lacks a surviving representation, transfer it to the correct durable field, and report coverage.

Coverage categories include user constraints, assistant findings, tool evidence and open work. The surviving basis includes canonical `ACTIVE_REQUIREMENTS` and `SOURCE_INDEX` plus `WORKING_STATE`. Audit `source_seq` values MUST refer to the actual prune candidate; `TRANSFERRED` dispositions MUST name a non-empty durable transfer field. Session revision, source revision, canonical-state fingerprint and working-state fingerprint are rechecked immediately before authorization. Any `UNCERTAIN`, uncovered critical item, forged/out-of-span reference, stale authority basis or divergent state causes fail-closed `COMPACTION_REFUSED`.

Only after a successful coverage audit may the host advance `prune_safe_through_seq` and replace the old completed-turn prefix on the active model surface. The raw session archive is never deleted by compaction.

## 8. Context-pressure behavior

The host maintains completion, compression-recovery and safety reserves against the 131072 context window. SOFT pressure may offer compaction. HARD pressure may attempt up to three sequential bounded, audited completed-turn evacuations; if safe headroom is still HARD, or any pass fails closed, the model dispatch is refused. Compaction is never inferred safe solely from the existence of an investigative checkpoint.

## 9. Tool-budget semantics

Default task global productive-tool ceiling is 144. Default fresh-role productive-tool ceilings are SOURCE_CURATOR 20, TASK_PLANNER 20, TEST_ANALYST 15, REVIEWER 15 and ACCEPTANCE_AUDITOR 8. CONTEXT_COMPACTOR is bounded independently at 8.

At exact productive-tool cap, the next model step is allowed so it can terminate. N+1 productive tool execution is denied by the host guard. Dynamic `structured_output` and checkpoint protocol tools are not productive repository-tool calls.

The worker validation reserve is derived from the remaining mandatory validation chain. Exact worker threshold may still admit the terminal model step; a productive call that would consume protected validation reserve is denied before execution.

## 10. Token accounting

Local tokenizer helper calls MUST use the configured llama API credential (`Authorization: Bearer ${LLAMA_LOCAL_API_KEY}` when present). Immutable assistant-step accounting SHOULD be cached/reused rather than repeatedly tokenized. Failure of exact tokenizer accounting may fall back conservatively, but local auth failure must not be the normal path.

## 11. Mutation authority

Hard mutation guards remain authoritative across direct write/edit and shell/other gated mutation surfaces. `NO_TASK` provides no workspace mutation authority. A normal user request to write/compose text is interpreted as a chat answer unless the user explicitly requests project-file mutation through the controlled workflow. After an authoritative mutation-policy denial, equivalent mutation attempts through another tool in the same turn are denied.

## 12. Explicit workflow authority

`/triage`, `/task`, `/work`, `/review`, `/accept` remain separate host workflows. Fresh roles are used where independence has a reason: source curation, task planning, review, acceptance, and rare context compaction. There is no per-turn FINALIZER and no permanent per-turn STATE_CURATOR.

`/work` may retain stricter task-owned checkpoints, pending-evidence coverage, worktree confinement, write-set publication contract and dynamic validation reserve. These are workflow controls and do not reintroduce universal ordinary-turn commit.

## 13. Source authority retained from v0.7.4

The source system preserves PRIMARY / supplementary-dirty / historical relationships, intersection-only dirty adoption, conflict-before-mutation, strict preserve, historical compatibility/regression-only semantics, durable stable conflict ids, explicit conflict resolution ids, source generation/revision, relationship-only revision invalidation, concurrent stale-basis rejection, large raw-input staging, and recoverable multi-file project transactions.

Failed or stale triage staging is not durable source authority. Unknown transaction target divergence fails closed.

## 14. Qualification

Release qualification requires source tests, JS syntax checks, JSON/BOM/YAML validation, npm tgz/source identity, manifest identity, extracted-ZIP re-execution of the same suite, and adversarial cases. Live Windows DSH/llama qualification remains mandatory before production trust because static mocks cannot prove installed DSH streaming and hook semantics.
