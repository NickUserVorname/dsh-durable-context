# Install and run v0.8.0 on Windows

Prerequisites: Git project, DSH web profile, local llama-server and Qwen3.8-27B GGUF. The target overlay assumes the qualified `C:\DSH-QWEN` layout.

## Generic install

```powershell
Set-ExecutionPolicy -Scope Process Bypass

.\INSTALL_V0_8_WINDOWS.ps1 `
  -ProjectRoot C:\path\to\git-repo `
  -DshHome C:\DSH-QWEN\dsh-home
```

The installer installs `dist\local-dsh-v4-control-0.8.0.tgz`, the `qwen-v4` preset, and missing Project Pack files. It writes runtime policy as UTF-8 without BOM and refuses to overwrite an existing `.dsh` by default.

For an existing controlled project, use `-ExistingProjectPolicy MergeMissing` only after reviewing migration impact. v0.8 adds missing policy fields. If the original policy is a v0.7 schema and a tool-call value is exactly the shipped v0.7 default, the installer upgrades that value to the v0.8 +20% default. A customized value is preserved. `validation_reserve` is then recomputed from the effective TEST/REVIEW/ACCEPT role caps.

## Target-machine qualification install

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\_LOCAL_C_DSH-QWEN\02-install-v080-qualification.ps1
```

Default project:

```text
C:\DSH-QWEN\qualification-v080
```

Start local Qwen:

```powershell
& "C:\DSH-QWEN\start-qwen38-128k.ps1"
```

Verify files/config/auth/model:

```powershell
.\_LOCAL_C_DSH-QWEN\03-verify-live.ps1
```

Start DSH:

```powershell
& "C:\DSH-QWEN\start-dsh-qwen.cmd" "C:\DSH-QWEN\qualification-v080"
```

Create a new session using preset `qwen-v4`, provider `llama-local`, model `qwen3.8-27b`.

## Runtime behavior to verify

Ordinary text request:

```text
USER → MAIN → ANSWER
```

It must not require a checkpoint and must not launch a finalizer.

Investigative material result:

```text
MAIN reasoning/tools
→ assistant visible answer + state_checkpoint call
→ host commits transferable state
→ concludeTurn
```

There is no post-checkpoint finalizer inference. If no material state changed, MAIN simply answers and omits the checkpoint.

`state_checkpoint` is for transferable iterative-problem-solving state, not a turn summary. Concrete evidence such as exact log lines/fingerprints may be retained when diagnostically useful.

## Context management

Level-A deterministic hygiene is always available and can collapse identical contiguous tool exchanges on the active model surface to one exact exchange plus `×N`; the raw session log remains intact.

Full semantic pruning is rare:

```text
/compress --dry-run
/compress
```

A real compaction requires semantic evacuation and coverage proof. Incremental investigative state does not itself move `prune_safe_through_seq`. If a live old user constraint, assistant finding, tool evidence or open work item has no surviving representation, the compactor must transfer it or refuse compaction.

## Tool budgets

Default productive tool caps in v0.8:

```text
task global          144
SOURCE_CURATOR        20
TASK_PLANNER          20
TEST_ANALYST          15
REVIEWER              15
ACCEPTANCE_AUDITOR     8
```

At the exact cap the next model step may still terminate normally; the N+1 productive tool call is denied. Dynamic `structured_output` is a terminal protocol tool and does not consume the productive role-tool count.

## Model baseline

```text
ctx 131072
tensor split 4,1
K q8_0
V q5_1
FlashAttention on
fit off
reasoning medium / 6144
--no-reasoning-preserve
API key local
```

`--no-reasoning-preserve` means prior raw reasoning is not rendered back into the next Qwen prompt. v0.8 therefore manages visible conversation/tool surfaces rather than attempting to summarize hidden reasoning.
