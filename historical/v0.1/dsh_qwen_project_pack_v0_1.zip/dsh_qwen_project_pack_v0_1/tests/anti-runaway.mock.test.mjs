import assert from 'node:assert/strict'
import { apply } from '../dsh-bundle-anti-runaway/index.js'

const handlers = new Map()
let guard
const ctx = {
  logger: { warn() {} },
  on(name, fn) { handlers.set(name, fn) },
  tools: { guard(fn) { guard = fn } },
}
apply(ctx, { maxStepsPerTurn: 2, maxToolCallsPerTurn: 4, maxTokensPerRequest: 100, identicalFailureLimit: 1, cancelAfterBlockedAttempts: 2 })

const cancels=[]
const agent={ id:'a', cancel(cause, opts){ cancels.push({cause,opts}) } }
const pre=handlers.get('agent/pre-step')
assert.deepEqual(await pre({agent,turn:1,step:1}, async()=>({kind:'enter',messages:[]})), {kind:'enter',messages:[]})
assert.deepEqual(await pre({agent,turn:1,step:3}, async()=>({kind:'enter',messages:[]})), {kind:'reject'})

const req=handlers.get('agent/request')
assert.equal((await req({}, async()=>({maxTokens:999}))).maxTokens, 100)
assert.equal((await req({}, async()=>({}))).maxTokens, 100)

const exec={name:'bash',arguments:{command:'bad'},agent}
assert.equal(guard(exec), undefined)
handlers.get('tools/result')(exec,{isError:true,error:{message:'boom',info:{code:'E'}}})
assert.match(guard(exec), /exact failed tool replay denied/)
assert.equal(cancels.length,0)
assert.match(guard(exec), /exact failed tool replay denied/)
assert.equal(cancels.length,1)
console.log('anti-runaway mock tests: PASS')
