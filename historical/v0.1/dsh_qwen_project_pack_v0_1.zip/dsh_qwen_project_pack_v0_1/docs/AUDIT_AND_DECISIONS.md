# Audit of OpenCode v4 donor -> DSH target

## What the donor really is

The v4 bundle has two layers: `Universal_OpenCode_Core` (agents, skills, commands, OpenCode registration) and `Project_Pack_Template` (source authority, requirements, phase/task state, claims/handoffs, quality gates). The portable value is overwhelmingly in the second layer plus a small set of procedural skills.

### Portable invariants

- classify source artifacts before mutation;
- separate direct user requirements from assistant/model proposals in transcripts;
- explicit precedence beats dates/filenames/detail level;
- material source conflict blocks mutation;
- source authority changes increment `source_revision` and stale older task packets;
- implementation works from a compact normalized task packet with exact provenance;
- retained/legacy capability must be explicitly regression-checked;
- two evidence-backed failed hypotheses trigger escalation rather than endless patching;
- long benchmark rerun requires a new root-cause reason;
- mandatory acceptance follows requirement -> canonical implementation -> production path -> failure/fallback semantics -> focused test -> regression/integration -> real evidence;
- proxy evidence (class exists, flag exists, branch exists, mock passes, unrelated suite green) is not production proof;
- next phase does not start automatically.

### OpenCode mechanics we are not porting

- OpenCode `opencode.jsonc`, permission/model declarations and installers;
- the permanent lead/architect/source-curator/implementer/tester/debugger/reviewer/auditor topology;
- OpenCode command registration;
- Pro-vs-Flash routing as an architectural requirement;
- the old Python claim/task wrappers as the DSH runtime.

## New requirement from the failure logs / continuation chat

The donor already has pieces of this, but the new DSH profile must make it explicit:

**production-integrity rule** — never replace/remove retained functionality because a smaller substitute is easier; never count sidecar/shadow code as implementation when the requirement is production integration; never insert placeholders/stubs as if complete; and never call a requirement done until the real canonical path exercises it.

This is specifically aimed at the Codex/Sol failure class discussed in the continuation: large CLI / dirty-input processing / new routing were not to be silently reduced, bypassed or left as a detached shadow implementation.

## Why stock DSH is not enough

Current `standard` is a broad coding preset. It includes goal/delegation/workflow machinery, a spawn subagent, a fork subagent, Ralph (`maxRounds: 64`), todo and web tools. That is useful as a capability library, but it is too autonomous as the initial profile for a single local Qwen after observed runaway failures.

The stock repeat-tool reminder is explicitly advisory: it detects identical consecutive calls and injects reminders, but does not veto them. Therefore the first local profile needs a hard turn/failed-call layer below model intent.
