# Target DSH architecture

```text
User / current normative sources
        |
        v
.dsh/project source authority + source_revision
        |
        v
DSH main agent (standard-derived, deliberately reduced)
  - fs read/write/edit + fs search
  - shell for tests/commands
  - compact skill catalog
  - web search when configured
  - NO Ralph initially
  - NO goal-autonomy initially
  - NO fork subagent initially
  - NO generic workflow swarm initially
        |
        +--> anti-runaway bundle (hard step/output/tool-replay caps)
        |
        +--> task packet / production-integrity / debugger skills
        |
        +--> fresh reviewer SPAWN (only when independent check is needed)
        |
        +--> fresh acceptance SPAWN (phase boundary only)
        v
Qwen3.8-27B local route through llama-server
```

## Roles

There is one normal implementation session. `source-curator`, `architect`, `debugger` and most `tester` behavior are procedures/skills, not permanent agents. Reviewer and acceptance are fresh `spawn` contexts so they do not inherit implementer reasoning. `fork` is not part of the first profile because inherited history defeats the independence goal and adds context cost.

## State ownership

DSH owns session/runtime/tool state. `.dsh/project/` owns durable project truth that must survive compaction or a fresh session: source revision, active requirement view, phase, task packets, task graph/claims, decisions/blockers and evidence pointers. Chat history is not project authority.

## Reasoning policy

First safe profile:

- Qwen reasoning enabled;
- server default reasoning effort LOW (`llama-server --reasoning-effort low` on current llama.cpp);
- hard reasoning budget at llama-server;
- per-request DSH `maxTokens` clamp;
- raw hidden-thinking persistence is a switch, not an architectural dependency;
- explicit compact working state carries durable conclusions/evidence.

Official Qwen guidance favors preserving thinking for agent consistency/cache reuse, while the supplied runaway examples show that pathological traces can also become harmful state. Therefore preserve-thinking must be A/B tested on the real tasks under the same hard limits instead of decided by doctrine.

## What is hard vs soft in v0.1

Hard now: step cap, request-output clamp, tool-call cap, exact failed-call replay denial/cancel.

Project-authority semantics now: source revision/task packet/acceptance are explicit durable files and skills, but full mutation enforcement is not yet hard for arbitrary shell writes.

Hardening next: FS/sandbox-level write-set authority, source-revision gate before mutation, benchmark ownership, explicit scope-expansion gate, telemetry and no-progress evidence tracking.
