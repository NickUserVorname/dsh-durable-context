# Runbook: first DSH bring-up

## 0. Do not modify stock preset in place

Copy DSH `standard` into a custom preset/profile and inspect the exact active composition with:

```bash
dsh --profile web --dump-config
```

A ready reduced preset is included at `dsh-preset-qwen-safe/`. Copy it to `$DSH_HOME/.agent-presets/qwen-safe/`. It omits `tool-goal`, fork, workflows, Ralph and generic background delegation, and exposes only fixed fresh review/acceptance spawn tools.

Why: current stock `standard` exposes both spawn and fork, workflow machinery and Ralph with `maxRounds: 64`. This is an intentionally broad preset, not the safety profile for this project.

## 1. Install anti-runaway bundle

From the bundle directory:

```bash
dsh plugin --profile web add ./dsh-bundle-anti-runaway
```

Then inspect the profile and **real boot**, not only a static file:

```bash
dsh --profile web --dump-config
# then start your normal DSH surface and confirm the plugin logs once
```

If your profile already manually inserts bundle-declaring plugins in `cordis.patch.yml`, back it up first and avoid double registration. Recent DSH community reports show duplicate bundle/manual insert rows can break boot.

## 2. Install project files

Copy the *contents* of `project-template/` into the repository root. DSH discovers project skills under `.dsh/skills/`.

Populate in this order before implementation:

```text
.dsh/project/SOURCE_INTAKE.md
.dsh/project/SOURCE_INDEX.json
.dsh/project/SOURCE_CONFLICTS.md
.dsh/project/ACTIVE_REQUIREMENTS.md
.dsh/project/CURRENT_PHASE.md
.dsh/project/PROJECT_INVARIANTS.md
.dsh/project/task_packets/<task>.md
```

Set source intake to READY only after precedence/conflicts are actually resolved.

## 3. llama-server reasoning safety profile

Use the exact flags supported by your pinned llama.cpp build. The intended first profile is:

```text
--reasoning on
--reasoning-effort low
--reasoning-format deepseek
--reasoning-budget 8192
--reasoning-budget-message "Reasoning budget reached. Use established evidence; act, finish, or return a concise blocked handoff."
--no-reasoning-preserve
```

This is the conservative first run because of the supplied reasoning-runaway trace. It is **not** a claim that no-preserve is universally better for Qwen. After smoke/real-task baselines, A/B the same suite with preserve enabled while keeping all hard caps identical.

## 4. Mandatory smoke tests before real project mutation

Run these against a disposable repository:

```text
A. 17-step synthetic tool loop -> turn must not continue beyond configured step cap.
B. Same failing tool+same args twice -> second execution must be denied.
C. Hammer blocked call again -> active turn must be cancelled.
D. One large reasoning response -> request output must be clamped; llama reasoning budget must stop thinking.
E. Normal edit -> focused test -> final answer path must still work.
F. Fresh reviewer spawn -> must not inherit implementation history.
G. Compaction/restart -> `.dsh/project` source revision/task packet remains authority.
```

## 5. First real-task policy

Start with one active implementation task. No Ralph, no goal loop, no fork, no swarm. A task ends at acceptance or a bounded blocker handoff. If two evidence-backed debugging hypotheses fail, escalate/re-plan; do not keep trying variants indefinitely.

## 6. What is deliberately not declared finished yet

- hard write-set enforcement for shell mutations;
- SearXNG provider wiring (needs a chosen/verified DSH web provider plugin or a small adapter);
- automated source-revision mutation denial;
- benchmark ownership lock;
- semantic no-progress detector;
- final tuned Qwen preserve-thinking decision;
- exact V100/3070Ti layer split/performance profile.

These are next implementation/qualification tasks, not hidden assumptions.
