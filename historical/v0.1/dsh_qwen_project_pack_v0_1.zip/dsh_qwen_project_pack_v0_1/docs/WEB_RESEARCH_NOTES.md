# Web research notes (2026-08-22)

Verified against current DeepSeek Harness master/docs:

- `standard` includes fs/search/shell/skills/compaction plus spawn and fork subagents, workflow and Ralph; its Ralph row currently sets `maxRounds: 64`.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/apps/cli/config/agent-presets/standard/agent.cordis.yml
- Agent extension points include waterfall `agent/pre-step` and `agent/request`; `Agent.cancel({kind:'hook', reason})` is public.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/core/agent/src/runtime-types.ts
- `ctx.tools.guard()` is a monotonic post-policy guard; later listeners cannot re-allow a denied tool call.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/core/tools/README.md
- Stock repeat-tool-reminder is advisory only and explicitly does not veto/rewrite calls.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/guard/repeat-tool-reminder/README.md
- DSH bundle packages declare `dsh.bundle.patch`/`dsh.bundle` patch and can be installed as profile layers; current docs recommend inspecting effective composition with `dsh --profile ... --dump-config`.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md
- Current DSH fs tools are `read`, `read_image`, `write`, `edit`; write/edit use `file_path` and the fs observation policy supplies read-before-write behavior.
  https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/fs/tool-fs/README.md

Operational caution: DSH is a developer preview and current community reports include runaway loops/very large token burns; pin an exact working build and smoke-test the safety bundle before real mutations.

- Current llama.cpp server documents `--reasoning-effort`, `--reasoning-budget`, `--reasoning-budget-message`, and `--reasoning-preserve/--no-reasoning-preserve`.
  https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md
