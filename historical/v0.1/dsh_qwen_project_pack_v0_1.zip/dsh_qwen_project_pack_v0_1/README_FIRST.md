# DSH + Qwen project-control pack v0.1

This is **not an OpenCode runtime**. The uploaded OpenCode v4 bundle was read in full and is used only as a donor of source-authority, task, evidence, regression and acceptance semantics.

Target runtime: **DeepSeek Harness (DSH)**. Main local model: Qwen3.8-27B. OpenCode registration, model routing, installer scripts and the old multi-agent runtime are not carried forward.

## What is actually implemented here

1. `dsh-bundle-anti-runaway/` — a DSH-native bundle using current public seams (`agent/pre-step`, `agent/request`, `ctx.tools.guard`, `tools/result`) to bound one turn and stop exact failed-call replay.
2. `project-template/.dsh/project/` — DSH-neutral project authority/state templates derived from the useful part of Project Pack v4.
3. `project-template/.dsh/skills/` — a deliberately small skill set; not a dump of every old OpenCode skill.
4. `docs/MIGRATION_MAP.csv` — every donor file classified.
5. `docs/SOURCE_READ_MANIFEST.csv` — every donor file with bytes/line count/SHA-256.
6. `docs/TARGET_ARCHITECTURE.md`, `docs/AUDIT_AND_DECISIONS.md`, `docs/RUNBOOK.md`.

## Important boundary

The anti-runaway bundle is syntax/mock tested in this artifact, but it has **not** been booted inside your actual DSH installation in this environment. DSH is a fast-moving developer preview; run the smoke procedure in `docs/RUNBOOK.md` against the exact installed build before trusting it.

Write-set enforcement is intentionally **not claimed as complete** here. Guarding only DSH `write`/`edit` is not sufficient while `bash`/`pwsh` can mutate the repository. Hard path-level mutation policy belongs at the FS/sandbox authority layer or requires a restricted shell policy.
