# Project execution rules

Project authority lives in `.dsh/project/`, not in chat memory.

Before mutation:
1. read `.dsh/project/SOURCE_INTAKE.md` and current source revision;
2. read the active task packet and reject it if revisions differ;
3. load `production-integrity` plus any task-specific skill;
4. preserve retained functionality and canonical production integration;
5. after two evidence-backed failed debug hypotheses, stop and escalate/re-plan;
6. do not start the next phase automatically.

A class/flag/branch/mock/green unrelated suite is not proof. Mandatory `NOT_PROVEN` is failure.
