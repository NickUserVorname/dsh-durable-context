# Active approved requirement view

This is a **compact compiled normative index/view**, not a dump or paraphrase of every uploaded Markdown/chat/log.

Raw/adopted sources and authority are recorded in `SOURCE_INTAKE.md`, `SOURCE_INDEX.json`, `SOURCE_CONFLICTS.md`, and `source_material/`.

For a large formal specification (including 7k+ lines), keep the raw document unchanged and reference exact source IDs + sections/requirement IDs here. Do not spend tokens rewriting the full document or weaken wording through paraphrase.

For clean+dirty input, include only clean requirements plus explicitly compatible/adopted clarifications. Do not copy unmatched dirty ideas or assistant/model proposals.

## Source revision

Current revision: `0`. Any normative/source-authority change increments this value and invalidates older task packets.

## Precedence

Populate during `/ingest-sources`.

## Negative requirements / compatibility

Populate exact references; do not omit prohibitions merely because they are not implementation features.

## Phase map / approved requirements

Populate as an index with exact provenance. Put the exact text needed for execution into the relevant phase/task packet rather than duplicating the whole source bundle.
