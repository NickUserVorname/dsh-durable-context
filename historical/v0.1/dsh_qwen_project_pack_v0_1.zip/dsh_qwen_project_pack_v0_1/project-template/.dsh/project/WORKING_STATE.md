# Compact explicit working state

Use this instead of relying on raw hidden reasoning as durable project memory.

```yaml
task_id: null
source_revision: 0
goal: ""
known_evidence: []
changed_files: []
failed_attempts: []
do_not_repeat: []
next_discriminating_action: ""
acceptance_left: []
blocker: null
```

Update only with externally grounded facts/results. Do not paste chain-of-thought.
