# llama-server reasoning profiles

Current llama.cpp master exposes `--reasoning-effort`, `--reasoning-budget`, `--reasoning-budget-message` and preserve/no-preserve directly. The first production-safety profile uses LOW + 8192 hard thinking budget + no historical reasoning preservation. The A/B profile flips only preservation.

Do not change effort, budget and preserve behavior simultaneously when comparing loop rate/quality. Pin the llama.cpp build and run a correctness smoke for Qwen3.8 before qualification.
