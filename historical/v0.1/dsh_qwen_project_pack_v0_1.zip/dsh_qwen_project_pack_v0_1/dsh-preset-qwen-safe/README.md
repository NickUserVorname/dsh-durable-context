# qwen-safe preset

Copy this directory to:

```text
$DSH_HOME/.agent-presets/qwen-safe/
```

The current DSH standard preset was used as the reference, but this version intentionally omits: `tool-goal`, plan mode, jobs/background controls, `subagent_fork`, generic continuable `subagent`, workflow engine, `tool-workflow`, Ralph and `ask_user_question`.

It keeps filesystem/search/shell/skills/compaction, one serial todo list, web search, and two fixed fresh one-shot read-only review tools.

The reviewer/auditor tool filters intentionally omit shell and write/edit. They therefore validate code/evidence but cannot independently execute tests in v0.1. If independent test execution is required later, add a dedicated constrained test tool rather than giving the verifier unrestricted shell mutation power.
