# dsh-project-anti-runaway

Hard lower-bound safety layer for the first local Qwen/DSH profile.

- rejects model steps after `maxStepsPerTurn`;
- clamps per-request output tokens through `agent/request`;
- cancels after tool-call budget overflow;
- records canonical failed tool calls from `tools/result`;
- the next exact `tool + arguments` replay is denied through monotonic `ctx.tools.guard()`;
- repeated attempts to hammer the blocked call cancel the turn.

It intentionally does **not** claim semantic no-progress detection, fuzzy tool-loop detection, or repository write-set enforcement.
