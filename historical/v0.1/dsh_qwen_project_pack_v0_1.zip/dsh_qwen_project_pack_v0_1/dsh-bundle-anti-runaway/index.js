export const name = 'dsh-project-anti-runaway'
export const inject = ['tools']

const DEFAULTS = Object.freeze({
  maxStepsPerTurn: 16,
  maxToolCallsPerTurn: 40,
  maxTokensPerRequest: 8192,
  identicalFailureLimit: 1,
  cancelAfterBlockedAttempts: 2,
  trackNestedCalls: false,
})

function positiveInt(value, field) {
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(`${field} must be a positive safe integer`)
  return value
}

function canonical(value) {
  const walk = (v) => {
    if (Array.isArray(v)) return v.map(walk)
    if (v !== null && typeof v === 'object') {
      const out = Object.create(null)
      for (const key of Object.keys(v).sort()) out[key] = walk(v[key])
      return out
    }
    return v
  }
  const encoded = JSON.stringify(walk(value))
  return encoded === undefined ? String(value) : encoded
}

function callKey(exec) {
  return `${exec.name}\n${canonical(exec.arguments)}`
}

function failureText(result) {
  if (!result?.isError) return ''
  const err = result.error ?? {}
  const info = err.info ?? {}
  const code = info.code ?? info.name ?? 'ERROR'
  return `${code}:${err.message ?? 'tool failed'}`
}

export function apply(ctx, config = {}) {
  const maxSteps = positiveInt(config.maxStepsPerTurn ?? DEFAULTS.maxStepsPerTurn, 'maxStepsPerTurn')
  const maxToolCalls = positiveInt(config.maxToolCallsPerTurn ?? DEFAULTS.maxToolCallsPerTurn, 'maxToolCallsPerTurn')
  const maxTokens = positiveInt(config.maxTokensPerRequest ?? DEFAULTS.maxTokensPerRequest, 'maxTokensPerRequest')
  const failureLimit = positiveInt(config.identicalFailureLimit ?? DEFAULTS.identicalFailureLimit, 'identicalFailureLimit')
  const cancelAfter = positiveInt(config.cancelAfterBlockedAttempts ?? DEFAULTS.cancelAfterBlockedAttempts, 'cancelAfterBlockedAttempts')
  const trackNested = config.trackNestedCalls ?? DEFAULTS.trackNestedCalls

  const states = new WeakMap()

  function stateFor(agent, turn) {
    const old = states.get(agent)
    if (old && old.turn === turn) return old
    const fresh = { turn, step: 0, toolCalls: 0, failures: new Map(), blockedAttempts: new Map() }
    states.set(agent, fresh)
    return fresh
  }

  ctx.on('agent/pre-step', async ({ agent, turn, step }, next) => {
    const state = stateFor(agent, turn)
    state.step = step
    if (step > maxSteps) {
      ctx.logger?.warn?.(`anti-runaway: rejecting agent=${agent.id} turn=${turn} step=${step} max=${maxSteps}`)
      return { kind: 'reject' }
    }
    return next()
  })

  ctx.on('agent/request', async (_payload, next) => {
    const base = await next()
    return {
      ...base,
      maxTokens: base.maxTokens === undefined ? maxTokens : Math.min(base.maxTokens, maxTokens),
    }
  })

  ctx.tools.guard((exec) => {
    if (!trackNested && exec.parent !== undefined) return undefined
    const agent = exec.agent
    if (!agent) return undefined
    const state = states.get(agent)
    if (!state) return undefined

    state.toolCalls += 1
    if (state.toolCalls > maxToolCalls) {
      const reason = `anti-runaway: tool-call budget exceeded (${state.toolCalls}/${maxToolCalls})`
      agent.cancel({ kind: 'hook', reason }, { keepInbox: false })
      return reason
    }

    const key = callKey(exec)
    const failure = state.failures.get(key)
    if (!failure || failure.count < failureLimit) return undefined

    const attempts = (state.blockedAttempts.get(key) ?? 0) + 1
    state.blockedAttempts.set(key, attempts)
    const reason = `anti-runaway: exact failed tool replay denied; previous failure=${failure.error}`
    if (attempts >= cancelAfter) {
      agent.cancel({ kind: 'hook', reason: `${reason}; blocked replay attempts=${attempts}` }, { keepInbox: false })
    }
    return reason
  })

  ctx.on('tools/result', (exec, result) => {
    if (!trackNested && exec.parent !== undefined) return
    const agent = exec.agent
    if (!agent) return
    const state = states.get(agent)
    if (!state) return
    const key = callKey(exec)

    if (!result?.isError) {
      state.failures.delete(key)
      state.blockedAttempts.delete(key)
      return
    }

    const prev = state.failures.get(key)
    state.failures.set(key, {
      count: (prev?.count ?? 0) + 1,
      error: failureText(result),
    })
  })
}

export const _test = { canonical, callKey, failureText }
