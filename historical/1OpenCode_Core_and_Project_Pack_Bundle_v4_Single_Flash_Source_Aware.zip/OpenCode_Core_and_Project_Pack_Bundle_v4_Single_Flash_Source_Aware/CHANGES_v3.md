# v3 — Source-aware API Hands

This revision keeps the v2 Pro-lead / cheap-hands architecture and adds a hard source-intake layer for the input styles actually used with this pack.

## Why

Not every uploaded Markdown/text file is a technical specification. A project may arrive as:

- one large formal specification;
- a stack of formal base/correction/recovery specifications with explicit precedence;
- a clean mini-spec plus a long dirty discussion/idea transcript;
- a read-only audit/review plus an instruction to repair from it;
- an implementation conversation/log that mixes user corrections, assistant proposals, tool output and status claims.

Treating all of those as equally normative can manufacture requirements from assistant text or stale implementation claims.

## Added

- `source-triage` skill;
- `source-curator` Pro agent;
- `/ingest-sources` command;
- project `SOURCE_POLICY.md`, `SOURCE_INTAKE.md`, `SOURCE_INDEX.json`, `SOURCE_CONFLICTS.md`;
- raw-source retention folder `project_pack/source_material/`;
- source-intake status in `.agent/state.json`;
- hard pre-mutation conflict gate;
- explicit clean+dirty intersection mode;
- assistant/model text in transcripts is non-normative unless explicitly adopted by the user;
- explicit user corrections inside transcripts can become candidate normative deltas;
- audit/review findings are evidence/repair overlays, not architecture authority unless the user explicitly promotes them;
- explicit source-declared precedence beats file date/order;
- backwards-compatibility mode is carried into task packets and acceptance tests.

## v2 behavior retained

- Pro lead/reviewer/auditor;
- Flash implementation/test/debug hands;
- bounded Flash→Pro escalation;
- parallel conflict-free hands;
- task packets;
- write/resource claims;
- serialized long benchmark ownership;
- independent integration/review/acceptance gates.
