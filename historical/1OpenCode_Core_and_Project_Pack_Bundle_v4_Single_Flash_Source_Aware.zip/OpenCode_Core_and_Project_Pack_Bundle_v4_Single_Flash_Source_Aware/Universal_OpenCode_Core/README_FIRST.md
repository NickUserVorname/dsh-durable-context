# Universal OpenCode Core v4 — Source-aware Pro Lead + Single API Hand

Install this once into global OpenCode configuration. It is the reusable engine: agents, commands and skills. Project-specific requirements/state live in the separate Project Pack.

## Default model topology

- Pro: `lead`, `source-curator`, `architect`, `reviewer`, `acceptance-auditor`, `implementer-pro`, `debugger-pro` -> `deepseek/deepseek-v4-pro`
- Cheap: `implementer`, `tester`, `debugger` -> `deepseek/deepseek-v4-flash`
- **Only one cheap/Flash role is active at a time by default.** Parallel hands are opt-in, not automatic.

Connect the **direct DeepSeek provider** via `/connect`, then verify the two model IDs via `/models`. OpenCode uses `provider/model-id` IDs; current direct IDs are `deepseek/deepseek-v4-pro` and `deepseek/deepseek-v4-flash`.

## Source modes

Supports large formal specs, formal base/correction/recovery stacks, clean mini-spec + dirty requirement draft/discussion, audit-driven repair, dirty agent transcripts, and current-state reports that are evidence rather than requirements.

Run `/ingest-sources` whenever source authority changes. User corrections increment source revision and invalidate stale task packets.

## Workflow

`/ingest-sources` -> `/plan-phase` -> `/implement-phase` -> `/integrate-hands` -> `/test-phase` -> `/debug-phase`/`/escalate-task` -> `/review-phase` -> `/finish-phase`.

`/auto-run-current-phase` stays inside the current phase, defaults to one Flash hand, and never bypasses source conflicts or benchmark gates.

## Installer safety

The installer backs up and merges global AGENTS rules. Existing global `opencode.jsonc` is preserved by default and a reference config is emitted instead of silently overwriting it. Use `-ReplaceGlobalConfig` only if you explicitly want replacement.
