param(
    [switch]$ReplaceGlobalConfig
)

$ErrorActionPreference = "Stop"
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $env:USERPROFILE ".config\opencode"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "Installing Universal OpenCode Core v4"
Write-Host "Target: $Target"
New-Item -ItemType Directory -Force -Path $Target | Out-Null

function Backup-Path([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $Backup = "$Path.backup-$Stamp"
        Copy-Item -Recurse -Force -LiteralPath $Path -Destination $Backup
        Write-Host "Backup: $Path -> $Backup"
    }
}

function Copy-TreeContents([string]$From, [string]$To) {
    New-Item -ItemType Directory -Force -Path $To | Out-Null
    Get-ChildItem -LiteralPath $From -Recurse -File -Force | ForEach-Object {
        $Relative = $_.FullName.Substring($From.Length).TrimStart([char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar))
        $Dest = Join-Path $To $Relative
        $Parent = Split-Path -Parent $Dest
        New-Item -ItemType Directory -Force -Path $Parent | Out-Null
        Copy-Item -Force -LiteralPath $_.FullName -Destination $Dest
    }
}

# Merge pack block into personal global AGENTS.md.
$PackAgents = Get-Content -LiteralPath (Join-Path $Source "AGENTS.md") -Raw
$AgentsTarget = Join-Path $Target "AGENTS.md"
$Begin = "<!-- BEGIN OPENCode CORE v4 -->"
$End = "<!-- END OPENCode CORE v4 -->"
$Pattern = [regex]::Escape($Begin) + ".*?" + [regex]::Escape($End)
$Regex = [regex]::new($Pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
$Block = "$Begin`r`n$PackAgents`r`n$End"
if (Test-Path -LiteralPath $AgentsTarget) {
    Backup-Path $AgentsTarget
    $Existing = Get-Content -LiteralPath $AgentsTarget -Raw
    if ($Regex.IsMatch($Existing)) { $Merged = $Regex.Replace($Existing, $Block) }
    else { $Merged = $Existing.TrimEnd() + "`r`n`r`n" + $Block + "`r`n" }
    Set-Content -LiteralPath $AgentsTarget -Value $Merged -Encoding UTF8
} else {
    Set-Content -LiteralPath $AgentsTarget -Value $Block -Encoding UTF8
}

# Merge named agent/skill/command files without directory nesting.
foreach ($DirName in @("agents", "skills", "commands")) {
    $From = Join-Path $Source $DirName
    $To = Join-Path $Target $DirName
    if (Test-Path -LiteralPath $To) { Backup-Path $To }
    Copy-TreeContents $From $To
}

# Preserve user-owned global config unless explicit replacement requested.
$ConfigSource = Join-Path $Source "opencode.jsonc"
$ConfigTarget = Join-Path $Target "opencode.jsonc"
if (-not (Test-Path -LiteralPath $ConfigTarget)) {
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $ConfigTarget
} elseif ($ReplaceGlobalConfig) {
    Backup-Path $ConfigTarget
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $ConfigTarget
} else {
    $Reference = Join-Path $Target "opencode.core-v4.reference.jsonc"
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $Reference
    Write-Warning "Existing global opencode.jsonc preserved. Review/merge $Reference if you want pack default_agent/permission defaults."
}

Write-Host "Universal core installed."
Write-Host "Use /connect -> DeepSeek and /models to verify deepseek/deepseek-v4-pro and deepseek/deepseek-v4-flash."
Write-Host "If your existing global config was preserved, switch to @lead manually or merge the emitted reference config."
