---
name: repository-explorer
description: Establish the factual current repository topology, canonical owners, runtime paths, tests and persistence before planning or editing.
---
# Workflow

Inspect facts before desired architecture.

Map:
- repository roots and packages;
- entry points and CLI/service startup;
- canonical production owners for the task;
- imports/dependency direction;
- runtime call path;
- persistence/config/benchmark stores;
- tests and fixtures;
- generated/vendor/legacy/archive boundaries;
- duplicate or superseded implementations.

Do not infer ownership from filenames alone. Follow actual imports/calls/registrations.

Return a compact repository map with exact paths/functions and unresolved ambiguity. If two implementations both appear active, treat that as an architectural finding rather than choosing one silently.
