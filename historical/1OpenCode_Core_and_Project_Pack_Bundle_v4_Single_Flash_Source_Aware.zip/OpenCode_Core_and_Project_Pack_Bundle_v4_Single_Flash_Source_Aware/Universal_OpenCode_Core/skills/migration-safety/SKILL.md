---
name: migration-safety
description: Protect persisted/runtime compatibility with explicit versioning, interrupted-upgrade behavior, rollback and legacy-read policy.
---
# Workflow

Identify every persisted format/config/binding touched. Define old->new compatibility, version bump, atomicity, crash points, rollback and stale-cache invalidation. Test interrupted migration and downgrade/rollback where supported.

Never silently reuse stale artifacts merely because they deserialize.
