---
name: edge-case-hunter
description: Derive adversarial boundary/failure cases from exact requirements, state machines and interfaces instead of generic random fuzzing.
---
# Coverage families

Consider empty/zero/singleton, minimum/maximum, malformed/corrupt, duplicate/idempotency, ordering/out-of-order, timeout/cancel, retry exhaustion, OOM/resource loss, restart/resume, stale provenance/cache, Unicode/path weirdness, races, partial persistence, fallback failure and unavailable optional backends.

Tie every generated case to a requirement or production state transition. Preserve ambiguous inputs as ambiguous when the spec forbids guessing.
