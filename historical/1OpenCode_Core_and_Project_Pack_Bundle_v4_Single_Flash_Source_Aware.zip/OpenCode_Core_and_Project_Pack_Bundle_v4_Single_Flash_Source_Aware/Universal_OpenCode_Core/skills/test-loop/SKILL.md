---
name: test-loop
description: Run a bounded focused-to-regression test loop; classify failures and prohibit blind long/full reruns.
---
# Order

1. Static/compile/type checks relevant to changed files.
2. New focused regression test.
3. Nearby unit/contract tests.
4. Relevant integration tests.
5. Phase regression suite.
6. Hardware/long/full qualification only when required gates are green.

On failure:
- capture exact command, first failing assertion/state and artifacts;
- classify cause before editing;
- do not change tests merely to accept current behavior;
- rerun the narrowest proving test after the fix;
- broaden only after narrow evidence is green.

A long run may be repeated only after a specific diagnosed change relevant to its failure.
