---
name: task-graph
description: Maintain explicit dependency-ready tasks, source revision, model class, write/resource claims, tests, handoffs and integration evidence; default one active cheap task.
---
For every node record at least:

```text
task_id
phase
source_revision
status = BLOCKED | READY | ACTIVE | HANDOFF | ESCALATED | INTEGRATED | DONE | STALE
model_class = cheap | pro
dependencies[]
canonical_owners[]
write_set[]
shared_mutable_resources[]
acceptance_tests[]
compatibility_tests[]
handoff
```

A task is READY only when dependencies are satisfied, its source revision is current and no source/conflict gate blocks it.

Default scheduler for cheap tasks: one ACTIVE at a time. Optional multi-hand activation requires explicit project opt-in and conflict-free claims.
