---
name: performance-benchmark
description: Benchmark real production paths reproducibly, with prerequisite gates, provenance and strict no-blind-rerun discipline.
---
# Preconditions

Before a long benchmark:
- relevant focused and integration tests are green;
- benchmark prerequisites are measured/qualified for the same valid provenance domain;
- no concurrent task owns the same mutable benchmark store/hardware qualification resource;
- benchmark command and expected artifacts are known.

# During run

Record run ID, configuration, hardware identity, software/model fingerprint, prerequisite provenance and progress. Do not edit code while the evidence run is active unless the run is intentionally cancelled and invalidated.

# On failure

Stop. Inspect the first failed gate and exact reason. Do not automatically continue to downstream scopes and do not relaunch the full benchmark until a relevant root-cause fix is proven with focused evidence.

# Valid evidence

Measured means the real backend/production execution path ran. Historical/default/estimated/synthetic values must be labelled as such and cannot satisfy a measured gate.
