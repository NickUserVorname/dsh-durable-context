---
name: phase-executor
description: Keep exactly one active phase and, by default, one active Flash implementation task; optional parallelism requires explicit project opt-in.
---
# Core rule

Exactly one implementation phase is active. By default, exactly one cheap/Flash task is ACTIVE at a time.

Additional concurrent cheap tasks are allowed only when project policy explicitly enables parallelism and `parallel-hands` preconditions pass.

# Per-task execution

1. Verify source revision, dependencies, task packet and claims.
2. Execute only the packet scope.
3. Run focused tests before broad tests.
4. Persist handoff/evidence.
5. Stop/edit-free before integration.

# Phase completion

Implementation completion is not phase completion. Integration, independent testing, Pro review and acceptance are separate gates. Never advance automatically.
