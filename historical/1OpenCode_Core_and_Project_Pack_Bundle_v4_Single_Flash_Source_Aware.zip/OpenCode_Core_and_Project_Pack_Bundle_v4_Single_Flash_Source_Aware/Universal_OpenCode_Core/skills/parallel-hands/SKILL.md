---
name: parallel-hands
description: Optional opt-in multi-hand execution inside one phase. Default is one Flash hand; enable parallel hands only when project policy explicitly permits it.
---
# Default

Do **not** spawn parallel cheap hands by default.

Require:

```text
parallel_opt_in = true
max_active_cheap_hands > 1
```

from the project concurrency policy before any parallel dispatch. Otherwise serialize READY tasks through the single cheap hand.

# Preconditions for optional parallel mode

For each pair of tasks verify:

```text
write_set(A) ∩ write_set(B) = empty
shared_mutable_resources(A) ∩ shared_mutable_resources(B) = empty
A does not consume B's unreviewed output
B does not consume A's unreviewed output
```

Treat unknown overlap as overlap.

# Shared resources that force serialization

- benchmark/result stores;
- generated config/state files;
- package lockfiles;
- migrations touching the same schema/version;
- code-generation outputs;
- a single hardware device if tests mutate its state;
- long benchmark/qualification artifacts;
- canonical central registries.

# Dispatch

1. Lead creates one task packet per hand.
2. Register tasks and claims.
3. Never exceed `max_active_cheap_hands`.
4. Each hand edits only its claim and writes its handoff.
5. Hands do not `git add`, commit, merge or rebase.
6. Long/shared qualification requires explicit ownership.

# Integration

After every dispatched hand is DONE/ESCALATED:

1. Freeze further hand edits.
2. Inspect full diffs and handoffs.
3. Resolve accidental overlap before testing.
4. Run cross-task integration tests.
5. Run independent Pro review.
6. Only then mark results integrated.

Parallel completion is not integration completion.
