---
name: implementation-planner
description: Convert exact phase requirements and current repository facts into reversible atomic task packets, dependencies, tests and rollback.
---
# Workflow

1. Start from requirement traceability and current repository facts.
2. Group changes by canonical owner, not by convenient new abstractions.
3. Define atomic tasks whose semantic outcome can be tested independently.
4. Add dependency edges.
5. Define exact write sets and shared mutable resources.
6. Mark each task `cheap` or `pro` using model-routing rules.
7. Define focused acceptance and negative tests before implementation.
8. Identify migration/rollback where state or stored formats change.
9. Identify integration tests required only after multiple tasks combine.
10. Stop before implementation if an S0/S1 semantic choice remains ambiguous.

Do not create tasks merely to create classes, adapters, managers or files. A task exists to close a measurable requirement gap.
