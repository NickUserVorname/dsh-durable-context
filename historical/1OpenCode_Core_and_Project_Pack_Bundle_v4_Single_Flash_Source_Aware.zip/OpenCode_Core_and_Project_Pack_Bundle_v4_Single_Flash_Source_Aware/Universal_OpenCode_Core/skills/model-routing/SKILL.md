---
name: model-routing
description: Route source interpretation/architecture to Pro and bounded scoped implementation/tests to cheap hands; escalate before repeated guessing burns tokens.
---
# Pro-only work

Use Pro for:

- source triage, mixed-source classification and precedence/conflict resolution;
- interpreting conflicting, ambiguous or long-range requirements;
- extracting normative user corrections from dirty transcripts;
- architecture and canonical ownership decisions;
- scheduler/concurrency/resource/transaction/state-machine semantics;
- migration/backward-compatibility policy changes;
- cross-subsystem changes whose interaction semantics are not already fixed;
- final integration decisions, independent review and acceptance.

# Cheap-hand work

Default topology is one active cheap/Flash role at a time. Use cheap hands when the task packet already fixes semantics and contains a bounded write set, tests and escalation rules. Good examples: local wiring, implementing a specified contract, focused tests, mechanical migration, benchmark adapter fixes and local deterministic debugging.

# Mandatory escalation conditions

A cheap hand stops and escalates when any is true:

1. task packet conflicts with repository reality or another approved requirement;
2. source intake is not READY or a source conflict appears;
3. completing the task requires interpreting dirty source material not normalized into the packet;
4. more than one canonical subsystem owner must change and interaction semantics are not explicit;
5. public/API/persisted/CLI behavior would change beyond the packet's compatibility policy;
6. scheduler/concurrency/transaction/resource semantics require a new decision;
7. the required production owner cannot be proven;
8. two evidence-backed fix hypotheses failed;
9. a fallback/workaround would change semantics or hide missing evidence;
10. task scope would have to grow.

Escalation is cheaper than repeated low-confidence retries.
