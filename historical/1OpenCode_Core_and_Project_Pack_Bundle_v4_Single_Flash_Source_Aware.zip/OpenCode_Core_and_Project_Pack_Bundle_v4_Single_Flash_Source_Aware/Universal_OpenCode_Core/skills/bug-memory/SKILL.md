---
name: bug-memory
description: "Persist reusable bug evidence: symptom, reproducer, first incorrect state, root cause, failed hypotheses, fix, regression test and prevention rule."
---
# Record

Append a structured JSONL record containing timestamp, phase/task, symptom, exact reproducer, affected owner, first incorrect state, root cause, failed hypotheses, fix commit/diff reference if available, regression test, evidence and prevention rule.

Do not record speculation as root cause. Update the record when a hypothesis is disproven rather than silently replacing history.
