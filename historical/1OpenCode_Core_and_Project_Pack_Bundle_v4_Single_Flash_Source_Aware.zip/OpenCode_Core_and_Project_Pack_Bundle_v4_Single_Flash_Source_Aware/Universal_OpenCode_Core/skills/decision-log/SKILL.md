---
name: decision-log
description: Record architecture-significant decisions with requirement, alternatives, evidence, chosen semantics, risks and rollback.
---
# Record when

A decision changes canonical ownership, public contracts, persisted format, fallback semantics, scheduling/resource policy, security posture, migration or a cross-subsystem invariant.

Record alternatives considered and why rejected. Do not log routine mechanical edits as architecture decisions.
