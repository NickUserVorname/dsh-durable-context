---
name: security-audit
description: Audit trust boundaries, injection, filesystem, subprocess, network, secrets and untrusted input without broadening project scope.
---
# Workflow

Map untrusted inputs to privileged actions. Check command construction, path traversal/symlink behavior, archive extraction, URL/credential handling, secret logging, environment inheritance, downloads/checksums, permission boundaries and unsafe repair/install actions.

Distinguish a real project requirement from speculative hardening. Report severity, exact path and minimal mitigation. Do not introduce unrelated security architecture.
