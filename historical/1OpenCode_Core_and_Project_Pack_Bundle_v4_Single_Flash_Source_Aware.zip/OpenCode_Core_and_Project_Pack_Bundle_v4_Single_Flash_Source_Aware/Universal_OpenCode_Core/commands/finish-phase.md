---
description: Pro acceptance audit of every mandatory requirement and evidence gate; stop without advancing.
agent: acceptance-auditor
subtask: true
---
Audit every mandatory active-phase requirement. Mandatory NOT_PROVEN is failure. Validate production execution, tests and real evidence where required. Write the phase report and stop. Do not begin the next phase.
