---
description: Escalate a blocked cheap task to Pro with reproducer, evidence and failed hypotheses instead of further cheap retries.
agent: lead
---
For task `$ARGUMENTS`, read its task packet, handoff and evidence. Confirm the escalation condition. Route the semantic decision/debugging to the appropriate Pro agent, preserve the original task scope, then either return a precise decision to the cheap hand or reclassify the task for `implementer-pro`.
