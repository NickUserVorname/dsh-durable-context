---
description: Debug current failures with cheap local debugging and bounded automatic escalation to Pro; prohibit blind long benchmark reruns.
agent: lead
---
Classify current failures. Route local deterministic failures to `debugger`. Route cross-subsystem/semantic failures or cheap failures exceeding the retry budget to `debugger-pro`. Require a reproducer and regression test. Do not rerun unchanged long/full benchmarks.
