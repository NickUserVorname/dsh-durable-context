---
description: Recover phase, concurrent tasks, claims, handoffs and long runs from persisted state and continue only the current phase.
agent: lead
---
Recover from repository and persisted state, not chat memory. Reconcile stale active tasks/claims with actual diffs and running long tasks. State the next safe action and continue only the active phase.
