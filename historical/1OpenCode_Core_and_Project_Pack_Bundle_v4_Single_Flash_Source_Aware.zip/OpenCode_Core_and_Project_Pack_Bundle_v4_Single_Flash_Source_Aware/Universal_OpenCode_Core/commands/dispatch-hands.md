---
description: Dispatch specific READY task IDs after source/conflict gates. With the default one-Flash policy, multiple IDs are serialized.
agent: lead
---
Require source intake READY and no blocking source conflict. Dispatch only task IDs in `$ARGUMENTS`. Verify dependencies, approved source provenance, compatibility policy, model class, write-set claims and shared-resource conflicts first.

Use task packets rather than raw/full/dirty source replay. With default `max_active_cheap_hands: 1`, execute requested cheap tasks sequentially. Parallel dispatch is allowed only after explicit project opt-in and only within the configured limit.
