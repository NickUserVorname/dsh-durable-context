---
description: Run independent focused and phase regressions; long/full qualification only after prerequisites are green and benchmark ownership is exclusive.
agent: lead
---
Invoke the independent tester for focused, integration, negative and regression tests. Classify failures. If long/full qualification is required, verify all prerequisite gates and exclusive benchmark ownership before starting it with the project long-task wrapper.
