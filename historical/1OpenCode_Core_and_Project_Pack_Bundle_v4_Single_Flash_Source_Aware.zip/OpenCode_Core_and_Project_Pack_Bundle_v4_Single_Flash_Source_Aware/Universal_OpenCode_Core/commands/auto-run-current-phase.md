---
description: Cost-aware current-phase orchestrator. Default one Flash hand, bounded Pro escalation, source gate, integration, test, review and acceptance. Never advances automatically.
agent: lead
---
First require source intake READY and no blocking source conflict; if not, perform source intake and stop for user resolution if needed. Run the current phase only.

Plan source-normalized task packets. Execute READY tasks through **one cheap hand at a time by default**; use optional parallelism only if the project explicitly enables it. Integrate, run focused/regression/compatibility tests, debug with bounded escalation, perform Pro review and acceptance audit.

Stop on blockers or failed gates. Never begin the next phase automatically and never use repeated long benchmarks as a debugging loop.
