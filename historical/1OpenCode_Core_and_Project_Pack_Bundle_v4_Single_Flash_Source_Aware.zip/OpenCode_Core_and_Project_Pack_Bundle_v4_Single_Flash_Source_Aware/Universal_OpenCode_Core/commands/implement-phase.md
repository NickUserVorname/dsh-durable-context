---
description: Dispatch READY source-normalized tasks. Default is exactly one cheap hand at a time; parallel hands require explicit project opt-in.
agent: lead
---
Refuse implementation unless source intake is READY and no blocking source conflict exists. Use the persisted task graph and task packets.

By default dispatch **one** READY implementation task to one hand. Cheap tasks use `implementer`; escalated semantic tasks use `implementer-pro`. Do not spawn a second cheap hand just because more READY tasks exist.

Only when `project_pack/CONCURRENCY_POLICY.md` explicitly has `parallel_opt_in: true` and `max_active_cheap_hands > 1` may additional conflict-free tasks run concurrently, never above that limit.

Collect handoffs and stop hand editing before integration. Do not start the next phase.
