---
description: "Pro-only read/metadata pass: classify formal specs, dirty transcripts, audits and logs; resolve precedence/conflicts and block mutation until source intake is READY."
agent: lead
---
Run source intake only; do not implement production code. Use `source-curator`/`source-triage` to inventory every supplied source, preserve raw files, classify source/statement authority, record explicit user-declared relationships and source-internal precedence, detect blocking conflicts, and compile the approved normalized requirement view. Update SOURCE_INTAKE/SOURCE_INDEX/SOURCE_CONFLICTS and state. If any blocking conflict remains, show it to the user and stop before mutation.
