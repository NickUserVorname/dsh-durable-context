---
description: Pro independent semantic review of the integrated phase diff; no production edits.
agent: reviewer
subtask: true
---
Review the integrated active-phase diff against exact requirements, invariants, production execution paths and tests. Look specifically for surface compliance, duplicate owners, placeholders, fake provenance, hidden fallbacks and architecture drift. Return evidence-backed blockers/majors/minors.
