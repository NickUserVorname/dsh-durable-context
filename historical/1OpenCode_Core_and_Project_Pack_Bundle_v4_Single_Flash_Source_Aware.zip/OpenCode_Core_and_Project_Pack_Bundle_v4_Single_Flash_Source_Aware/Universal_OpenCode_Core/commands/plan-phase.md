---
description: Pro lead verifies source intake, builds active-phase traceability, task packets, routing and dependency graph. Default execution plan uses one Flash hand.
agent: lead
---
Require source intake READY and no material blocking source conflict. Recover repository state. Read exact approved active-phase requirements. Build traceability and a dependency graph of atomic tasks.

For each task create/refresh a compact packet with current source revision, provenance, compatibility policy, model class (`cheap` or `pro`), write set, shared resources, tests and escalation conditions.

Plan cheap tasks for **sequential one-Flash execution by default**. You may annotate OPTIONAL parallel-safe candidates for future use, but do not activate parallel dispatch unless project policy explicitly opts in. Do not implement yet.
