---
description: Freeze hand edits, inspect handoffs/diffs, integrate completed tasks, run cross-task tests and prepare Pro review.
agent: lead
---
Freeze further edits from completed hands. Inspect every requested task handoff and full diff. Reject scope growth or unproven surface compliance. Resolve overlap, run focused and cross-task integration tests, update integrated evidence and then invoke the Pro reviewer. Do not run full/long qualification unless its prerequisite gates are green.
