# Project Pack Template v4 — Source-aware, Single Flash Default

Copy/install this into a specific repository. It is separate from `Universal_OpenCode_Core`:

- Universal core = reusable global agents/skills/commands;
- Project pack = per-project source authority, normalized/indexed specification, active phase, invariants, toolchain, state, task packets and evidence.

## First setup

1. Install Universal Core globally.
2. Install this template into the target repository.
3. Provide/point source intake at **every relevant raw source**: clean specs, corrections, dirty requirement drafts/discussions, audits, implementation logs and current-state reports.
4. Run `/ingest-sources` or use `OPENCODE_SETUP_PROMPT.txt`.
5. Do not implement until intake is READY and no material blocking conflict remains.

Do **not** overwrite `project_pack/FULL_SPEC.md` with one raw spec. Raw sources stay raw; FULL_SPEC is a compact compiled index/view with provenance.

## Default execution

Exactly one cheap/Flash role is active at a time. Pro handles source interpretation/architecture/review/escalation. Optional parallel hands require explicit opt-in.

## Supported inputs

- one 7k+ formal spec;
- formal base/correction/recovery stacks with explicit precedence;
- clean ~500-line mini-spec + dirty ~1000-line draft/discussion;
- audit-driven repair;
- dirty agent transcript containing user corrections + assistant proposals + tool logs;
- user-supplied “what exists now” snapshots/reports, treated as evidence and verified against repo/runtime.

## Installer safety

Existing AGENTS rules are merged, existing project `opencode.jsonc` is preserved by default, and live `project_pack/.agent` state is never overwritten on reinstall. Backups are created first.
