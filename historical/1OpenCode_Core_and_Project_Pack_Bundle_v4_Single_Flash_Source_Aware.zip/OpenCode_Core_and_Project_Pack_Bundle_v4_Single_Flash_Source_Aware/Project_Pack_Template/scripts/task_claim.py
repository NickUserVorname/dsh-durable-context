from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / ".agent" / "claims.json"


def load():
    if not PATH.exists():
        return {"schema_version": "1.0", "claims": []}
    return json.loads(PATH.read_text(encoding="utf-8"))


def save(data):
    PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    tmp.replace(PATH)


def norm(p: str) -> str:
    value = Path(p).as_posix().strip("/")
    return value.casefold() if os.name == "nt" else value


def overlaps(a: str, b: str) -> bool:
    a, b = norm(a), norm(b)
    return a == b or a.startswith(b + "/") or b.startswith(a + "/")


ap = argparse.ArgumentParser(description="Manage agent write/shared-resource claims")
sp = ap.add_subparsers(dest="action", required=True)
acq = sp.add_parser("acquire")
acq.add_argument("--task", required=True)
acq.add_argument("--write", action="append", default=[])
acq.add_argument("--resource", action="append", default=[])
rel = sp.add_parser("release")
rel.add_argument("--task", required=True)
sp.add_parser("list")
a = ap.parse_args()

data = load()
claims = data.setdefault("claims", [])

if a.action == "list":
    print(json.dumps(data, indent=2))
    raise SystemExit(0)

if a.action == "release":
    data["claims"] = [c for c in claims if c.get("task_id") != a.task]
    save(data)
    print(f"released {a.task}")
    raise SystemExit(0)

existing = [c for c in claims if c.get("task_id") != a.task]
for c in existing:
    for x in a.write:
        for y in c.get("write_set", []):
            if overlaps(x, y):
                raise SystemExit(f"write-set conflict: {x!r} overlaps {y!r} claimed by {c['task_id']}")
    shared = set(a.resource) & set(c.get("shared_resources", []))
    if shared:
        raise SystemExit(f"shared-resource conflict with {c['task_id']}: {sorted(shared)}")

claims[:] = [c for c in claims if c.get("task_id") != a.task]
claims.append({"task_id": a.task, "write_set": [norm(x) for x in a.write], "shared_resources": a.resource})
save(data)
print(json.dumps(claims[-1], indent=2))
