from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TASKS = ROOT / ".agent" / "tasks"
TASKS.mkdir(parents=True, exist_ok=True)


def paths(name: str):
    safe = "".join(c for c in name if c.isalnum() or c in "-_.")
    if not safe or safe != name:
        raise ValueError("Unsafe task name; use only letters, digits, '-', '_' and '.'")
    return TASKS / f"{safe}.json", TASKS / f"{safe}.log", TASKS / f"{safe}.exitcode"


def running(pid: int) -> bool:
    try:
        if os.name == "nt":
            r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], capture_output=True, text=True)
            return f'"{pid}"' in r.stdout or f',"{pid}",' in r.stdout
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def current_status(meta_p: Path, exit_p: Path):
    if not meta_p.exists():
        return None
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    if exit_p.exists():
        meta.update(status="finished", exit_code=int(exit_p.read_text().strip()))
    else:
        meta.update(status="running" if running(int(meta["pid"])) else "unknown_stopped")
    return meta


ap = argparse.ArgumentParser(description="Run/check long project commands without duplicate same-name starts")
sp = ap.add_subparsers(dest="action", required=True)
s = sp.add_parser("start")
s.add_argument("--name", required=True)
s.add_argument("command", nargs=argparse.REMAINDER)
s = sp.add_parser("status")
s.add_argument("--name", required=True)
s = sp.add_parser("tail")
s.add_argument("--name", required=True)
s.add_argument("--lines", type=int, default=100)
a = ap.parse_args()
meta_p, log_p, exit_p = paths(a.name)

if a.action == "start":
    existing = current_status(meta_p, exit_p)
    if existing and existing.get("status") == "running":
        raise SystemExit(f"Refusing duplicate start: task {a.name!r} is already running with PID {existing['pid']}")

    cmd = a.command[1:] if a.command and a.command[0] == "--" else a.command
    if not cmd:
        raise SystemExit("Command required")

    exit_p.unlink(missing_ok=True)
    run_id = uuid.uuid4().hex
    wrapper = ROOT / "scripts" / "_task_wrapper.py"
    log = log_p.open("w", encoding="utf-8")
    kwargs = dict(cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    else:
        kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen([sys.executable, str(wrapper), str(exit_p), *cmd], **kwargs)
    finally:
        log.close()

    meta = {"run_id": run_id, "pid": proc.pid, "command": cmd, "started_at": time.time(), "log": str(log_p), "exit_file": str(exit_p)}
    meta_p.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps({**meta, "status": "running"}, indent=2))

elif a.action == "status":
    meta = current_status(meta_p, exit_p)
    if meta is None:
        raise SystemExit(f"Unknown task: {a.name}")
    print(json.dumps(meta, indent=2))

else:
    if not log_p.exists():
        raise SystemExit(f"No log for task: {a.name}")
    lines = log_p.read_text(encoding="utf-8", errors="replace").splitlines()
    print("\n".join(lines[-a.lines:]))
