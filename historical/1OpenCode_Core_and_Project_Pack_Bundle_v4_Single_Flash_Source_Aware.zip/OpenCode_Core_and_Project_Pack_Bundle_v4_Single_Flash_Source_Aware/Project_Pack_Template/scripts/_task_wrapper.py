from pathlib import Path
import subprocess, sys
exit_file = Path(sys.argv[1])
code = 255
try:
    code = subprocess.run(sys.argv[2:], check=False).returncode
finally:
    exit_file.write_text(str(code), encoding="utf-8")
raise SystemExit(code)
