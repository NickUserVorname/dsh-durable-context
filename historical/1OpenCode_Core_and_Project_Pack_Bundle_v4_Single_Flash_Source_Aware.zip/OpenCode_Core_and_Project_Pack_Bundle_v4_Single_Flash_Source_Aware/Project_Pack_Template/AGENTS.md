# Project-local Agent Rules

Read before implementation:

1. `project_pack/SOURCE_POLICY.md`
2. `project_pack/SOURCE_INTAKE.md`
3. `project_pack/SOURCE_INDEX.json` and `SOURCE_CONFLICTS.md`
4. `project_pack/FULL_SPEC.md` only as needed for authoritative retrieval; Flash normally uses task packets.
5. `project_pack/CURRENT_PHASE.md`
6. `project_pack/PROJECT_INVARIANTS.md`
7. `project_pack/CONCURRENCY_POLICY.md`
8. `project_pack/MODEL_ROUTING.md`
9. `project_pack/TOOLCHAIN.json`
10. `.agent/state.json`, `.agent/task_graph.json`, `.agent/claims.json`

## Hard pre-mutation gate

No production edit, test mutation, benchmark mutation or implementation-hand dispatch while source intake is not READY or a material BLOCKING conflict remains. Read-only inspection is allowed.

Every task packet must match current `source_revision`. A user correction/source-authority change invalidates older READY packets before more edits.

## Project workflow

- Work only on the active phase.
- Default = **one active Flash/cheap hand/role at a time**. Do not spawn a second unless explicitly opted in.
- Every implementation task receives a source-normalized task packet.
- Flash does not reinterpret dirty transcripts/audits into new requirements.
- Do not begin the next phase automatically.
- Preserve project invariants, negative requirements and requested backward compatibility.
- Validate toolchain commands against real repository state.
- Persist progress, claims, decisions, bugs, handoffs and reports under `.agent/`.
- Use `scripts/agent_task.py` for long-running commands; it refuses duplicate same-name starts.
- Only one task may own a shared long benchmark/qualification at a time.
- Analyze a failed long benchmark before any rerun.
