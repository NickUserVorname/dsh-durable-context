# Project invariants

Replace these examples with the project's real non-negotiable rules.

- Do not silently lose user data.
- Do not change public behavior without tests and migration notes.
- Do not begin the next phase automatically.
- Do not hide failing tests or fallbacks.
- Do not perform destructive filesystem or Git operations.
