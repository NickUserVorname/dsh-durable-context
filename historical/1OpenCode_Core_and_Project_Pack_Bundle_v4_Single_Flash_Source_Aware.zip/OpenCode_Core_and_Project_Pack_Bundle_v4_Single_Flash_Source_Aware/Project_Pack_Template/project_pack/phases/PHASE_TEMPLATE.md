# Phase N — Name

Source revision: `<current>`

## Dependencies

## Scope

## Requirements / traceability

## Do not implement yet

## Deliverables

## Atomic task candidates

For each candidate identify model class, dependencies, canonical owners, write set and shared mutable resources.

## Tests

### Focused
### Integration
### Regression
### Long/full qualification

## Exit gate
