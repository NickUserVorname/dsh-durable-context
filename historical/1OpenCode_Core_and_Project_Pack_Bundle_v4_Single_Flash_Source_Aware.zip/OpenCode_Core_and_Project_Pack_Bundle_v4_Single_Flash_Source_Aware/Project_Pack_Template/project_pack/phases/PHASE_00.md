# PHASE 00 — Source intake and repository baseline

## Gate 0A — Source authority

- inventory all supplied sources;
- classify source/statement authority;
- resolve explicit precedence;
- detect conflicts;
- source intake must be READY before any implementation mutation.

## Gate 0B — Repository baseline

- inspect real canonical owners/runtime paths;
- establish baseline tests/toolchain;
- map approved active requirements to current state.

No production behavior changes in this phase unless the user explicitly defines a different Phase 0.
