# Model routing

Default intent:

```text
DeepSeek V4 Pro   -> lead / source triage / architecture / semantic decisions / review / acceptance / escalated implementation
DeepSeek V4 Flash -> ONE active cheap role at a time: scoped implementer OR tester OR routine debugger
```

The default project topology is one Flash hand/role at a time. Do not run implementer + tester/debugger as concurrent cheap agents unless the user explicitly opts into parallel hands later.

## Cheap hand boundary

Flash may choose local implementation details only inside an already-fixed semantic contract. It may not silently decide canonical architecture/ownership, cross-subsystem contracts, scheduler/concurrency/resource semantics, migration/data compatibility, security policy, user-visible fallback/quality changes, requirement conflicts or scope expansion. Those escalate to Pro.

## Cost rule

Do not replay `FULL_SPEC.md` or raw source bundles to every Flash role. The Pro lead extracts exact relevant requirements into task packets. Tester works from integrated packets/test matrix; debugger works from reproducer/evidence.

Do not repeatedly retry Flash on the same semantic blocker. Two evidence-backed failed hypotheses is the default maximum; critical semantic classes escalate immediately.

## Source triage

Source classification, transcript speaker/authority separation, precedence/conflict resolution and clean+dirty normalization are Pro-only. Flash receives approved packets and never mines dirty source bundles for new requirements.
