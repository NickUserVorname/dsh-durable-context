# Concurrency policy

```yaml
parallel_opt_in: false
max_active_cheap_hands: 1
```

## Default: one Flash hand

The default execution topology is one active implementation phase and **one active cheap/Flash hand at a time**. A second cheap hand must never be spawned merely because another READY task exists.

Multiple cheap hands are an explicit project/user opt-in. To enable them, change both fields above and record the decision in `.agent/decisions/decisions.jsonl`.

## Optional parallel mode

If parallelism is explicitly enabled, independent atomic tasks may run concurrently only when:

- all dependency edges are satisfied;
- explicit write sets do not overlap, or isolated worktrees are used;
- no mutable benchmark/config/state/generated-output owner is shared;
- neither task consumes the other's unreviewed output;
- each task has focused acceptance evidence.

Unknown overlap means serialize.

## Shared resources

Only one active owner at a time for:

- long/full benchmark or qualification;
- benchmark/result store mutation;
- schema/version migration;
- package lockfiles if tools rewrite them;
- generated central registries;
- any hardware test that mutates global device state.

## Integration

Hands do not merge or commit. After the active hand stops editing, the lead performs a separate integration/review step. In optional parallel mode, integration starts only after all relevant hands stop editing.

Hand completion is not phase completion.
