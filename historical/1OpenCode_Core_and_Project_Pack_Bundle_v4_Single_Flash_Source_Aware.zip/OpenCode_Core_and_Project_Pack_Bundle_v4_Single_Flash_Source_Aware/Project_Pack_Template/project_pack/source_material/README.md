# Raw source material

Preserve supplied source artifacts here unchanged when possible. Examples: formal specs, corrections, dirty requirement drafts, conversation transcripts, audits, implementation logs and current-state reports.

Do not edit a raw source to “clean it up”. Authority, statement classification and precedence belong in SOURCE_INDEX/SOURCE_INTAKE/FULL_SPEC. Repository/runtime remains the factual authority for what currently exists.
