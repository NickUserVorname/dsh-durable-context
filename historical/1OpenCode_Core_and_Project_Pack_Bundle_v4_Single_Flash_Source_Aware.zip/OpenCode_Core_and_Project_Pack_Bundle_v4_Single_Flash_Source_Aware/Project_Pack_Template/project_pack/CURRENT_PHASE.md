# Current phase

```yaml
source_intake_status: UNRESOLVED
source_revision: 0
phase: 0
name: Source intake, repository audit and baseline preservation
status: not_started
execution:
  parallel_opt_in: false
  max_active_cheap_hands: 1
  active_task_ids: []
  benchmark_owner_task_id: null
```

## Scope

First resolve source authority/precedence/conflicts, then replace this section with the exact scope of the first factually unfinished implementation phase.

## Required deliverables

- source classification/index/precedence and conflict status;
- repository/current-state map;
- exact approved requirement traceability for active scope;
- baseline test result;
- verified toolchain commands;
- compatibility risks/policy;
- task graph and source-normalized task packets.

## Forbidden

- No production/test/benchmark mutation while source intake is not READY.
- Do not implement later phases.
- Do not change production behavior during an audit-only phase unless explicitly required.
- Do not send ambiguous source/architecture decisions to the cheap implementation hand.
- Do not spawn a second cheap hand unless the project/user explicitly opts into it.
