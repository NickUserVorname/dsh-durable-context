# Task packets

Each implementation task gets one compact packet compiled by the Pro path after source intake is READY.

Packets contain approved requirements with exact source provenance, compatibility policy, write set, tests and escalation conditions. Do not paste raw dirty transcripts into cheap-hand packets.
