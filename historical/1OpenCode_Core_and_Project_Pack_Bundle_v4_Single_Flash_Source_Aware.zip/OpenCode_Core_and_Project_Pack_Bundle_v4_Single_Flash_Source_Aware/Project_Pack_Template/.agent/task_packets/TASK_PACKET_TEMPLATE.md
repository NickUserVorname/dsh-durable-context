# Task packet

```yaml
task_id:
phase:
status: ready
model_class: cheap
source_intake_status: READY
source_revision: 0
requirements:
  - id:
    text:
    source_id:
    source_location:
    authority:
compatibility_policy: NONE
invariants: []
required_context_files: []
scope:
  allowed_changes: []
  forbidden_changes: []
canonical_owners: []
write_set: []
dependencies: []
acceptance_tests: []
compatibility_tests: []
negative_tests: []
benchmark_owner: false
shared_mutable_resources: []
escalation_conditions: []
failed_hypothesis_budget: 2
expected_handoff: ""
```

Do not include raw dirty transcripts. Include only source-normalized approved requirements with provenance.

Before work, compare `source_revision` with current `SOURCE_INTAKE.md`. A mismatch makes the packet STALE; stop and return it to the Pro lead for regeneration.
