# Handoffs

Every hand writes `<TASK_ID>.md` before returning control to the lead.

Required sections: status, files changed, semantic behavior, tests, exact commands/results, deviations from packet, blockers/escalation, remaining risks and evidence references.
