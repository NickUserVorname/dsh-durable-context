# Phase <N> Report

## Phase
## Source revision used
## Requirement traceability
## Task graph / parallel execution
## Task packets completed
## Escalations
## Implemented
## Files changed
## Integration
## Migrations
## Compatibility
## Decisions
## Bugs/root causes
## Tests added
## Tests executed
## Failures and classification
## Long benchmark / qualification evidence
## Security review
## Known limitations
## Reviewer findings
## Acceptance auditor verdict
## Exit gate
