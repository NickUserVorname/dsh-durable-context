param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectPath,
    [switch]$ReplaceProjectConfig
)

$ErrorActionPreference = "Stop"
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = (Resolve-Path $ProjectPath).Path
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "Installing Project Pack Template v4"
Write-Host "Target project: $Target"

function Backup-Path([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $Backup = "$Path.backup-$Stamp"
        Copy-Item -Recurse -Force -LiteralPath $Path -Destination $Backup
        Write-Host "Backup: $Path -> $Backup"
    }
}

function Copy-TreeContents([string]$From, [string]$To) {
    New-Item -ItemType Directory -Force -Path $To | Out-Null
    Get-ChildItem -LiteralPath $From -Recurse -File -Force | ForEach-Object {
        $Relative = $_.FullName.Substring($From.Length).TrimStart([char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar))
        $Dest = Join-Path $To $Relative
        $Parent = Split-Path -Parent $Dest
        New-Item -ItemType Directory -Force -Path $Parent | Out-Null
        Copy-Item -Force -LiteralPath $_.FullName -Destination $Dest
    }
}

# Merge rules without destroying repository AGENTS.md.
$PackAgents = Get-Content -LiteralPath (Join-Path $Source "AGENTS.md") -Raw
$AgentsTarget = Join-Path $Target "AGENTS.md"
$Begin = "<!-- BEGIN OPENCode PROJECT PACK v4 -->"
$End = "<!-- END OPENCode PROJECT PACK v4 -->"
$Pattern = [regex]::Escape($Begin) + ".*?" + [regex]::Escape($End)
$Regex = [regex]::new($Pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
$Block = "$Begin`r`n$PackAgents`r`n$End"
if (Test-Path -LiteralPath $AgentsTarget) {
    Backup-Path $AgentsTarget
    $Existing = Get-Content -LiteralPath $AgentsTarget -Raw
    if ($Regex.IsMatch($Existing)) { $Merged = $Regex.Replace($Existing, $Block) }
    else { $Merged = $Existing.TrimEnd() + "`r`n`r`n" + $Block + "`r`n" }
    Set-Content -LiteralPath $AgentsTarget -Value $Merged -Encoding UTF8
} else {
    Set-Content -LiteralPath $AgentsTarget -Value $Block -Encoding UTF8
}

# Preserve user-owned project config by default.
$ConfigSource = Join-Path $Source "opencode.jsonc"
$ConfigTarget = Join-Path $Target "opencode.jsonc"
if (-not (Test-Path -LiteralPath $ConfigTarget)) {
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $ConfigTarget
} elseif ($ReplaceProjectConfig) {
    Backup-Path $ConfigTarget
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $ConfigTarget
} else {
    $Reference = Join-Path $Target "opencode.project-pack-v4.reference.jsonc"
    Copy-Item -Force -LiteralPath $ConfigSource -Destination $Reference
    Write-Warning "Existing project opencode.jsonc preserved. Review/merge $Reference if needed."
}

# Stateful dirs are initialization-only. Never overlay live project state on reinstall.
foreach ($DirName in @("project_pack", ".agent")) {
    $From = Join-Path $Source $DirName
    $To = Join-Path $Target $DirName
    if (Test-Path -LiteralPath $To) {
        Backup-Path $To
        Write-Warning "$DirName already exists; live state preserved and template not overlaid."
    } else {
        Copy-TreeContents $From $To
    }
}

# Runtime helper scripts are pack-owned and may be refreshed after backup.
$ScriptsFrom = Join-Path $Source "scripts"
$ScriptsTo = Join-Path $Target "scripts"
if (Test-Path -LiteralPath $ScriptsTo) { Backup-Path $ScriptsTo }
Copy-TreeContents $ScriptsFrom $ScriptsTo

Write-Host "Project pack installed/preserved safely."
Write-Host "Next: provide ALL raw sources to source intake; do NOT paste one real spec directly over project_pack\FULL_SPEC.md."
Write-Host "Use OPENCODE_SETUP_PROMPT.txt or /ingest-sources. Default: one Flash role at a time."
