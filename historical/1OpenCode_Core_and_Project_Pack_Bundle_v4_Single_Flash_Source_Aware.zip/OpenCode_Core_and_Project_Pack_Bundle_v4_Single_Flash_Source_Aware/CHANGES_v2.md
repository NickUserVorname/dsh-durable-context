# v2 — API Hands / Parallel Execution

This revision keeps the original evidence-first, phase-gated style and adds a cost-aware multi-agent execution layer.

## Main changes

- DeepSeek V4 Pro is the default **lead / architect / reviewer / acceptance** model.
- DeepSeek V4 Flash is the default **implementer / tester / routine debugger** model.
- Added explicit **Flash -> Pro escalation** instead of burning cheap-agent retries indefinitely.
- Replaced the global "one atomic task at a time" rule with:
  - one active phase;
  - multiple independent atomic tasks may run concurrently;
  - overlapping writes, shared mutable benchmark state, and integration are serialized.
- Added **task packets** so hands do not reread the full project specification for every task.
- Added **write-set claims** and structured handoffs.
- Added a dedicated **integration gate** after parallel work.
- Added benchmark ownership rules to prevent repeated full/long benchmark loops.
- Expanded the thin skills into concrete workflows with evidence, state transitions and stop conditions.
- Updated project state/task graph schema for multiple active tasks.

## Model IDs

The pack currently uses OpenCode's direct DeepSeek provider IDs:

- `deepseek/deepseek-v4-pro`
- `deepseek/deepseek-v4-flash`

Connect the DeepSeek provider with `/connect`, then confirm the exact IDs using `/models`. If OpenCode changes provider IDs, edit only the `model:` lines in `Universal_OpenCode_Core/agents/*.md`.

No API keys are stored in this pack.
