# v4 control-audit fixes

This version is a corrective audit of v3, not a new architecture rewrite.

Key fixes:

- default cheap topology changed from two parallel Flash hands to **one active Flash role at a time**; optional parallelism is explicit opt-in only;
- lead task permission restricted to named pack agents, preventing accidental subagent proliferation;
- fixed OpenCode permission-rule ordering for source curator / acceptance paths; tester is now read-only for independent verification;
- added `source_revision` and stale-task-packet invalidation after user/source corrections;
- added `DIRTY_REQUIREMENT_DRAFT` and `CURRENT_STATE_REPORT` source classes;
- material UNKNOWN authority blocks; clearly nonmaterial unknowns can be recorded/deferred instead of freezing all work;
- large 7k+ specs stay raw; FULL_SPEC is a compact indexed view, not a costly paraphrased clone;
- setup prompt explicitly supports formal spec, formal stack, clean+dirty, dirty TЗ, audit, transcript and “what exists now” evidence;
- installers preserve/merge existing AGENTS/config/state by default and avoid directory nesting on reinstall;
- long-task wrapper refuses duplicate same-name starts and handles missing status/logs cleanly;
- removed accidental `__pycache__/*.pyc` artifacts;
- regenerated manifests and validation metadata.
